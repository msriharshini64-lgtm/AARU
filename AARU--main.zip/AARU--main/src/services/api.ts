import {
  Product,
  Order,
  UserProfile,
  NotificationItem,
  EditorialStory,
  ConsultationRequest,
  SearchResponse,
  SearchFacets,
  CatalogueFilterState,
  EditorialCollection,
  ShopTheLookEnsemble,
  SendOtpResult,
  VerifyOtpResult,
  AuthStatusResult
} from '../types';
import {
  INITIAL_PRODUCTS,
  EDITORIAL_STORIES,
  INITIAL_ORDERS,
  INITIAL_USER_PROFILE,
  INITIAL_NOTIFICATIONS,
  EDITORIAL_COLLECTIONS,
  SHOP_THE_LOOKS
} from '../data/mockData';
import { DatabaseSearchEngine, SearchQueryFilters } from '../../server/searchService';

// Fallback search engine in browser memory
const clientSearchEngine = new DatabaseSearchEngine(INITIAL_PRODUCTS);

export const api = {
  async search(params: SearchQueryFilters): Promise<SearchResponse> {
    try {
      const query = new URLSearchParams();
      if (params.q) query.set('q', params.q);
      if (params.category && params.category !== 'all') query.set('category', params.category);
      if (params.collection && params.collection !== 'all') query.set('collection', params.collection);
      if (typeof params.minPrice === 'number') query.set('minPrice', String(params.minPrice));
      if (typeof params.maxPrice === 'number') query.set('maxPrice', String(params.maxPrice));
      if (params.color?.length) query.set('color', params.color.join(','));
      if (params.fabric?.length) query.set('fabric', params.fabric.join(','));
      if (params.size?.length) query.set('size', params.size.join(','));
      if (params.occasion?.length) query.set('occasion', params.occasion.join(','));
      if (params.availability && params.availability !== 'all') query.set('availability', params.availability);
      if (params.sort) query.set('sort', params.sort);

      const res = await fetch(`/api/search?${query.toString()}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return clientSearchEngine.search(params);
  },

  async getCatalogueFilters(): Promise<SearchFacets> {
    try {
      const res = await fetch('/api/catalogue/filters');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return clientSearchEngine.getFacets();
  },

  async getSearchSuggestions(q?: string): Promise<SearchResponse['suggestions']> {
    try {
      const query = q ? `?q=${encodeURIComponent(q)}` : '';
      const res = await fetch(`/api/search/suggestions${query}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return clientSearchEngine.getSuggestions(q);
  },

  async getProducts(params?: {
    element?: string;
    category?: string;
    search?: string;
    sort?: string;
    minPrice?: number;
    maxPrice?: number;
    color?: string[];
    fabric?: string[];
    size?: string[];
    occasion?: string[];
    availability?: string;
  }): Promise<Product[]> {
    try {
      const query = new URLSearchParams();
      if (params?.element && params.element !== 'all') query.set('element', params.element);
      if (params?.category && params.category !== 'all') query.set('category', params.category);
      if (params?.search) query.set('search', params.search);
      if (params?.sort) query.set('sort', params.sort);
      if (params?.minPrice) query.set('minPrice', String(params.minPrice));
      if (params?.maxPrice) query.set('maxPrice', String(params.maxPrice));
      if (params?.color?.length) query.set('color', params.color.join(','));
      if (params?.fabric?.length) query.set('fabric', params.fabric.join(','));
      if (params?.size?.length) query.set('size', params.size.join(','));
      if (params?.occasion?.length) query.set('occasion', params.occasion.join(','));
      if (params?.availability && params.availability !== 'all') query.set('availability', params.availability);

      const res = await fetch(`/api/products?${query.toString()}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback to local
    }

    const searchRes = await clientSearchEngine.search({
      q: params?.search,
      category: params?.category,
      collection: params?.element,
      minPrice: params?.minPrice,
      maxPrice: params?.maxPrice,
      color: params?.color,
      fabric: params?.fabric,
      size: params?.size,
      occasion: params?.occasion,
      availability: params?.availability as any,
      sort: params?.sort as any
    });
    return searchRes.products;
  },

  async getProductById(id: string): Promise<Product | undefined> {
    try {
      const res = await fetch(`/api/products/${id}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return INITIAL_PRODUCTS.find(p => p.id === id);
  },

  async getStories(): Promise<EditorialStory[]> {
    try {
      const res = await fetch('/api/stories');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return EDITORIAL_STORIES;
  },

  async getOrders(): Promise<Order[]> {
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return INITIAL_ORDERS;
  },

  async createOrder(orderData: { items: any[]; total: number; shippingAddress?: any; giftPackaging?: boolean }): Promise<Order> {
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }

    const orderSeq = Math.floor(1000 + Math.random() * 9000);
    return {
      id: `order-${Date.now()}`,
      orderNumber: `ARU-${orderSeq}`,
      date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      total: orderData.total,
      status: 'Artisan Allocated',
      estimatedDelivery: new Date(Date.now() + 14 * 86400000).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      giftPackaging: Boolean(orderData.giftPackaging),
      shippingAddress: orderData.shippingAddress || {
        fullName: 'AARU Patron',
        email: 'patron@aaru.luxury',
        phone: '+91 98490 12345',
        address: 'Bespoke Atelier Address',
        city: 'Hyderabad',
        postalCode: '500033',
        country: 'India'
      },
      items: orderData.items,
      trackingMilestones: [
        {
          title: 'Artisan Allocated',
          description: 'Senior Master Weaver and guild loom assigned for bespoke crafting.',
          date: 'Just now',
          completed: true
        },
        {
          title: 'Warp Setup & Zari Allocation',
          description: 'Inspecting certified 24k gold core zari and pure mulberry silk yarn.',
          date: 'In preparation',
          completed: false
        }
      ]
    };
  },

  async getProfile(): Promise<UserProfile> {
    try {
      const res = await fetch('/api/profile');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return INITIAL_USER_PROFILE;
  },

  async updateProfile(profile: Partial<UserProfile>): Promise<UserProfile> {
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
      });
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return { ...INITIAL_USER_PROFILE, ...profile };
  },

  async getNotifications(): Promise<{ items: NotificationItem[]; unreadCount: number }> {
    try {
      const res = await fetch('/api/notifications');
      if (res.ok) {
        const json = await res.json();
        return { items: json.data, unreadCount: json.unreadCount };
      }
    } catch {
      // Fallback
    }
    return {
      items: INITIAL_NOTIFICATIONS,
      unreadCount: INITIAL_NOTIFICATIONS.filter(n => !n.read).length
    };
  },

  async markNotificationsRead(id?: string): Promise<void> {
    try {
      await fetch('/api/notifications/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
    } catch {
      // Ignore
    }
  },

  async triggerTestNotification(type: 'order' | 'recommendation' | 'atelier'): Promise<NotificationItem | null> {
    try {
      const res = await fetch('/api/notifications/trigger-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type })
      });
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Ignore
    }
    return null;
  },

  async bookConsultation(data: Partial<ConsultationRequest>): Promise<ConsultationRequest> {
    try {
      const res = await fetch('/api/consultations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return {
      id: `cons-${Date.now()}`,
      clientName: data.clientName || 'Patron',
      email: data.email || 'patron@aaru.luxury',
      phone: data.phone || '+91 90000 00000',
      preferredChannel: data.preferredChannel || 'whatsapp',
      preferredDate: data.preferredDate || new Date().toISOString(),
      coutureInterest: data.coutureInterest || 'Couture Sizing',
      status: 'confirmed'
    };
  },

  async getRecommendations(element?: string): Promise<Product[]> {
    try {
      const res = await fetch(`/api/recommendations?element=${element || 'aaru'}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return INITIAL_PRODUCTS.slice(0, 3);
  },

  async getReadyToShip(params?: {
    category?: string;
    sort?: string;
    minPrice?: number;
    maxPrice?: number;
    color?: string[];
    fabric?: string[];
  }): Promise<{ meta: any; data: Product[]; total: number }> {
    try {
      const query = new URLSearchParams();
      if (params?.category && params.category !== 'all') query.set('category', params.category);
      if (params?.sort) query.set('sort', params.sort);
      if (params?.minPrice) query.set('minPrice', String(params.minPrice));
      if (params?.maxPrice) query.set('maxPrice', String(params.maxPrice));
      if (params?.color?.length) query.set('color', params.color.join(','));
      if (params?.fabric?.length) query.set('fabric', params.fabric.join(','));

      const res = await fetch(`/api/collections/ready-to-ship?${query.toString()}`);
      if (res.ok) {
        const json = await res.json();
        return { meta: json.meta, data: json.data, total: json.total };
      }
    } catch {
      // Fallback
    }

    let items = INITIAL_PRODUCTS.filter(p => p.inStock && p.availability === 'in_stock');
    if (params?.category && params.category !== 'all') {
      items = items.filter(p => p.category.toLowerCase() === params.category!.toLowerCase());
    }
    return {
      meta: {
        id: 'ready-to-ship',
        title: 'Ready to Ship Creations',
        teluguTitle: 'తక్షణ లభ్యత',
        subtitle: 'Immaculate Handcrafted Silhouettes Available for 24-Hour Immediate Courier',
        description: 'Vault-stored creations that have achieved full master-weaver completion and 24K zari hallmark certification.',
        route: '/ready-to-ship',
        badge: 'Immediate Dispatch',
        dispatchPromise: 'Guaranteed 24-hour white glove handover to logistics courier'
      },
      data: items,
      total: items.length
    };
  },

  async getSareesReadyToShip(params?: {
    sort?: string;
    minPrice?: number;
    maxPrice?: number;
    color?: string[];
    fabric?: string[];
  }): Promise<{ meta: any; data: Product[]; total: number }> {
    try {
      const query = new URLSearchParams();
      if (params?.sort) query.set('sort', params.sort);
      if (params?.minPrice) query.set('minPrice', String(params.minPrice));
      if (params?.maxPrice) query.set('maxPrice', String(params.maxPrice));
      if (params?.color?.length) query.set('color', params.color.join(','));
      if (params?.fabric?.length) query.set('fabric', params.fabric.join(','));

      const res = await fetch(`/api/collections/sarees-ready-to-ship?${query.toString()}`);
      if (res.ok) {
        const json = await res.json();
        return { meta: json.meta, data: json.data, total: json.total };
      }
    } catch {
      // Fallback
    }

    const items = INITIAL_PRODUCTS.filter(p => p.inStock && p.availability === 'in_stock' && p.category === 'saree');
    return {
      meta: {
        id: 'sarees-ready-to-ship',
        title: 'Sarees – Ready to Ship',
        teluguTitle: 'తక్షణ పట్టు చీరలు',
        subtitle: 'Certified Masterpiece Drapes in Kanchipuram, Banarasi & Uppada Weaves',
        description: 'Six yards of woven poetry, tested real gold-silver zari, and certified Silk Mark authenticity. Dispatched immediately.',
        route: '/sarees-ready-to-ship',
        badge: 'Handloom Saree Vault',
        dispatchPromise: 'Ships within 24 hours in velvet-lined teakwood casket with unstitched matching blouse'
      },
      data: items,
      total: items.length
    };
  },

  async getEditorialCollections(): Promise<EditorialCollection[]> {
    try {
      const res = await fetch('/api/editorial-collections');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return EDITORIAL_COLLECTIONS;
  },

  async getEditorialCollectionById(id: string): Promise<(EditorialCollection & { products?: Product[] }) | undefined> {
    try {
      const res = await fetch(`/api/editorial-collections/${id}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    const found = EDITORIAL_COLLECTIONS.find(c => c.id === id);
    if (!found) return undefined;
    const colProducts = INITIAL_PRODUCTS.filter(p => {
      if (found.element === 'aaru') return p.element === 'aaru';
      return p.element === found.element;
    });
    return {
      ...found,
      products: colProducts
    };
  },

  async getShopTheLooks(): Promise<ShopTheLookEnsemble[]> {
    try {
      const res = await fetch('/api/shop-the-look');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return SHOP_THE_LOOKS;
  },

  async getShopTheLookById(id: string): Promise<ShopTheLookEnsemble | undefined> {
    try {
      const res = await fetch(`/api/shop-the-look/${id}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fallback
    }
    return SHOP_THE_LOOKS.find(l => l.id === id);
  },

  // Authentication API Methods
  async getAuthStatus(): Promise<AuthStatusResult> {
    try {
      const res = await fetch('/api/auth/status');
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Ignore
    }
    return {
      success: true,
      hasTwilioConfigured: false,
      message: 'Running in development mode (Twilio credentials pending in environment variables)'
    };
  },

  async sendOtp(phoneNumber: string, extra?: { fullName?: string; email?: string }): Promise<SendOtpResult> {
    const res = await fetch('/api/auth/send-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneNumber, ...extra })
    });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.message || 'Failed to dispatch verification SMS');
    }
    return json;
  },

  async verifyOtp(phoneNumber: string, code: string, extra?: { fullName?: string; email?: string }): Promise<VerifyOtpResult> {
    const res = await fetch('/api/auth/verify-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneNumber, code, ...extra })
    });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.message || 'Verification failed. Please check code and try again.');
    }
    if (json.token) {
      localStorage.setItem('aaru_auth_token', json.token);
      localStorage.setItem('aaru_auth_user', JSON.stringify(json.user));
    }
    return json;
  },

  async googleAuth(profile: { email: string; name: string; picture?: string; googleId?: string }): Promise<VerifyOtpResult> {
    const res = await fetch('/api/auth/google', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile)
    });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.message || 'Google authentication failed');
    }
    if (json.token) {
      localStorage.setItem('aaru_auth_token', json.token);
      localStorage.setItem('aaru_auth_user', JSON.stringify(json.user));
    }
    return json;
  },

  async getCurrentAuth(): Promise<{ user: UserProfile; token: string } | null> {
    const token = localStorage.getItem('aaru_auth_token');
    if (!token) return null;

    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const json = await res.json();
        return { user: json.user, token: json.token };
      }
    } catch {
      // If server check fails, check local cached user
    }

    const cachedUser = localStorage.getItem('aaru_auth_user');
    if (cachedUser) {
      try {
        return { user: JSON.parse(cachedUser), token };
      } catch {
        // Invalid json
      }
    }
    return null;
  },

  async logout(): Promise<void> {
    const token = localStorage.getItem('aaru_auth_token');
    if (token) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch {
        // Ignore network errors on logout
      }
    }
    localStorage.removeItem('aaru_auth_token');
    localStorage.removeItem('aaru_auth_user');
  }
};
