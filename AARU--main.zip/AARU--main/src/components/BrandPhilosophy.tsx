import React from 'react';
import { Sparkles, Mountain, Droplets, Flame, Wind, Globe, ArrowRight } from 'lucide-react';

interface BrandPhilosophyProps {
  onSelectElement: (element: string) => void;
  onReadFullStory: () => void;
}

export const BrandPhilosophy: React.FC<BrandPhilosophyProps> = ({
  onSelectElement,
  onReadFullStory
}) => {
  const elements = [
    {
      id: 'earth',
      num: 'ELEMENT 01',
      telugu: 'పృథ్వి',
      title: 'Earth — Stature & Heritage',
      description: 'The unyielding bedrock of royal tradition. Heavy weighted silks dyed in mineral terracotta and clay.',
      fabricTag: 'Double-warp Kanchipuram Brocade',
      icon: Mountain,
      iconColor: 'text-[#A0A5B5]',
      isSixth: false
    },
    {
      id: 'water',
      num: 'ELEMENT 02',
      telugu: 'జలం',
      title: 'Water — Flow & Grace',
      description: 'Fluidity that mirrors the Krishna and Godavari rivers. Rippling organza woven with liquid silver resham.',
      fabricTag: 'Chanderi Tissue & Freshwater Pearls',
      icon: Droplets,
      iconColor: 'text-[#7EAEE6]',
      isSixth: false
    },
    {
      id: 'fire',
      num: 'ELEMENT 03',
      telugu: 'అగ్ని',
      title: 'Fire — Solar Sovereignty',
      description: 'The sacred ceremonial flame. Bullion wire embroidery and crimson weaves commanding unconditional presence.',
      fabricTag: 'Raw Matka Silk & Heavy Zardozi',
      icon: Flame,
      iconColor: 'text-[#E5A869]',
      isSixth: false
    },
    {
      id: 'air',
      num: 'ELEMENT 04',
      telugu: 'వాయువు',
      title: 'Air — Breath & Liberty',
      description: 'The featherlight breath of peace silk. Hand-chikankari shadow stitches undulating with the gentlest breeze.',
      fabricTag: 'Cruelty-Free Ahimsa Silk',
      icon: Wind,
      iconColor: 'text-[#8DE2C8]',
      isSixth: false
    },
    {
      id: 'ether',
      num: 'ELEMENT 05',
      telugu: 'ఆకాశం',
      title: 'Space — Infinite Cosmos',
      description: 'The midnight sky unfurling into eternity. Starfield bullion embroidery set upon nocturnal indigo velvet.',
      fabricTag: 'Italian Silk Velvet & Gold Filigree',
      icon: Globe,
      iconColor: 'text-[#B89FE6]',
      isSixth: false
    },
    {
      id: 'aaru',
      num: 'ELEMENT 06',
      telugu: 'ఆరు',
      title: 'The Sixth Element — Soul',
      description: 'The transcendent presence that unites matter and memory. When forty days of human prayer and rhythmic loom work breathe life into cloth.',
      fabricTag: '24K Gold Zari & Telia Rumal Double-Ikat',
      icon: Sparkles,
      iconColor: 'text-[#D4AF37]',
      isSixth: true
    }
  ];

  return (
    <section id="the-sixth-element-story" className="py-24 bg-[#07080B] text-[#FAF7F0] border-b border-[#1C1F2B] relative overflow-hidden">
      {/* Background Subtle Gradient Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-[#111420]/40 via-[#07080B] to-[#07080B] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Top Centered Brand Philosophy Header (Image 2) */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          {/* Pill Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#11141E] border border-[#D4AF37]/40 text-xs uppercase tracking-[0.25em] text-[#D4AF37] mb-6 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>THE BRAND PHILOSOPHY</span>
          </div>

          {/* Heading */}
          <h2 className="font-cormorant text-3xl sm:text-5xl lg:text-5xl font-light text-[#FAF7F0] tracking-wide leading-tight mb-2">
            The Sixth Element:
          </h2>
          <div className="font-cormorant italic text-3xl sm:text-5xl lg:text-5xl text-[#D4AF37] font-normal tracking-wide mb-6">
            <span className="font-telugu not-italic font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FFF2CC] via-[#D4AF37] to-[#C5A059] mr-3">
              ఆరు
            </span>
            — When Matter Meets Soul
          </div>

          {/* Subtitle */}
          <p className="text-sm sm:text-base text-[#9B978F] font-light leading-relaxed">
            Ancient philosophy teaches that all physical existence is born of five primal elements: Earth, Water, Fire, Air, and Space. At AARU, we manifest the transcendent Sixth — the sacred synergy of artisan devotion, generational heritage, and the wearer&apos;s sovereign presence.
          </p>
        </div>

        {/* 6 Elements Grid: 3 columns x 2 rows (Image 2) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {elements.map((elem) => {
            const IconComponent = elem.icon;
            return (
              <div
                key={elem.id}
                onClick={() => onSelectElement(elem.id)}
                className={`group cursor-pointer rounded-xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 relative ${
                  elem.isSixth
                    ? 'border-2 border-[#D4AF37] bg-gradient-to-b from-[#18150E] via-[#0E1017] to-[#0A0C12] shadow-[0_0_35px_rgba(212,175,55,0.18)] hover:shadow-[0_0_45px_rgba(212,175,55,0.28)]'
                    : 'border border-[#1E2332] hover:border-[#343B52] bg-[#0C0E15]/90 hover:bg-[#10131D]'
                }`}
              >
                <div>
                  {/* Card Header: Icon Circle & Element Number / Telugu script */}
                  <div className="flex items-center justify-between mb-6">
                    <div
                      className={`w-11 h-11 rounded-full flex items-center justify-center border transition-transform duration-300 group-hover:scale-110 ${
                        elem.isSixth
                          ? 'bg-[#262012] border-[#D4AF37]/60'
                          : 'bg-[#131622] border-[#252B3E]'
                      }`}
                    >
                      <IconComponent className={`w-4 h-4 ${elem.iconColor}`} />
                    </div>

                    <div className="text-right">
                      <div
                        className={`font-telugu text-sm font-semibold ${
                          elem.isSixth ? 'text-[#D4AF37]' : 'text-[#FAF7F0]'
                        }`}
                      >
                        {elem.telugu}
                      </div>
                      <div className="text-[9px] uppercase tracking-[0.25em] text-[#696F82] font-mono mt-0.5">
                        {elem.num}
                      </div>
                    </div>
                  </div>

                  {/* Element Title */}
                  <h3
                    className={`font-cormorant text-xl font-medium mb-3 transition-colors ${
                      elem.isSixth ? 'text-[#FAF7F0]' : 'text-[#FAF7F0] group-hover:text-[#D4AF37]'
                    }`}
                  >
                    {elem.title}
                  </h3>

                  {/* Element Description */}
                  <p className="text-xs text-[#8A8F9E] font-light leading-relaxed mb-6">
                    {elem.description}
                  </p>
                </div>

                {/* Card Footer: Fabric Tag & Curate Action */}
                <div className="border-t border-[#1C202E] pt-4 flex items-center justify-between text-xs">
                  <span
                    className={`text-[11px] font-medium tracking-wide ${
                      elem.isSixth ? 'text-[#D4AF37]' : 'text-[#A09A8E]'
                    }`}
                  >
                    {elem.fabricTag}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectElement(elem.id);
                    }}
                    className={`flex items-center gap-1 text-xs font-medium transition-all group-hover:translate-x-0.5 ${
                      elem.isSixth
                        ? 'text-[#D4AF37] hover:text-[#FFF0C2]'
                        : 'text-[#FAF7F0] hover:text-[#D4AF37]'
                    }`}
                  >
                    <span>Curate</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Master Artisan Sri Ramanayya Quote Card (Image 3) */}
        <div className="mt-14 rounded-2xl border border-[#232738] bg-[#0B0D14] p-7 sm:p-10 flex flex-col md:flex-row items-center gap-6 sm:gap-10 relative overflow-hidden shadow-[0_15px_40px_rgba(0,0,0,0.6)]">
          {/* Subtle gold glow behind card */}
          <div className="absolute -left-20 -bottom-20 w-64 h-64 rounded-full bg-[#D4AF37]/5 blur-3xl pointer-events-none"></div>

          {/* Master Weaver Circular Portrait */}
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-2 border-[#D4AF37]/60 flex-shrink-0 shadow-[0_0_25px_rgba(0,0,0,0.7)] relative">
            <img
              src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=400&auto=format&fit=crop"
              alt="Master Artisan Sri Ramanayya"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center grayscale contrast-125 hover:grayscale-0 transition-all duration-700"
            />
          </div>

          {/* Quote & Credentials */}
          <div className="flex-1 text-center md:text-left">
            <blockquote className="font-cormorant italic text-lg sm:text-2xl text-[#E8E2D5] leading-relaxed mb-4">
              &ldquo;The loom is not merely wood and thread. When a master weaver works for seventy-two days, his pulse becomes the rhythm of the warp. That is &lsquo;<span className="font-telugu not-italic font-semibold text-[#D4AF37]">ఆరు</span>&rsquo; — the soul you feel the moment silk touches your skin.&rdquo;
            </blockquote>

            <div>
              <div className="font-cinzel text-xs tracking-[0.22em] text-[#D4AF37] font-bold uppercase">
                MASTER ARTISAN SRI RAMANAYYA
              </div>
              <div className="text-[11px] text-[#848796] font-light mt-1 tracking-wider">
                Fifth-Generation Double-Ikat &amp; Zari Custodian, Pochampally Weave Sanctuary
              </div>
            </div>
          </div>

          {/* Read Full Story Button */}
          <div className="flex-shrink-0 mt-4 md:mt-0">
            <button
              onClick={onReadFullStory}
              className="whitespace-nowrap px-6 py-3 rounded-full hover:bg-[#141724] border border-[#303548] hover:border-[#D4AF37] text-xs font-medium tracking-[0.2em] uppercase text-[#FAF7F0] hover:text-[#D4AF37] transition-all flex items-center gap-2 group shadow-sm"
            >
              <span>READ FULL ATELIER CHRONICLE</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37] group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
