import React from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, Sparkles, Gift, ShieldCheck, Truck, RotateCcw, CheckCircle2 } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, qty: number) => void;
  onRemoveItem: (index: number) => void;
  onUpdateSize?: (index: number, size: string) => void;
  onProceedCheckout: () => void;
  currency?: 'INR' | 'USD';
  giftPackaging: boolean;
  onToggleGiftPackaging: (val: boolean) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onUpdateSize,
  onProceedCheckout,
  currency = 'INR',
  giftPackaging,
  onToggleGiftPackaging
}) => {
  if (!isOpen) return null;

  const FREE_SHIPPING_THRESHOLD = 5000;
  const subtotal = items.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  const isFreeShippingUnlocked = subtotal >= FREE_SHIPPING_THRESHOLD;
  const amountToFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const shippingProgress = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100));

  const formattedSubtotal = `₹${subtotal.toLocaleString('en-IN')}`;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0E1016] border-l border-[#2E2C26] text-[#FAF7F0] shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-5 bg-[#141620] border-b border-[#252838] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
              <div>
                <h2 className="font-cinzel text-base font-bold text-[#FAF7F0] tracking-wider uppercase">
                  Shopping Cart
                </h2>
                <div className="text-[10px] text-[#A09A8E]">
                  {items.length} {items.length === 1 ? 'Item' : 'Items'}
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-[#1E2130] text-[#A09A8E] hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Delivery Cue: Free shipping over ₹5000 Progress / Status Banner */}
          {items.length > 0 && (
            <div className="px-5 py-3 bg-[#11131C] border-b border-[#212536]">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#D4AF37]" />
                  {isFreeShippingUnlocked ? (
                    <span className="text-emerald-400 font-medium text-[11px] flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      Free Delivery Unlocked!
                    </span>
                  ) : (
                    <span className="text-[#C8C2B7] text-[11px]">
                      Add <strong className="text-[#FAF7F0]">₹{amountToFreeShipping.toLocaleString('en-IN')}</strong> for Free Shipping
                    </span>
                  )}
                </div>
                <span className="text-[10px] uppercase font-mono text-[#D4AF37] font-semibold">
                  {isFreeShippingUnlocked ? 'Free Over ₹5,000' : `${shippingProgress}%`}
                </span>
              </div>
              <div className="w-full h-1 bg-[#1F2332] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#C5A059] to-[#D4AF37] transition-all duration-300 rounded-full"
                  style={{ width: `${shippingProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
            {items.length === 0 ? (
              <div className="text-center py-20 text-[#7A756C] space-y-3">
                <ShoppingBag className="w-12 h-12 mx-auto opacity-30 text-[#D4AF37]" />
                <p className="text-sm font-light">Your shopping cart is empty.</p>
                <button
                  onClick={onClose}
                  className="mt-2 text-xs uppercase tracking-widest text-[#D4AF37] underline underline-offset-4 hover:text-white transition-colors cursor-pointer"
                >
                  Browse Our Collections
                </button>
              </div>
            ) : (
              items.map((item, idx) => {
                const itemTotal = item.product.price * item.quantity;
                const formattedItemPrice = `₹${itemTotal.toLocaleString('en-IN')}`;

                return (
                  <div
                    key={`${item.product.id}-${item.size}-${idx}`}
                    className="p-3.5 bg-[#13151D] border border-[#252838] rounded-sm flex gap-3 relative group"
                  >
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-20 h-24 object-cover rounded-sm border border-[#2D3042]"
                    />

                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="text-xs font-semibold text-[#FAF7F0] truncate font-cinzel">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(idx)}
                            className="text-[#7A756C] hover:text-rose-400 p-1 transition-colors"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Variant Details & Size Switcher */}
                        <div className="mt-1 flex items-center gap-2 flex-wrap text-[11px]">
                          <span className="text-[#A09A8E]">Variant:</span>
                          {onUpdateSize && item.product.sizes.length > 1 ? (
                            <select
                              value={item.size}
                              onChange={e => onUpdateSize(idx, e.target.value)}
                              className="bg-[#1C1F2B] text-[#D4AF37] border border-[#2E3346] rounded px-1.5 py-0.5 text-[10px] focus:border-[#D4AF37] outline-none"
                            >
                              {item.product.sizes.map(sz => (
                                <option key={sz} value={sz}>
                                  {sz}
                                </option>
                              ))}
                            </select>
                          ) : (
                            <span className="px-1.5 py-0.5 bg-[#1B1E2B] rounded text-[#D4AF37] text-[10px] border border-[#2B3044]">
                              {item.size}
                            </span>
                          )}
                          <span className="text-[#5F6375]">•</span>
                          <span className="text-[#8E92A4] text-[10px] truncate">{item.product.fabric}</span>
                        </div>

                        {item.monogram && (
                          <div className="text-[10px] font-mono text-[#D4AF37] mt-1 flex items-center gap-1">
                            <Sparkles className="w-2.5 h-2.5" />
                            <span>Monogram: &ldquo;{item.monogram}&rdquo;</span>
                          </div>
                        )}

                        {item.customMeasurements && (
                          <div className="text-[9px] text-[#A09A8E] mt-0.5 italic">
                            Custom Measurements Attached
                          </div>
                        )}
                      </div>

                      {/* Quantity Controls & Line Subtotal */}
                      <div className="flex items-center justify-between pt-2 border-t border-[#1F2230]">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onUpdateQuantity(idx, Math.max(1, item.quantity - 1))}
                            className="w-5 h-5 rounded bg-[#1C1F2B] hover:bg-[#282D3E] text-xs flex items-center justify-center text-[#FAF7F0] transition-colors"
                            title="Decrease quantity"
                          >
                            -
                          </button>
                          <span className="text-xs font-mono font-medium w-4 text-center">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(idx, item.quantity + 1)}
                            className="w-5 h-5 rounded bg-[#1C1F2B] hover:bg-[#282D3E] text-xs flex items-center justify-center text-[#FAF7F0] transition-colors"
                            title="Increase quantity"
                          >
                            +
                          </button>
                        </div>

                        <div className="text-xs font-mono font-bold text-[#D4AF37]">
                          {formattedItemPrice}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}

            {/* Gift Box */}
            {items.length > 0 && (
              <div className="p-3 bg-[#171924] border border-[#2B2F42] rounded-sm flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Gift className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <div>
                    <div className="text-xs font-medium text-[#FAF7F0]">
                      Complimentary Gift Box
                    </div>
                    <div className="text-[10px] text-[#A09A8E]">
                      Includes premium gift packaging and personalized message card
                    </div>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={giftPackaging}
                  onChange={e => onToggleGiftPackaging(e.target.checked)}
                  className="rounded border-[#3A3832] text-[#D4AF37] focus:ring-0 cursor-pointer accent-[#D4AF37] w-4 h-4"
                />
              </div>
            )}

            {/* Policy & Trust Cues */}
            {items.length > 0 && (
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="p-2.5 rounded bg-[#10121A] border border-[#1E2130] flex items-center gap-2">
                  <RotateCcw className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                  <span className="text-[10px] text-[#C8C2B7]">7-Day Returns & Exchanges</span>
                </div>
                <div className="p-2.5 rounded bg-[#10121A] border border-[#1E2130] flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                  <span className="text-[10px] text-[#C8C2B7]">Authentic Handloom Certified</span>
                </div>
              </div>
            )}
          </div>

          {/* Checkout Footer */}
          {items.length > 0 && (
            <div className="p-5 bg-[#141620] border-t border-[#252838] space-y-4">
              <div className="space-y-1.5 text-xs text-[#A09A8E]">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-mono text-[#FAF7F0]">{formattedSubtotal}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery:</span>
                  <span className="text-emerald-400 uppercase font-mono text-[11px] font-semibold">
                    {isFreeShippingUnlocked ? 'Free' : '₹500'}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-[#FAF7F0] pt-2 border-t border-[#22242E]">
                  <span>Total:</span>
                  <span className="font-mono text-base text-[#D4AF37]">
                    {formattedSubtotal}
                  </span>
                </div>
              </div>

              <button
                onClick={onProceedCheckout}
                className="w-full py-3.5 bg-gradient-to-r from-[#D4AF37] via-[#DFBF58] to-[#C5A059] text-black font-semibold text-xs uppercase tracking-[0.25em] rounded-sm hover:opacity-95 transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(212,175,55,0.3)] cursor-pointer"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-[#A09A8E]">
                <ShieldCheck className="w-3 h-3 text-[#D4AF37]" />
                <span>Secure 256-bit Checkout</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
