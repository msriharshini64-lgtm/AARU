import React, { useState } from 'react';
import { Heart, ShoppingBag, Trash2, ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { Product, CartItem } from '../types';

interface WishlistPageProps {
  wishlistIds: string[];
  allProducts: Product[];
  currency: 'INR' | 'USD';
  onRemoveFromWishlist: (productId: string) => void;
  onAddToCart?: (item: CartItem) => void;
  onMoveToCart?: (productId: string, size?: string) => void;
  onMoveAllToCart?: () => void;
  onOpenCart?: () => void;
  onSelectProduct: (product: Product) => void;
  onContinueShopping?: () => void;
  onNavigateHome?: () => void;
  onNavigateCatalogue?: () => void;
  formatPrice?: (priceINR: number) => string;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({
  wishlistIds,
  allProducts,
  currency,
  onRemoveFromWishlist,
  onAddToCart,
  onMoveToCart,
  onMoveAllToCart,
  onOpenCart,
  onSelectProduct,
  onContinueShopping,
  onNavigateHome,
  onNavigateCatalogue,
  formatPrice: propFormatPrice
}) => {
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({});
  const [addedIds, setAddedIds] = useState<Record<string, boolean>>({});

  const wishlistedProducts = allProducts.filter(p => wishlistIds.includes(p.id));

  const formatPrice = propFormatPrice || ((priceINR: number) => {
    if (currency === 'USD') {
      return `$${Math.round(priceINR / 83).toLocaleString()}`;
    }
    return `₹${priceINR.toLocaleString('en-IN')}`;
  });

  const handleContinue = onContinueShopping || onNavigateCatalogue || onNavigateHome || (() => {});

  const handleSizeChange = (productId: string, size: string) => {
    setSelectedSizes(prev => ({ ...prev, [productId]: size }));
  };

  const handleAddToCartClick = (product: Product) => {
    const size = selectedSizes[product.id] || product.sizes[0] || 'Standard';
    if (onMoveToCart) {
      onMoveToCart(product.id, size);
    } else if (onAddToCart) {
      onAddToCart({
        product,
        size,
        quantity: 1
      });
    }

    setAddedIds(prev => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedIds(prev => ({ ...prev, [product.id]: false }));
    }, 2000);
  };

  const handleMoveAllToCartClick = () => {
    if (onMoveAllToCart) {
      onMoveAllToCart();
    } else if (onAddToCart) {
      wishlistedProducts.forEach(product => {
        const size = selectedSizes[product.id] || product.sizes[0] || 'Standard';
        onAddToCart({
          product,
          size,
          quantity: 1
        });
      });
    }
    if (onOpenCart) onOpenCart();
  };

  return (
    <div className="min-h-screen bg-[#0A0B0E] text-[#FAF7F0] pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Navigation Breadcrumb / Back button */}
        <div className="mb-6">
          <button
            onClick={handleContinue}
            className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#A09A8E] hover:text-[#D4AF37] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Continue Shopping</span>
          </button>
        </div>

        {/* Header Title Section */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#212432] mb-8">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#171924] border border-rose-500/40 flex items-center justify-center">
                <Heart className="w-5 h-5 text-rose-400 fill-rose-400/20" />
              </div>
              <h1 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#FAF7F0] tracking-wide">
                Wishlist
              </h1>
            </div>
            <p className="text-sm text-[#A09A8E] mt-2">
              {wishlistedProducts.length} {wishlistedProducts.length === 1 ? 'item' : 'items'} saved for later
            </p>
          </div>

          {wishlistedProducts.length > 0 && (
            <div className="flex items-center gap-3">
              <button
                onClick={handleMoveAllToCartClick}
                className="px-4 py-2.5 rounded bg-[#1A1D2A] hover:bg-[#D4AF37] text-[#D4AF37] hover:text-black border border-[#D4AF37]/50 hover:border-[#D4AF37] text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Move All to Cart</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              {onOpenCart && (
                <button
                  onClick={onOpenCart}
                  className="px-4 py-2.5 rounded bg-[#D4AF37] hover:bg-[#e0bb42] text-black text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>View Cart</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Empty State */}
        {wishlistedProducts.length === 0 ? (
          <div className="text-center py-24 bg-[#11131B] border border-[#212432] rounded-lg p-8 max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-full bg-[#181B26] border border-[#2B3042] flex items-center justify-center mx-auto mb-4">
              <Heart className="w-8 h-8 text-[#D4AF37]/40" />
            </div>
            <h2 className="font-cinzel text-lg font-semibold text-[#FAF7F0] mb-2">
              Your Wishlist is Empty
            </h2>
            <p className="text-sm text-[#8E92A4] mb-6">
              You haven&apos;t saved any items yet. Browse our clothing collections and tap the heart icon on any product to save your favorites here.
            </p>
            <button
              onClick={handleContinue}
              className="px-6 py-3 rounded bg-[#D4AF37] hover:bg-[#e0bb42] text-black font-semibold text-xs uppercase tracking-widest transition-all cursor-pointer shadow-lg"
            >
              Browse All Clothing
            </button>
          </div>
        ) : (
          /* Products Grid */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {wishlistedProducts.map(product => {
              const isAdded = addedIds[product.id];
              const activeSize = selectedSizes[product.id] || product.sizes[0] || 'Standard';

              return (
                <div
                  key={product.id}
                  className="bg-[#11131B] border border-[#212432] hover:border-[#383E54] rounded-lg overflow-hidden flex flex-col transition-all group shadow-md"
                >
                  {/* Product Image */}
                  <div
                    onClick={() => onSelectProduct(product)}
                    className="relative aspect-[3/4] overflow-hidden bg-[#171A24] cursor-pointer"
                  >
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        onRemoveFromWishlist(product.id);
                      }}
                      className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 hover:bg-rose-950/80 border border-white/20 hover:border-rose-500/50 text-[#FAF7F0] hover:text-rose-400 flex items-center justify-center transition-all cursor-pointer backdrop-blur-sm"
                      title="Remove from Wishlist"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Product Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="text-[11px] text-[#A09A8E] uppercase tracking-wider mb-1">
                        {product.fabric} · {product.weaveOrigin}
                      </div>
                      <h3
                        onClick={() => onSelectProduct(product)}
                        className="font-cinzel text-base font-semibold text-[#FAF7F0] hover:text-[#D4AF37] line-clamp-1 cursor-pointer transition-colors"
                      >
                        {product.name}
                      </h3>
                      <div className="text-base font-mono font-bold text-[#D4AF37] mt-2">
                        {formatPrice(product.price)}
                      </div>

                      {/* Size Selector */}
                      <div className="mt-3 flex items-center gap-2">
                        <label className="text-xs text-[#8E92A4]">Size:</label>
                        <select
                          value={activeSize}
                          onChange={e => handleSizeChange(product.id, e.target.value)}
                          className="bg-[#171A24] border border-[#2B3042] text-[#FAF7F0] text-xs rounded px-2 py-1 focus:border-[#D4AF37] outline-none cursor-pointer flex-1"
                        >
                          {product.sizes.map(s => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="mt-4 pt-3 border-t border-[#212432] flex items-center gap-2">
                      <button
                        onClick={() => handleAddToCartClick(product)}
                        className={`flex-1 py-2 px-3 rounded text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                          isAdded
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[#1D202D] hover:bg-[#D4AF37] text-[#FAF7F0] hover:text-black border border-[#2B3042] hover:border-[#D4AF37]'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-white" />
                            <span>Added to Cart</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Add to Cart</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => onRemoveFromWishlist(product.id)}
                        className="p-2 rounded bg-[#171A24] hover:bg-rose-950/40 border border-[#2B3042] hover:border-rose-500/40 text-[#8E92A4] hover:text-rose-400 transition-all cursor-pointer"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
