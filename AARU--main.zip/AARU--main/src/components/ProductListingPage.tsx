import React, { useState, useEffect } from 'react';
import {
  SlidersHorizontal,
  ChevronDown,
  X,
  Sparkles,
  RotateCcw,
  ArrowUpDown,
  Search,
  CheckCircle2,
  Clock,
  Layers,
  Flame,
  Compass,
  Droplets,
  Wind,
  Globe
} from 'lucide-react';
import { Product, CatalogueFilterState, SearchFacets } from '../types';
import { ProductCard } from './ProductCard';
import { CatalogueFilterSidebar } from './CatalogueFilterSidebar';
import { ELEMENT_METADATA } from '../data/mockData';

interface ProductListingPageProps {
  products: Product[];
  facets: SearchFacets | null;
  currency: 'INR' | 'USD';
  filters: CatalogueFilterState;
  onFilterChange: (newFilters: Partial<CatalogueFilterState>) => void;
  onResetFilters: () => void;
  isWishlisted: (id: string) => boolean;
  onToggleWishlist: (productId: string) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, size?: string) => void;
  onWhatsAppInquiry: (product: Product) => void;
  onOpenGlobalSearch: () => void;
}

const ELEMENT_HERO_DESCRIPTIONS: Record<string, { title: string; telugu: string; desc: string }> = {
  all: {
    title: 'The Sovereign Handloom Registry',
    telugu: 'సమగ్ర చేనేత భాండాగారం',
    desc: 'Bespoke handloom heirlooms woven on traditional pit and jacquard looms across the historic textile clusters of the subcontinent.'
  },
  aaru: {
    title: 'The Sixth Element (ఆరు)',
    telugu: 'ఆరు - ఆరవ తత్వం: సృష్టి & జీవం',
    desc: 'The living soul of the master artisan. Pure 24k Tested Gilt Zari drapes requiring up to 1,200 hours of single-weaver devotion.'
  },
  ether: {
    title: 'Akasha (Ether / Space)',
    telugu: 'ఆకాశ తత్వం: విశ్వాంతరాళం',
    desc: 'Midnight cosmic velvets, star-clustered real silver Zardozi, and whisper-sheer organzas echoing celestial tranquility.'
  },
  fire: {
    title: 'Agni (Fire)',
    telugu: 'అగ్ని తత్వం: తేజస్సు',
    desc: 'Blazing Kadwa brocades, molten gold zari borders, and imperial vermilion silks celebrating auspicious ritual fire.'
  },
  water: {
    title: 'Jala (Water)',
    telugu: 'జల తత్వం: ప్రవాహం',
    desc: 'Weightless Uppada Jamdani weaves with serpentine fluid drapes replicating the gentle ripples of sacred riverbeds.'
  },
  earth: {
    title: 'Prithvi (Earth)',
    telugu: 'పృథ్వి తత్వం: స్థిరత్వం',
    desc: 'Rooted terra tones, double-ikat Pochampally geometries, and raw textured Matka silks honoring fertile mother soil.'
  },
  air: {
    title: 'Vayu (Air)',
    telugu: 'వాయు తత్వం: శ్వాస',
    desc: 'Feather-light Chanderi muslins and non-violent Ahimsa peace silks floating with the delicate cadence of a desert breeze.'
  }
};

const CATEGORY_NAMES: Record<string, string> = {
  saree: 'Heritage Sarees',
  sherwani: 'Regal Sherwanis',
  lehenga: 'Bridal Lehengas',
  'cape-gown': 'Celestial Cape-Gowns',
  kurta: 'Couture Kurta Sets',
  stole: 'Pashmina Stoles'
};

export const ProductListingPage: React.FC<ProductListingPageProps> = ({
  products,
  facets,
  currency,
  filters,
  onFilterChange,
  onResetFilters,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
  onWhatsAppInquiry,
  onOpenGlobalSearch
}) => {
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const activeCollectionKey = filters.collection || 'all';
  const heroInfo = ELEMENT_HERO_DESCRIPTIONS[activeCollectionKey] || ELEMENT_HERO_DESCRIPTIONS.all;

  // Compute active filter pills
  const activePills: { label: string; onRemove: () => void }[] = [];

  if (filters.category && filters.category !== 'all') {
    activePills.push({
      label: `Category: ${CATEGORY_NAMES[filters.category] || filters.category}`,
      onRemove: () => onFilterChange({ category: 'all' })
    });
  }

  if (filters.collection && filters.collection !== 'all') {
    activePills.push({
      label: `Realm: ${filters.collection.toUpperCase()}`,
      onRemove: () => onFilterChange({ collection: 'all' })
    });
  }

  if (filters.availability && filters.availability !== 'all') {
    activePills.push({
      label: filters.availability === 'in_stock' ? 'Ready to Ship' : 'Made to Order',
      onRemove: () => onFilterChange({ availability: 'all' })
    });
  }

  if (filters.minPrice !== undefined || filters.maxPrice !== undefined) {
    const minStr = filters.minPrice ? `₹${filters.minPrice.toLocaleString('en-IN')}` : '₹0';
    const maxStr = filters.maxPrice ? `₹${filters.maxPrice.toLocaleString('en-IN')}` : 'Any';
    activePills.push({
      label: `Price: ${minStr} - ${maxStr}`,
      onRemove: () => onFilterChange({ minPrice: undefined, maxPrice: undefined })
    });
  }

  filters.color?.forEach(c => {
    activePills.push({
      label: `Color: ${c}`,
      onRemove: () => onFilterChange({ color: filters.color?.filter(item => item !== c) })
    });
  });

  filters.fabric?.forEach(f => {
    activePills.push({
      label: `Fabric: ${f}`,
      onRemove: () => onFilterChange({ fabric: filters.fabric?.filter(item => item !== f) })
    });
  });

  filters.size?.forEach(s => {
    activePills.push({
      label: `Size: ${s}`,
      onRemove: () => onFilterChange({ size: filters.size?.filter(item => item !== s) })
    });
  });

  filters.occasion?.forEach(o => {
    activePills.push({
      label: `Occasion: ${o}`,
      onRemove: () => onFilterChange({ occasion: filters.occasion?.filter(item => item !== o) })
    });
  });

  return (
    <div id="product-listing-page" className="min-h-screen bg-[#07090F] text-[#FAF7F0] pb-24">
      {/* Top Curatorial Editorial Hero Banner */}
      <div className="relative border-b border-[#1A1D2B] bg-gradient-to-b from-[#0F121C] to-[#07090F] pt-8 pb-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-telugu text-sm sm:text-base text-[#D4AF37] font-semibold tracking-wider">
                {heroInfo.telugu}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]/50" />
              <span className="text-[11px] uppercase tracking-[0.25em] text-[#8E93A6] font-semibold">
                Haute Couture Registry
              </span>
            </div>

            <h1 className="font-cinzel text-2xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#FAF7F0] mb-3">
              {heroInfo.title}
            </h1>

            <p className="text-xs sm:text-sm text-[#A5AABF] font-light leading-relaxed">
              {heroInfo.desc}
            </p>
          </div>

          {/* Quick Collection Tabs Row */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
            {[
              { id: 'all', label: 'All Silhouettes' },
              { id: 'aaru', label: 'ఆరు (Sixth Element)' },
              { id: 'ether', label: 'Akasha' },
              { id: 'fire', label: 'Agni' },
              { id: 'water', label: 'Jala' },
              { id: 'earth', label: 'Prithvi' },
              { id: 'air', label: 'Vayu' }
            ].map(col => (
              <button
                key={col.id}
                onClick={() => onFilterChange({ collection: col.id })}
                className={`px-3 py-1.5 rounded-full text-xs uppercase tracking-wider font-semibold transition-all whitespace-nowrap ${
                  activeCollectionKey === col.id
                    ? 'bg-[#D4AF37] text-black shadow-md'
                    : 'bg-[#121522] text-[#9A9FB4] hover:text-[#FAF7F0] hover:bg-[#1C2030] border border-[#23273A]'
                }`}
              >
                {col.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main PLP Workspace: Sidebar + Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {/* Controls Bar: Results Count, Mobile Filter Button, Sorting Dropdown, Global Search shortcut */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#1A1D2B]">
          <div className="flex items-center gap-3">
            {/* Mobile Filter Drawer Trigger */}
            <button
              type="button"
              onClick={() => setMobileDrawerOpen(true)}
              className="lg:hidden px-4 py-2.5 rounded-sm bg-[#121522] hover:bg-[#1A1E2E] border border-[#2A3046] text-[#FAF7F0] text-xs font-semibold uppercase tracking-wider flex items-center gap-2 shadow-sm"
            >
              <SlidersHorizontal className="w-4 h-4 text-[#D4AF37]" />
              <span>Filter Silhouettes</span>
              {activePills.length > 0 && (
                <span className="w-5 h-5 rounded-full bg-[#D4AF37] text-black text-[11px] font-mono font-bold flex items-center justify-center">
                  {activePills.length}
                </span>
              )}
            </button>

            <div className="text-xs sm:text-sm text-[#8E93A6] font-mono">
              Displaying <span className="font-bold text-[#FAF7F0]">{products.length}</span> curated handloom silhouettes
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Search shortcut */}
            <button
              type="button"
              onClick={onOpenGlobalSearch}
              className="p-2 rounded-sm bg-[#111420] border border-[#23273A] text-[#9A9FB4] hover:text-[#FAF7F0] hover:border-[#D4AF37]/60 text-xs flex items-center gap-2 transition-colors"
              title="Search catalogue"
            >
              <Search className="w-4 h-4 text-[#D4AF37]" />
              <span className="hidden md:inline">Search Catalogue</span>
            </button>

            {/* Sorting Dropdown */}
            <div className="relative flex items-center">
              <span className="text-xs text-[#7B8094] uppercase tracking-wider mr-2 hidden sm:inline">Sort:</span>
              <div className="relative">
                <select
                  value={filters.sort || 'featured'}
                  onChange={e => onFilterChange({ sort: e.target.value as any })}
                  className="appearance-none bg-[#111420] border border-[#252A3C] hover:border-[#D4AF37]/50 focus:border-[#D4AF37] rounded px-3 py-2 pr-8 text-xs font-medium text-[#FAF7F0] focus:outline-none transition-colors cursor-pointer"
                >
                  <option value="featured">Curatorial Featured</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="hours-desc">Artisan Effort: Most Loom Hours</option>
                  <option value="newest">Limited Edition First</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-[#8A8F9E] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Active Filter Chips Bar */}
        {activePills.length > 0 && (
          <div className="py-3 flex items-center gap-2 flex-wrap border-b border-[#151824]">
            <span className="text-[11px] uppercase tracking-wider text-[#686D82] font-semibold mr-1">
              Active Filters:
            </span>

            {activePills.map((pill, i) => (
              <span
                key={i}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs bg-[#151928] border border-[#293046] text-[#E0DDD3]"
              >
                <span>{pill.label}</span>
                <button
                  type="button"
                  onClick={pill.onRemove}
                  className="text-[#8E93A6] hover:text-[#FAF7F0] p-0.5"
                  aria-label={`Remove ${pill.label}`}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}

            <button
              type="button"
              onClick={onResetFilters}
              className="text-xs text-[#D4AF37] hover:underline ml-1 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear All</span>
            </button>
          </div>
        )}

        {/* Layout Grid: Sidebar on Desktop + Products Grid */}
        <div className="flex gap-8 pt-6">
          {/* Desktop Filter Sidebar */}
          <CatalogueFilterSidebar
            filters={filters}
            facets={facets}
            currency={currency}
            onFilterChange={onFilterChange}
            onResetFilters={onResetFilters}
            totalResults={products.length}
            isMobileDrawerOpen={mobileDrawerOpen}
            onCloseMobileDrawer={() => setMobileDrawerOpen(false)}
          />

          {/* Product Cards Grid Area */}
          <div className="flex-1 min-w-0">
            {products.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {products.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    currency={currency}
                    isWishlisted={isWishlisted(product.id)}
                    onToggleWishlist={onToggleWishlist}
                    onQuickView={onQuickView}
                    onAddToCart={onAddToCart}
                    onWhatsAppInquiry={onWhatsAppInquiry}
                  />
                ))}
              </div>
            ) : (
              /* Designed Zero-Result Empty State */
              <div className="py-16 px-4 text-center rounded-lg border border-[#1E2333] bg-[#0A0D15] space-y-5">
                <div className="w-14 h-14 mx-auto rounded-full bg-[#141724] border border-[#282E42] flex items-center justify-center text-[#D4AF37]">
                  <SlidersHorizontal className="w-6 h-6 opacity-70" />
                </div>

                <div className="max-w-md mx-auto space-y-2">
                  <h3 className="font-cinzel text-xl font-bold text-[#FAF7F0]">
                    No Handloom Masterpieces Match This Refinement
                  </h3>
                  <p className="text-xs text-[#8E93A6] leading-relaxed">
                    Our handloom creations are woven in strict single-edition or limited capsule batches. Try relaxing one or more filters or explore our curations.
                  </p>
                </div>

                <div className="flex items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onResetFilters}
                    className="px-5 py-2.5 rounded-sm bg-[#D4AF37] hover:bg-[#E5C07B] text-black text-xs font-bold uppercase tracking-wider transition-colors shadow-md"
                  >
                    Reset All Filters
                  </button>
                  <button
                    type="button"
                    onClick={onOpenGlobalSearch}
                    className="px-5 py-2.5 rounded-sm bg-[#131726] hover:bg-[#1C2134] text-[#FAF7F0] border border-[#2B3146] text-xs font-bold uppercase tracking-wider transition-colors"
                  >
                    Open Global Search
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
