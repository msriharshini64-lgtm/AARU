import React from 'react';
import { ArrowRight, MessageCircle, ShieldCheck } from 'lucide-react';

interface HeroEditorialProps {
  onExploreClick: () => void;
  onNavigateReadyToShip?: () => void;
  onOpenConsultation: () => void;
}

export const HeroEditorial: React.FC<HeroEditorialProps> = ({
  onExploreClick,
  onNavigateReadyToShip,
  onOpenConsultation
}) => {
  return (
    <section className="relative min-h-[84vh] flex flex-col justify-center overflow-hidden bg-[#07080B] text-[#FAF7F0] border-b border-[#25231F]">
      {/* Background Editorial Visual Layer: Ivory Couture Bride against Dark Bokeh */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=2000&auto=format&fit=crop"
          alt="AARU Haute Couture - The Sixth Element"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-[center_28%] opacity-35 scale-100 transition-transform duration-[10000ms] hover:scale-105"
        />
        {/* Deep Obsidian Gradients for Razor-Sharp Readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#060709] via-[#060709]/70 to-[#060709]/50"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-[#060709]/60 to-[#060709]"></div>
      </div>

      {/* Center Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 sm:px-8 lg:px-12 py-24 text-center flex flex-col items-center">
        {/* Big Headline */}
        <h1 className="font-cormorant text-4xl sm:text-6xl lg:text-7xl font-light tracking-normal text-[#FAF7F0] leading-tight mb-2">
          Beyond the Five Elements Lies
        </h1>
        <div className="font-cormorant italic text-4xl sm:text-6xl lg:text-7xl text-[#D4AF37] font-normal tracking-wide mb-6">
          The Transcendent Sixth
        </div>

        {/* Subtitle Paragraph */}
        <p className="text-sm sm:text-base text-[#C5C0B5] max-w-2xl mx-auto font-light leading-relaxed mb-10">
          AARU (ఆరు) unites sacred Indian handloom traditions with royal Deccan master tailoring. Hand-hewn in certified 24-karat electroplated zari bullion, organic Telangana silks, and master-heirloom drapes.
        </p>

        {/* Call-To-Action Pill Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-5">
          {/* Button 1: Solid Gold */}
          <button
            onClick={onExploreClick}
            className="px-8 py-3.5 rounded-full bg-[#E5C07B] hover:bg-[#D4AF37] text-[#0A0B0E] font-semibold text-xs tracking-[0.2em] uppercase transition-all shadow-[0_0_25px_rgba(212,175,55,0.3)] flex items-center gap-2.5 whitespace-nowrap group"
          >
            <span>EXPLORE HAUTE COUTURE</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Button 2: Ready to Ship Vault */}
          {onNavigateReadyToShip && (
            <button
              onClick={onNavigateReadyToShip}
              className="px-7 py-3.5 rounded-full bg-[#10121A]/90 hover:bg-[#181B26] border border-[#D4AF37]/60 text-[#FAF7F0] hover:text-[#D4AF37] text-xs tracking-[0.2em] uppercase transition-all flex items-center gap-2 whitespace-nowrap"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>READY TO SHIP VAULT</span>
            </button>
          )}

          {/* Button 3: Atelier WhatsApp Consult */}
          <button
            onClick={onOpenConsultation}
            className="px-7 py-3.5 rounded-full bg-[#0B1710]/90 hover:bg-[#112419] border border-emerald-600/70 text-emerald-400 hover:text-emerald-300 text-xs tracking-[0.2em] uppercase transition-all flex items-center gap-2 whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4 text-emerald-400" />
            <span>ATELIER WHATSAPP CONSULT</span>
          </button>
        </div>
      </div>
    </section>
  );
};
