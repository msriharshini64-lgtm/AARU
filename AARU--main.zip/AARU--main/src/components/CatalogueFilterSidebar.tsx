import React, { useState } from 'react';
import {
  X,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  SlidersHorizontal,
  Check,
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';
import { CatalogueFilterState, SearchFacets } from '../types';

interface CatalogueFilterSidebarProps {
  filters: CatalogueFilterState;
  facets: SearchFacets | null;
  currency: 'INR' | 'USD';
  onFilterChange: (newFilters: Partial<CatalogueFilterState>) => void;
  onResetFilters: () => void;
  totalResults: number;
  // Drawer props for mobile
  isMobileDrawerOpen?: boolean;
  onCloseMobileDrawer?: () => void;
}

export const CatalogueFilterSidebar: React.FC<CatalogueFilterSidebarProps> = ({
  filters,
  facets,
  currency,
  onFilterChange,
  onResetFilters,
  totalResults,
  isMobileDrawerOpen = false,
  onCloseMobileDrawer
}) => {
  // Collapsible section states for desktop & mobile
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    category: true,
    price: true,
    availability: true,
    color: true,
    fabric: true,
    size: true,
    occasion: true,
    collection: false
  });

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  // Helper to toggle array filter elements
  const toggleArrayFilter = (field: 'color' | 'fabric' | 'size' | 'occasion', value: string) => {
    const currentList = filters[field] || [];
    const exists = currentList.includes(value);
    const updated = exists
      ? currentList.filter(item => item !== value)
      : [...currentList, value];
    onFilterChange({ [field]: updated });
  };

  // Active filter count calculator
  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.category && filters.category !== 'all') count++;
    if (filters.collection && filters.collection !== 'all') count++;
    if (filters.availability && filters.availability !== 'all') count++;
    if (filters.minPrice !== undefined || filters.maxPrice !== undefined) count++;
    count += (filters.color?.length || 0);
    count += (filters.fabric?.length || 0);
    count += (filters.size?.length || 0);
    count += (filters.occasion?.length || 0);
    return count;
  };

  const activeCount = getActiveFilterCount();

  const renderFilterContent = () => (
    <div className="space-y-6 text-sm text-[#FAF7F0]">
      {/* Header with Title & Reset Button */}
      <div className="flex items-center justify-between pb-4 border-b border-[#212536]">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-[#D4AF37]" />
          <h3 className="font-cinzel text-base font-bold tracking-wider text-[#FAF7F0]">
            Curatorial Filters
          </h3>
          {activeCount > 0 && (
            <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-[#D4AF37] text-black">
              {activeCount}
            </span>
          )}
        </div>

        {activeCount > 0 && (
          <button
            type="button"
            onClick={onResetFilters}
            className="text-xs text-[#9FA4B8] hover:text-[#D4AF37] flex items-center gap-1 transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset All</span>
          </button>
        )}
      </div>

      {/* 1. CANDIDATE FILTER: Availability */}
      <div className="border-b border-[#1E2232] pb-5">
        <button
          type="button"
          onClick={() => toggleSection('availability')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
            Availability
          </span>
          {openSections.availability ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.availability && (
          <div className="mt-3 space-y-2">
            {[
              { label: 'All Silhouettes', value: 'all' },
              { label: 'Ready to Ship (In Stock)', value: 'in_stock', icon: CheckCircle2 },
              { label: 'Made to Order (Bespoke 14d)', value: 'made_to_order', icon: Clock }
            ].map(opt => (
              <label
                key={opt.value}
                className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors ${
                  filters.availability === opt.value
                    ? 'bg-[#1C2030] text-[#D4AF37] font-semibold border border-[#D4AF37]/50'
                    : 'hover:bg-[#151825] text-[#C4C0B6]'
                }`}
              >
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="availability"
                    value={opt.value}
                    checked={filters.availability === opt.value}
                    onChange={() => onFilterChange({ availability: opt.value as any })}
                    className="sr-only"
                  />
                  <div
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      filters.availability === opt.value
                        ? 'border-[#D4AF37] bg-[#D4AF37]'
                        : 'border-[#42485E]'
                    }`}
                  >
                    {filters.availability === opt.value && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                  </div>
                  <span className="text-xs">{opt.label}</span>
                </div>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* 2. CANDIDATE FILTER: Category */}
      <div className="border-b border-[#1E2232] pb-5">
        <button
          type="button"
          onClick={() => toggleSection('category')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span>Category</span>
          {openSections.category ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.category && (
          <div className="mt-3 space-y-1.5">
            <button
              type="button"
              onClick={() => onFilterChange({ category: 'all' })}
              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors ${
                !filters.category || filters.category === 'all'
                  ? 'bg-[#1C2030] text-[#D4AF37] font-semibold'
                  : 'text-[#C4C0B6] hover:bg-[#151825]'
              }`}
            >
              <span>All Categories</span>
              <span className="text-[11px] font-mono text-[#7B8094]">
                {facets?.categories.reduce((acc, c) => acc + c.count, 0) || totalResults}
              </span>
            </button>

            {facets?.categories.map(cat => (
              <button
                key={cat.value}
                type="button"
                onClick={() => onFilterChange({ category: cat.value })}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors ${
                  filters.category === cat.value
                    ? 'bg-[#1C2030] text-[#D4AF37] font-semibold border border-[#D4AF37]/50'
                    : 'text-[#C4C0B6] hover:bg-[#151825]'
                }`}
              >
                <span>{cat.label}</span>
                <span className="text-[11px] font-mono text-[#7B8094]">{cat.count}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 3. CANDIDATE FILTER: Price Range */}
      <div className="border-b border-[#1E2232] pb-5">
        <button
          type="button"
          onClick={() => toggleSection('price')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span>Price Range</span>
          {openSections.price ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.price && (
          <div className="mt-3 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-[#7B8094] uppercase tracking-wider">Min ({currency})</label>
                <input
                  type="number"
                  placeholder="50,000"
                  value={filters.minPrice ?? ''}
                  onChange={e => onFilterChange({ minPrice: e.target.value ? Number(e.target.value) : undefined })}
                  className="w-full bg-[#121420] border border-[#2B3044] rounded px-2.5 py-1.5 text-xs text-[#FAF7F0] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#7B8094] uppercase tracking-wider">Max ({currency})</label>
                <input
                  type="number"
                  placeholder="3,00,000"
                  value={filters.maxPrice ?? ''}
                  onChange={e => onFilterChange({ maxPrice: e.target.value ? Number(e.target.value) : undefined })}
                  className="w-full bg-[#121420] border border-[#2B3044] rounded px-2.5 py-1.5 text-xs text-[#FAF7F0] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>
            </div>

            {/* Quick Price Tier Shortcuts */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[
                { label: '< ₹1L', min: undefined, max: 100000 },
                { label: '₹1L - ₹1.5L', min: 100000, max: 150000 },
                { label: '₹1.5L - ₹2.5L', min: 150000, max: 250000 },
                { label: '₹2.5L+', min: 250000, max: undefined }
              ].map((tier, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => onFilterChange({ minPrice: tier.min, maxPrice: tier.max })}
                  className={`px-2 py-1 rounded text-[10px] font-mono border transition-colors ${
                    filters.minPrice === tier.min && filters.maxPrice === tier.max
                      ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-bold'
                      : 'bg-[#121420] text-[#9A9FB4] border-[#25293B] hover:border-[#D4AF37]/50'
                  }`}
                >
                  {tier.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 4. CANDIDATE FILTER: Color Palette */}
      <div className="border-b border-[#1E2232] pb-5">
        <button
          type="button"
          onClick={() => toggleSection('color')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span>Color & Hues ({filters.color?.length || 0})</span>
          {openSections.color ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.color && (
          <div className="mt-3 space-y-1.5">
            {facets?.colors.map(col => {
              const isSelected = filters.color?.includes(col.value);
              return (
                <button
                  key={col.value}
                  type="button"
                  onClick={() => toggleArrayFilter('color', col.value)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors ${
                    isSelected
                      ? 'bg-[#1C2030] text-[#D4AF37] font-semibold border border-[#D4AF37]/50'
                      : 'text-[#C4C0B6] hover:bg-[#151825]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-black/50 shadow-sm flex items-center justify-center"
                      style={{ backgroundColor: col.hex || '#C5A059' }}
                    >
                      {isSelected && <Check className="w-2.5 h-2.5 text-black" />}
                    </span>
                    <span>{col.label}</span>
                  </div>
                  <span className="text-[11px] font-mono text-[#7B8094]">{col.count}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. CANDIDATE FILTER: Fabric & Weave Origin */}
      <div className="border-b border-[#1E2232] pb-5">
        <button
          type="button"
          onClick={() => toggleSection('fabric')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span>Fabric & Weave ({filters.fabric?.length || 0})</span>
          {openSections.fabric ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.fabric && (
          <div className="mt-3 space-y-1.5">
            {facets?.fabrics.map(fab => {
              const isSelected = filters.fabric?.includes(fab.value);
              return (
                <button
                  key={fab.value}
                  type="button"
                  onClick={() => toggleArrayFilter('fabric', fab.value)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs text-left transition-colors ${
                    isSelected
                      ? 'bg-[#1C2030] text-[#D4AF37] font-semibold border border-[#D4AF37]/50'
                      : 'text-[#C4C0B6] hover:bg-[#151825]'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 pr-2">
                    <div
                      className={`w-3.5 h-3.5 rounded border flex items-center justify-center flex-shrink-0 ${
                        isSelected ? 'bg-[#D4AF37] border-[#D4AF37]' : 'border-[#3D445D]'
                      }`}
                    >
                      {isSelected && <Check className="w-2.5 h-2.5 text-black" />}
                    </div>
                    <span className="truncate">{fab.label}</span>
                  </div>
                  <span className="text-[11px] font-mono text-[#7B8094] flex-shrink-0">{fab.count}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 6. CANDIDATE FILTER: Size Specification */}
      <div className="border-b border-[#1E2232] pb-5">
        <button
          type="button"
          onClick={() => toggleSection('size')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span>Size Specification ({filters.size?.length || 0})</span>
          {openSections.size ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.size && (
          <div className="mt-3 flex flex-wrap gap-2">
            {facets?.sizes.map(sz => {
              const isSelected = filters.size?.includes(sz.value);
              return (
                <button
                  key={sz.value}
                  type="button"
                  onClick={() => toggleArrayFilter('size', sz.value)}
                  className={`px-3 py-1.5 rounded text-xs border font-medium transition-all ${
                    isSelected
                      ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-bold shadow-sm'
                      : 'bg-[#121420] text-[#C4C0B6] border-[#2A3044] hover:border-[#D4AF37]/60'
                  }`}
                >
                  {sz.label} ({sz.count})
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 7. CANDIDATE FILTER: Occasion & Gala */}
      <div className="border-b border-[#1E2232] pb-5">
        <button
          type="button"
          onClick={() => toggleSection('occasion')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span>Occasion ({filters.occasion?.length || 0})</span>
          {openSections.occasion ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.occasion && (
          <div className="mt-3 space-y-1.5">
            {facets?.occasions.map(occ => {
              const isSelected = filters.occasion?.includes(occ.value);
              return (
                <button
                  key={occ.value}
                  type="button"
                  onClick={() => toggleArrayFilter('occasion', occ.value)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors ${
                    isSelected
                      ? 'bg-[#1C2030] text-[#D4AF37] font-semibold border border-[#D4AF37]/50'
                      : 'text-[#C4C0B6] hover:bg-[#151825]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-3.5 h-3.5 rounded border flex items-center justify-center flex-shrink-0 ${
                        isSelected ? 'bg-[#D4AF37] border-[#D4AF37]' : 'border-[#3D445D]'
                      }`}
                    >
                      {isSelected && <Check className="w-2.5 h-2.5 text-black" />}
                    </div>
                    <span>{occ.label}</span>
                  </div>
                  <span className="text-[11px] font-mono text-[#7B8094]">{occ.count}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Elemental Collection Filter */}
      <div className="pb-4">
        <button
          type="button"
          onClick={() => toggleSection('collection')}
          className="w-full flex items-center justify-between font-semibold uppercase tracking-wider text-xs text-[#C5A059] hover:text-[#FAF7F0] transition-colors py-1"
        >
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            Elemental Realm
          </span>
          {openSections.collection ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.collection && (
          <div className="mt-3 space-y-1.5">
            {facets?.collections.map(col => (
              <button
                key={col.value}
                type="button"
                onClick={() => onFilterChange({ collection: col.value })}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors ${
                  filters.collection === col.value
                    ? 'bg-[#1C2030] text-[#D4AF37] font-semibold border border-[#D4AF37]/50'
                    : 'text-[#C4C0B6] hover:bg-[#151825]'
                }`}
              >
                <span>{col.label}</span>
                <span className="text-[11px] font-mono text-[#7B8094]">{col.count}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* DESKTOP SIDEBAR */}
      <aside className="hidden lg:block w-72 flex-shrink-0 bg-[#0A0C13] border border-[#1E2333] rounded-lg p-5 h-fit sticky top-24 shadow-md">
        {renderFilterContent()}
      </aside>

      {/* MOBILE DRAWER / BOTTOM SHEET */}
      {isMobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div
            className="w-full max-h-[85vh] bg-[#0A0C13] border-t border-[#262B3F] rounded-t-2xl flex flex-col shadow-2xl animate-in slide-in-from-bottom duration-300"
            onClick={e => e.stopPropagation()}
          >
            {/* Mobile Drawer Header */}
            <div className="p-4 border-b border-[#1E2232] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-[#D4AF37]" />
                <h3 className="font-cinzel text-base font-bold text-[#FAF7F0]">
                  Filters & Weave Criteria
                </h3>
                {activeCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-[#D4AF37] text-black">
                    {activeCount}
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={onCloseMobileDrawer}
                className="p-1.5 rounded-full bg-[#151926] text-[#FAF7F0] hover:bg-[#202538]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Mobile Filter Body */}
            <div className="p-5 overflow-y-auto flex-1">
              {renderFilterContent()}
            </div>

            {/* Mobile Bottom Sticky Action Bar */}
            <div className="p-4 border-t border-[#1C2030] bg-[#0E111B] flex items-center gap-3">
              <button
                type="button"
                onClick={onResetFilters}
                className="flex-1 py-3 px-4 rounded-sm border border-[#2B3148] text-xs font-bold uppercase tracking-wider text-[#FAF7F0] hover:bg-[#171B2B]"
              >
                Reset All
              </button>
              <button
                type="button"
                onClick={onCloseMobileDrawer}
                className="flex-1 py-3 px-4 rounded-sm bg-[#D4AF37] hover:bg-[#E5C07B] text-black text-xs font-bold uppercase tracking-wider shadow-lg"
              >
                View {totalResults} Silhouettes
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
