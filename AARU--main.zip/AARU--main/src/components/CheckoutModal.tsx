import React, { useState } from 'react';
import { 
  X, Sparkles, Check, ShieldCheck, MessageCircle, ArrowRight, ArrowLeft, 
  Package, Truck, Clock, CreditCard, Smartphone, Building2, AlertCircle, 
  RotateCcw, Copy, Tag, CheckCircle2, MapPin, Plus, Edit2
} from 'lucide-react';
import { CartItem, Order } from '../types';

export interface SavedAddress {
  id: string;
  label: string;
  fullName: string;
  email: string;
  phone: string;
  address: string;
  apartment?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault?: boolean;
}

const DEFAULT_SAVED_ADDRESSES: SavedAddress[] = [
  {
    id: 'addr-1',
    label: 'Primary Residence (Jubilee Hills)',
    fullName: 'Gayathri Rao',
    email: 'gayathri.rao@aaru-clientele.com',
    phone: '+91 98490 12345',
    address: 'Plot 412, Road No. 36, Jubilee Hills',
    apartment: 'Villa Vaikuntha',
    city: 'Hyderabad',
    state: 'Telangana',
    postalCode: '500033',
    country: 'India',
    isDefault: true
  },
  {
    id: 'addr-2',
    label: 'South Mumbai Atelier',
    fullName: 'Gayathri Rao',
    email: 'gayathri.rao@aaru-clientele.com',
    phone: '+91 98490 12345',
    address: 'Maker Chambers VI, Nariman Point',
    apartment: 'Suite 14B',
    city: 'Mumbai',
    state: 'Maharashtra',
    postalCode: '400021',
    country: 'India'
  }
];

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  currency?: 'INR' | 'USD';
  giftPackaging: boolean;
  onOrderPlaced: (order: Order) => void;
}

type CheckoutStep = 'address' | 'summary' | 'payment' | 'processing' | 'declined' | 'success';

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  giftPackaging,
  onOrderPlaced
}) => {
  if (!isOpen) return null;

  // Checkout Stepper State
  const [step, setStep] = useState<CheckoutStep>('address');

  // Address State: Saved vs New
  const [savedAddresses, setSavedAddresses] = useState<SavedAddress[]>(() => {
    try {
      const stored = localStorage.getItem('aaru_saved_addresses');
      return stored ? JSON.parse(stored) : DEFAULT_SAVED_ADDRESSES;
    } catch {
      return DEFAULT_SAVED_ADDRESSES;
    }
  });

  const [selectedAddressId, setSelectedAddressId] = useState<string>('addr-1');
  const [isAddingNewAddress, setIsAddingNewAddress] = useState(false);
  const [saveAddressForFuture, setSaveAddressForFuture] = useState(true);

  // New Address Form Data
  const [newAddressForm, setNewAddressForm] = useState({
    label: 'Residence',
    fullName: '',
    email: '',
    phone: '',
    address: '',
    apartment: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'India'
  });

  // Special Notes
  const [specialNotes, setSpecialNotes] = useState(
    'Please verify gold hallmark certification and place in velvet-lined cedar casket.'
  );

  // Promo Code State
  const [promoCodeInput, setPromoCodeInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discountAmount: number; label: string } | null>(null);
  const [promoError, setPromoError] = useState<string | null>(null);

  // Payment Gateway State (Razorpay Simulation)
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking' | 'emi'>('upi');
  const [selectedUpiApp, setSelectedUpiApp] = useState<'gpay' | 'phonepe' | 'paytm' | 'custom'>('gpay');
  const [customUpiId, setCustomUpiId] = useState('');
  const [cardDetails, setCardDetails] = useState({
    number: '•••• •••• •••• 4242',
    name: 'GAYATHRI RAO',
    expiry: '09/29',
    cvv: '•••'
  });
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [shouldSimulateDecline, setShouldSimulateDecline] = useState(false);
  const [declineReason, setDeclineReason] = useState('Issuing Bank 3D Secure verification timed out.');

  // Confirmed Order State
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);
  const [copiedOrderId, setCopiedOrderId] = useState(false);

  // Cost Calculations
  const baseSubtotal = items.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  const promoDiscount = appliedPromo ? appliedPromo.discountAmount : 0;
  const shippingFee = 0; // Complimentary for orders over ₹5,000
  // 5% Handloom Silk GST
  const estimatedTax = Math.round((baseSubtotal - promoDiscount) * 0.05);
  const finalPayable = Math.max(0, baseSubtotal - promoDiscount); // All-inclusive luxury pricing

  // Get active shipping address object
  const getActiveAddress = (): SavedAddress => {
    if (isAddingNewAddress) {
      return {
        id: `addr-${Date.now()}`,
        label: newAddressForm.label || 'New Delivery Address',
        fullName: newAddressForm.fullName,
        email: newAddressForm.email,
        phone: newAddressForm.phone,
        address: newAddressForm.address,
        apartment: newAddressForm.apartment,
        city: newAddressForm.city,
        state: newAddressForm.state,
        postalCode: newAddressForm.postalCode,
        country: newAddressForm.country
      };
    }
    const found = savedAddresses.find(a => a.id === selectedAddressId);
    return found || savedAddresses[0];
  };

  // Promo Code Handlers
  const handleApplyPromo = () => {
    setPromoError(null);
    const cleanCode = promoCodeInput.trim().toUpperCase();

    if (cleanCode === 'AARUROYAL') {
      const discount = Math.min(15000, Math.round(baseSubtotal * 0.1));
      setAppliedPromo({
        code: 'AARUROYAL',
        discountAmount: discount,
        label: 'Patron Archival Privilege (10% Off)'
      });
      setPromoCodeInput('');
    } else if (cleanCode === 'ATELIER5000') {
      setAppliedPromo({
        code: 'ATELIER5000',
        discountAmount: 5000,
        label: 'First Loom Commission (₹5,000 Privilege)'
      });
      setPromoCodeInput('');
    } else if (cleanCode === 'SIXTHELEMENT') {
      const discount = Math.min(25000, Math.round(baseSubtotal * 0.15));
      setAppliedPromo({
        code: 'SIXTHELEMENT',
        discountAmount: discount,
        label: 'The Sixth Element Connoisseur (15% Off)'
      });
      setPromoCodeInput('');
    } else {
      setPromoError('Invalid privilege code. Please enter AARUROYAL or ATELIER5000.');
    }
  };

  const handleRemovePromo = () => {
    setAppliedPromo(null);
    setPromoError(null);
  };

  // Address Handlers
  const handleSaveNewAddressAndContinue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddressForm.fullName || !newAddressForm.address || !newAddressForm.city || !newAddressForm.postalCode) {
      alert('Please fill in all mandatory delivery fields.');
      return;
    }

    const newAddr: SavedAddress = {
      id: `addr-${Date.now()}`,
      label: newAddressForm.label || 'New Residence',
      fullName: newAddressForm.fullName,
      email: newAddressForm.email,
      phone: newAddressForm.phone,
      address: newAddressForm.address,
      apartment: newAddressForm.apartment,
      city: newAddressForm.city,
      state: newAddressForm.state,
      postalCode: newAddressForm.postalCode,
      country: newAddressForm.country
    };

    if (saveAddressForFuture) {
      const updated = [newAddr, ...savedAddresses];
      setSavedAddresses(updated);
      try {
        localStorage.setItem('aaru_saved_addresses', JSON.stringify(updated));
      } catch {
        // Ignore
      }
    }
    setSelectedAddressId(newAddr.id);
    setIsAddingNewAddress(false);
    setStep('summary');
  };

  // Payment Processing (Razorpay integration flow)
  const handleInitiatePayment = () => {
    setStep('processing');

    setTimeout(() => {
      if (shouldSimulateDecline) {
        setStep('declined');
      } else {
        // Payment Succeeded! Generate authentic unique order
        const activeAddr = getActiveAddress();
        const randomNum = Math.floor(1000 + Math.random() * 9000);
        const newOrder: Order = {
          id: `order-${Date.now()}`,
          orderNumber: `ARU-2026-${randomNum}`,
          date: new Date().toLocaleDateString('en-IN', { month: 'long', day: 'numeric', year: 'numeric' }),
          total: finalPayable,
          status: 'Artisan Allocated',
          estimatedDelivery: new Date(Date.now() + 14 * 86400000).toLocaleDateString('en-IN', { month: 'long', day: 'numeric', year: 'numeric' }),
          giftPackaging,
          shippingAddress: {
            fullName: activeAddr.fullName,
            email: activeAddr.email,
            phone: activeAddr.phone,
            address: `${activeAddr.address}${activeAddr.apartment ? `, ${activeAddr.apartment}` : ''}`,
            city: `${activeAddr.city}, ${activeAddr.state}`,
            postalCode: activeAddr.postalCode,
            country: activeAddr.country
          },
          items: items.map(it => ({
            productId: it.product.id,
            productName: it.product.name,
            productImage: it.product.images[0],
            price: it.product.price,
            quantity: it.quantity,
            size: it.size,
            monogram: it.monogram,
            customMeasurements: it.customMeasurements
          })),
          trackingMilestones: [
            {
              title: 'Razorpay Payment Captured & Verified',
              description: `Transaction ₹${finalPayable.toLocaleString('en-IN')} approved via 256-bit bank encrypted gateway.`,
              date: 'Just now',
              completed: true
            },
            {
              title: 'Assigned to Kanchipuram Pit-Loom Guild',
              description: 'Master Weaver assigned for dedicated warp tensioning and pure 24k zari allocation.',
              date: 'In progress',
              completed: false
            },
            {
              title: 'Solid Teakwood Box Archival & Hallmarking',
              description: 'Textile inspection officer applies government assay seal.',
              date: 'Estimated 7 days',
              completed: false
            },
            {
              title: 'White-Glove Armored Courier Dispatch',
              description: 'Insured private delivery with live GPS pin tracking.',
              date: 'Estimated 14 days',
              completed: false
            }
          ]
        };

        setPlacedOrder(newOrder);
        // CRITICAL CART PRESERVATION: Cart is ONLY emptied here upon confirmed payment success!
        onOrderPlaced(newOrder);
        setStep('success');
      }
    }, 2200);
  };

  const handleCopyOrderId = () => {
    if (placedOrder) {
      navigator.clipboard.writeText(placedOrder.orderNumber);
      setCopiedOrderId(true);
      setTimeout(() => setCopiedOrderId(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="relative max-w-3xl w-full bg-[#0E1016] border border-[#3A3832] rounded-sm shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#141620] border-b border-[#252838] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <span className="font-telugu text-2xl font-bold text-[#D4AF37]">ఆరు</span>
            <div>
              <h2 className="font-cinzel text-base font-bold text-[#FAF7F0] tracking-wider uppercase">
                {step === 'success' ? 'Haute Couture Commission Confirmed' : 'Bespoke Atelier Commission'}
              </h2>
              <div className="text-[10px] text-[#A09A8E] flex items-center gap-2">
                <span>Secure 256-Bit Encrypted Gateway</span>
                <span>•</span>
                <span>Verified PostgreSQL Archival Ledger</span>
              </div>
            </div>
          </div>

          {/* Close button preserves cart always */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#1E2130] text-[#A09A8E] hover:text-white transition-colors"
            title="Close (Your cart remains preserved)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-Step Breadcrumb Progress Bar (Only visible before completion) */}
        {step !== 'success' && (
          <div className="px-6 py-2.5 bg-[#10121A] border-b border-[#1E2130] flex items-center justify-between text-[11px] overflow-x-auto scrollbar-none">
            <div className="flex items-center gap-6 min-w-max">
              <button
                onClick={() => setStep('address')}
                className={`flex items-center gap-2 transition-colors ${
                  step === 'address' ? 'text-[#D4AF37] font-semibold' : 'text-[#7E8294] hover:text-white'
                }`}
              >
                <span className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center ${
                  step === 'address' ? 'bg-[#D4AF37] text-black font-bold' : 'bg-[#1E2230] text-[#A09A8E]'
                }`}>1</span>
                <span>Delivery Address</span>
              </button>

              <span className="text-[#323648]">/</span>

              <button
                onClick={() => setStep('summary')}
                className={`flex items-center gap-2 transition-colors ${
                  step === 'summary' ? 'text-[#D4AF37] font-semibold' : 'text-[#7E8294] hover:text-white'
                }`}
              >
                <span className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center ${
                  step === 'summary' ? 'bg-[#D4AF37] text-black font-bold' : 'bg-[#1E2230] text-[#A09A8E]'
                }`}>2</span>
                <span>Itemized Review</span>
              </button>

              <span className="text-[#323648]">/</span>

              <button
                onClick={() => setStep('payment')}
                className={`flex items-center gap-2 transition-colors ${
                  step === 'payment' || step === 'declined' || step === 'processing' ? 'text-[#D4AF37] font-semibold' : 'text-[#7E8294] hover:text-white'
                }`}
              >
                <span className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center ${
                  step === 'payment' || step === 'declined' ? 'bg-[#D4AF37] text-black font-bold' : 'bg-[#1E2230] text-[#A09A8E]'
                }`}>3</span>
                <span>Razorpay Gateway</span>
              </button>
            </div>

            <div className="text-[10px] text-[#A09A8E] hidden sm:flex items-center gap-1.5 font-mono">
              <span>Payable:</span>
              <strong className="text-[#D4AF37]">₹{finalPayable.toLocaleString('en-IN')}</strong>
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* ========================================================
              STEP 1: ADDRESS CAPTURE (Saved vs New Address)
             ======================================================== */}
          {step === 'address' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-cinzel text-base font-bold text-[#FAF7F0]">
                    Select Delivery Residence
                  </h3>
                  <p className="text-xs text-[#A09A8E]">
                    Select an archival patron address or register a new armored destination.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsAddingNewAddress(prev => !prev)}
                  className="px-3.5 py-1.5 rounded bg-[#171924] hover:bg-[#202434] border border-[#2B3044] hover:border-[#D4AF37] text-[#D4AF37] text-xs font-medium flex items-center gap-1.5 transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAddingNewAddress ? 'Choose Saved Address' : 'Add New Address'}</span>
                </button>
              </div>

              {!isAddingNewAddress ? (
                /* Saved Addresses Grid */
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {savedAddresses.map(addr => {
                      const isSelected = selectedAddressId === addr.id;
                      return (
                        <div
                          key={addr.id}
                          onClick={() => setSelectedAddressId(addr.id)}
                          className={`p-4 rounded-sm border cursor-pointer transition-all relative ${
                            isSelected
                              ? 'bg-[#181B26] border-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.15)]'
                              : 'bg-[#12141C] border-[#222534] hover:border-[#383D54]'
                          }`}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-2">
                              <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-[#D4AF37]' : 'text-[#7E8294]'}`} />
                              <span className="text-xs font-semibold text-[#FAF7F0] font-cinzel">
                                {addr.label}
                              </span>
                            </div>
                            {isSelected && (
                              <span className="w-5 h-5 rounded-full bg-[#D4AF37] text-black flex items-center justify-center">
                                <Check className="w-3 h-3 stroke-[3]" />
                              </span>
                            )}
                          </div>

                          <div className="mt-2.5 text-xs text-[#C8C2B7] space-y-0.5">
                            <p className="font-medium text-[#FAF7F0]">{addr.fullName}</p>
                            <p className="text-[#A09A8E]">{addr.address}{addr.apartment ? `, ${addr.apartment}` : ''}</p>
                            <p className="text-[#A09A8E]">{addr.city}, {addr.state} - {addr.postalCode}</p>
                            <p className="text-[#7E8294] text-[11px] font-mono pt-1">{addr.phone}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Continue Button */}
                  <div className="pt-4 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setStep('summary')}
                      className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-[#D4AF37] via-[#DFBF58] to-[#C5A059] text-black font-semibold text-xs uppercase tracking-[0.2em] rounded-sm hover:opacity-95 transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(212,175,55,0.25)]"
                    >
                      <span>Proceed to Itemized Review</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                /* New Address Form */
                <form onSubmit={handleSaveNewAddressAndContinue} className="p-4 bg-[#12141C] border border-[#242838] rounded-sm space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        Address Label (e.g. Hyderabad Villa / Mumbai Office)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Primary Residence"
                        value={newAddressForm.label}
                        onChange={e => setNewAddressForm({ ...newAddressForm, label: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        Full Legal Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Patron's Name"
                        value={newAddressForm.fullName}
                        onChange={e => setNewAddressForm({ ...newAddressForm, fullName: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        Patron Email *
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="clientele@aaru-patrons.com"
                        value={newAddressForm.email}
                        onChange={e => setNewAddressForm({ ...newAddressForm, email: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        Phone / WhatsApp Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+91 98490 00000"
                        value={newAddressForm.phone}
                        onChange={e => setNewAddressForm({ ...newAddressForm, phone: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        Street Address / Estate *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="House / Flat No., Street, Landmark"
                        value={newAddressForm.address}
                        onChange={e => setNewAddressForm({ ...newAddressForm, address: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        City *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Hyderabad / Mumbai / Delhi"
                        value={newAddressForm.city}
                        onChange={e => setNewAddressForm({ ...newAddressForm, city: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        State *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Telangana / Maharashtra"
                        value={newAddressForm.state}
                        onChange={e => setNewAddressForm({ ...newAddressForm, state: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        PIN / Postal Code *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="500033"
                        value={newAddressForm.postalCode}
                        onChange={e => setNewAddressForm({ ...newAddressForm, postalCode: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        Country
                      </label>
                      <input
                        type="text"
                        value={newAddressForm.country}
                        onChange={e => setNewAddressForm({ ...newAddressForm, country: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-[#1F2332]">
                    <input
                      type="checkbox"
                      id="saveForFuture"
                      checked={saveAddressForFuture}
                      onChange={e => setSaveAddressForFuture(e.target.checked)}
                      className="rounded border-[#3A3832] text-[#D4AF37] focus:ring-0 cursor-pointer accent-[#D4AF37]"
                    />
                    <label htmlFor="saveForFuture" className="text-xs text-[#C8C2B7] cursor-pointer">
                      Save this address to my permanent patron account for future commissions
                    </label>
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setIsAddingNewAddress(false)}
                      className="px-4 py-2 rounded bg-[#181A24] text-[#A09A8E] hover:text-white text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-3 bg-[#D4AF37] hover:bg-[#FFE59E] text-black font-semibold uppercase tracking-wider rounded-sm text-xs transition-all"
                    >
                      Save & Proceed to Review
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* ========================================================
              STEP 2: ITEMIZED ORDER SUMMARY (Transparent Breakdown & Promo)
             ======================================================== */}
          {step === 'summary' && (
            <div className="space-y-6">
              {/* Active Address Card */}
              <div className="p-3.5 bg-[#12141C] border border-[#252838] rounded-sm flex items-center justify-between">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <div className="font-semibold text-[#FAF7F0] font-cinzel">
                      Delivering to: {getActiveAddress().label}
                    </div>
                    <div className="text-[#A09A8E]">
                      {getActiveAddress().fullName} • {getActiveAddress().address}, {getActiveAddress().city} ({getActiveAddress().postalCode})
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setStep('address')}
                  className="text-xs text-[#D4AF37] hover:underline flex items-center gap-1 font-medium"
                >
                  <Edit2 className="w-3 h-3" />
                  <span>Change</span>
                </button>
              </div>

              {/* Line Items List */}
              <div className="p-4 bg-[#12141C] border border-[#252838] rounded-sm space-y-3">
                <div className="text-xs font-semibold text-[#D4AF37] uppercase tracking-wider font-cinzel pb-2 border-b border-[#1E2232] flex justify-between">
                  <span>Commission Line Items ({items.length} Masterpiece{items.length === 1 ? '' : 's'})</span>
                  <span>Line Total</span>
                </div>

                <div className="divide-y divide-[#1A1D2A] space-y-2">
                  {items.map((item, idx) => (
                    <div key={idx} className="pt-2 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-12 h-14 object-cover rounded border border-[#2D3042]"
                        />
                        <div className="text-xs">
                          <h4 className="font-semibold text-[#FAF7F0] font-cinzel">{item.product.name}</h4>
                          <div className="text-[11px] text-[#A09A8E]">
                            Size: <span className="text-[#D4AF37]">{item.size}</span> • Qty: {item.quantity}
                          </div>
                          {item.monogram && (
                            <div className="text-[10px] text-[#C5A059] flex items-center gap-1">
                              <Sparkles className="w-2.5 h-2.5" />
                              <span>Monogram: &ldquo;{item.monogram}&rdquo;</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="text-xs font-mono font-bold text-[#FAF7F0] text-right">
                        ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Promo Privilege Code Box */}
              <div className="p-4 bg-[#12141C] border border-[#252838] rounded-sm space-y-2">
                <label className="text-xs font-semibold text-[#FAF7F0] font-cinzel flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Atelier Privilege / Promo Code</span>
                </label>

                {appliedPromo ? (
                  <div className="p-2.5 bg-emerald-950/40 border border-emerald-500/50 rounded flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <div>
                        <span className="font-mono text-xs text-emerald-300 font-bold">{appliedPromo.code}</span>
                        <span className="text-[11px] text-emerald-400/80 ml-2">({appliedPromo.label})</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleRemovePromo}
                      className="text-[11px] text-rose-400 hover:text-rose-300 underline"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Enter privilege code (e.g. AARUROYAL)"
                        value={promoCodeInput}
                        onChange={e => setPromoCodeInput(e.target.value)}
                        className="flex-1 bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-xs text-[#FAF7F0] uppercase font-mono tracking-wider outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleApplyPromo}
                        className="px-4 py-2 bg-[#1B1E2B] hover:bg-[#25293B] border border-[#2E344A] hover:border-[#D4AF37] text-xs font-semibold uppercase text-[#D4AF37] rounded transition-all"
                      >
                        Apply Code
                      </button>
                    </div>
                    {promoError && (
                      <p className="text-[11px] text-rose-400 mt-1.5 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{promoError}</span>
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-[10px] text-[#7E8294]">Try sample codes:</span>
                      <button
                        type="button"
                        onClick={() => {
                          setPromoCodeInput('AARUROYAL');
                        }}
                        className="text-[10px] font-mono text-[#D4AF37] hover:underline px-1.5 py-0.5 rounded bg-[#171924]"
                      >
                        AARUROYAL (10% Off)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setPromoCodeInput('ATELIER5000');
                        }}
                        className="text-[10px] font-mono text-[#D4AF37] hover:underline px-1.5 py-0.5 rounded bg-[#171924]"
                      >
                        ATELIER5000 (₹5k Off)
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Transparent Cost Breakdown */}
              <div className="p-4 bg-[#141620] border border-[#252838] rounded-sm space-y-2 text-xs">
                <div className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold font-cinzel pb-2 border-b border-[#1E2232]">
                  Transparent Cost Breakdown
                </div>

                <div className="flex justify-between text-[#A09A8E] pt-1">
                  <span>Merchandise Base Subtotal:</span>
                  <span className="font-mono text-[#FAF7F0]">₹{baseSubtotal.toLocaleString('en-IN')}</span>
                </div>

                {appliedPromo && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Applied Privilege Discount ({appliedPromo.code}):</span>
                    <span className="font-mono">-₹{appliedPromo.discountAmount.toLocaleString('en-IN')}</span>
                  </div>
                )}

                <div className="flex justify-between text-[#A09A8E]">
                  <span>Insured Global Armored Shipping:</span>
                  <span className="text-emerald-400 font-mono uppercase text-[11px]">Complimentary (Waived)</span>
                </div>

                <div className="flex justify-between text-[#A09A8E]">
                  <span>Estimated 5% Handloom Silk GST:</span>
                  <span className="font-mono text-[#FAF7F0]">₹{estimatedTax.toLocaleString('en-IN')} (Included in Total)</span>
                </div>

                {giftPackaging && (
                  <div className="flex justify-between text-[#A09A8E]">
                    <span>Teakwood Archival Box & Muslin Wrap:</span>
                    <span className="text-emerald-400 font-mono uppercase text-[11px]">Complimentary</span>
                  </div>
                )}

                <div className="flex justify-between text-sm font-semibold text-[#FAF7F0] pt-3 border-t border-[#22242E]">
                  <div>
                    <span className="text-[#FAF7F0]">Net Payable Commission:</span>
                    <p className="text-[10px] text-[#A09A8E] font-normal">Includes hallmark guarantee & insured transit</p>
                  </div>
                  <span className="font-mono text-lg text-[#D4AF37]">
                    ₹{finalPayable.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Navigation Buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep('address')}
                  className="px-5 py-3 rounded bg-[#181A24] text-[#A09A8E] hover:text-white text-xs flex items-center gap-1.5 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Address</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStep('payment')}
                  className="px-8 py-3.5 bg-gradient-to-r from-[#D4AF37] via-[#DFBF58] to-[#C5A059] text-black font-semibold text-xs uppercase tracking-[0.2em] rounded-sm hover:opacity-95 transition-all flex items-center gap-2 shadow-[0_4px_20px_rgba(212,175,55,0.25)]"
                >
                  <span>Proceed to Razorpay Gateway</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* ========================================================
              STEP 3: PAYMENT GATEWAY FLOW (Razorpay Integration Flow)
             ======================================================== */}
          {step === 'payment' && (
            <div className="space-y-6">
              {/* Razorpay Brand Bar */}
              <div className="p-3.5 bg-[#101422] border border-[#202844] rounded-sm flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded bg-[#1E3A8A]/30 border border-[#3B82F6]/40 flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5 text-[#3B82F6]" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-[#FAF7F0] flex items-center gap-2">
                      <span>Razorpay Trusted Business Gateway</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/40">
                        PCI-DSS Level 1 Verified
                      </span>
                    </div>
                    <div className="text-[10px] text-[#A09A8E]">
                      256-bit bank-grade encryption • Instant UPI & Card Settlements
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] text-[#7E8294] uppercase font-mono">Amount to Authorize</div>
                  <div className="font-mono text-base font-bold text-[#D4AF37]">
                    ₹{finalPayable.toLocaleString('en-IN')}
                  </div>
                </div>
              </div>

              {/* Payment Methods Selection Tabs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-3 rounded-sm border flex flex-col items-center gap-1.5 transition-all ${
                    paymentMethod === 'upi'
                      ? 'bg-[#181B28] border-[#D4AF37] text-[#FAF7F0]'
                      : 'bg-[#12141C] border-[#222534] text-[#A09A8E] hover:text-white'
                  }`}
                >
                  <Smartphone className={`w-4 h-4 ${paymentMethod === 'upi' ? 'text-[#D4AF37]' : ''}`} />
                  <span className="font-medium">UPI / QR</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-sm border flex flex-col items-center gap-1.5 transition-all ${
                    paymentMethod === 'card'
                      ? 'bg-[#181B28] border-[#D4AF37] text-[#FAF7F0]'
                      : 'bg-[#12141C] border-[#222534] text-[#A09A8E] hover:text-white'
                  }`}
                >
                  <CreditCard className={`w-4 h-4 ${paymentMethod === 'card' ? 'text-[#D4AF37]' : ''}`} />
                  <span className="font-medium">Card (Visa/MC/Amex)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-3 rounded-sm border flex flex-col items-center gap-1.5 transition-all ${
                    paymentMethod === 'netbanking'
                      ? 'bg-[#181B28] border-[#D4AF37] text-[#FAF7F0]'
                      : 'bg-[#12141C] border-[#222534] text-[#A09A8E] hover:text-white'
                  }`}
                >
                  <Building2 className={`w-4 h-4 ${paymentMethod === 'netbanking' ? 'text-[#D4AF37]' : ''}`} />
                  <span className="font-medium">NetBanking</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('emi')}
                  className={`p-3 rounded-sm border flex flex-col items-center gap-1.5 transition-all ${
                    paymentMethod === 'emi'
                      ? 'bg-[#181B28] border-[#D4AF37] text-[#FAF7F0]'
                      : 'bg-[#12141C] border-[#222534] text-[#A09A8E] hover:text-white'
                  }`}
                >
                  <Clock className={`w-4 h-4 ${paymentMethod === 'emi' ? 'text-[#D4AF37]' : ''}`} />
                  <span className="font-medium">Cardless EMI</span>
                </button>
              </div>

              {/* Payment Method Details Panel */}
              <div className="p-4 bg-[#12141C] border border-[#252838] rounded-sm space-y-4">
                {paymentMethod === 'upi' && (
                  <div className="space-y-3">
                    <label className="text-xs font-semibold text-[#FAF7F0]">
                      Select Preferred UPI App:
                    </label>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {[
                        { id: 'gpay', name: 'Google Pay' },
                        { id: 'phonepe', name: 'PhonePe' },
                        { id: 'paytm', name: 'Paytm / BHIM' }
                      ].map(app => (
                        <button
                          key={app.id}
                          type="button"
                          onClick={() => setSelectedUpiApp(app.id as any)}
                          className={`py-2 px-3 rounded border text-center font-medium transition-all ${
                            selectedUpiApp === app.id
                              ? 'bg-[#1E2232] border-[#D4AF37] text-[#D4AF37]'
                              : 'bg-[#161822] border-[#2A2E40] text-[#A09A8E]'
                          }`}
                        >
                          {app.name}
                        </button>
                      ))}
                    </div>

                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">
                        Or Enter UPI VPA ID (e.g. yourname@okhdfcbank)
                      </label>
                      <input
                        type="text"
                        placeholder="patron@upi"
                        value={customUpiId}
                        onChange={e => setCustomUpiId(e.target.value)}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-xs text-[#FAF7F0] outline-none"
                      />
                    </div>
                  </div>
                )}

                {paymentMethod === 'card' && (
                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">Card Number</label>
                      <input
                        type="text"
                        value={cardDetails.number}
                        onChange={e => setCardDetails({ ...cardDetails, number: e.target.value })}
                        className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] font-mono outline-none"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">Cardholder Name</label>
                        <input
                          type="text"
                          value={cardDetails.name}
                          onChange={e => setCardDetails({ ...cardDetails, name: e.target.value })}
                          className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#A09A8E] uppercase tracking-wider block mb-1">Expiry / CVV</label>
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={cardDetails.expiry}
                            onChange={e => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                            className="bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] font-mono text-center outline-none"
                          />
                          <input
                            type="text"
                            value={cardDetails.cvv}
                            onChange={e => setCardDetails({ ...cardDetails, cvv: e.target.value })}
                            className="bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] font-mono text-center outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === 'netbanking' && (
                  <div className="space-y-3 text-xs">
                    <label className="text-xs font-semibold text-[#FAF7F0]">Select Bank for NetBanking:</label>
                    <select
                      value={selectedBank}
                      onChange={e => setSelectedBank(e.target.value)}
                      className="w-full bg-[#0B0C10] border border-[#2E3346] focus:border-[#D4AF37] rounded px-3 py-2 text-[#FAF7F0] outline-none"
                    >
                      <option value="HDFC Bank">HDFC Bank</option>
                      <option value="ICICI Bank">ICICI Bank</option>
                      <option value="State Bank of India">State Bank of India</option>
                      <option value="Axis Bank">Axis Bank</option>
                      <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                    </select>
                  </div>
                )}

                {paymentMethod === 'emi' && (
                  <div className="p-3 bg-[#171924] rounded text-xs text-[#C8C2B7] space-y-1">
                    <div className="font-semibold text-[#FAF7F0]">Zero-Cost Archival EMI Available:</div>
                    <p className="text-[11px] text-[#A09A8E]">
                      Pay in 3 or 6 monthly installments of ₹{Math.round(finalPayable / 6).toLocaleString('en-IN')}/mo at 0% interest via HDFC, ICICI, or Amex cards.
                    </p>
                  </div>
                )}

                {/* Gateway Test Simulation Toggle (Allows testing both Success and Decline flows) */}
                <div className="p-3 bg-[#10121A] border border-[#202332] rounded-sm flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[11px] text-[#A09A8E] font-medium">Gateway Simulator:</span>
                    <div className="text-[10px] text-[#7E8294]">
                      {shouldSimulateDecline ? 'Mode: Simulate Bank Decline' : 'Mode: Simulate Standard Authorized Charge'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShouldSimulateDecline(prev => !prev)}
                    className={`px-3 py-1 rounded text-[11px] font-mono transition-all ${
                      shouldSimulateDecline
                        ? 'bg-rose-950 text-rose-300 border border-rose-600'
                        : 'bg-[#181B26] text-[#A09A8E] hover:text-white border border-[#2A2E40]'
                    }`}
                  >
                    {shouldSimulateDecline ? 'Simulate Decline' : 'Simulate Success'}
                  </button>
                </div>
              </div>

              {/* Cart Preservation Guarantee Notice */}
              <div className="p-3 bg-[#12151E] border border-[#222738] rounded-sm flex items-center gap-2.5 text-[11px] text-[#A09A8E]">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>
                  <strong>Cart Preservation Guarantee:</strong> If this payment is declined, cancelled, or closed, your bag contents remain 100% saved and intact.
                </span>
              </div>

              {/* Authorize Payment Action */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep('summary')}
                  className="px-5 py-3 rounded bg-[#181A24] text-[#A09A8E] hover:text-white text-xs flex items-center gap-1.5 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Review</span>
                </button>

                <button
                  type="button"
                  onClick={handleInitiatePayment}
                  className="px-8 py-3.5 bg-gradient-to-r from-[#D4AF37] via-[#DFBF58] to-[#C5A059] text-black font-semibold text-xs uppercase tracking-[0.2em] rounded-sm hover:opacity-95 transition-all flex items-center gap-2 shadow-[0_4px_25px_rgba(212,175,55,0.35)]"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Authorize ₹{finalPayable.toLocaleString('en-IN')}</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================================
              PROCESSING STATE: 3D Secure Verification
             ======================================================== */}
          {step === 'processing' && (
            <div className="py-16 text-center space-y-6">
              <div className="relative w-20 h-20 mx-auto">
                <div className="w-20 h-20 rounded-full border-4 border-[#252838] border-t-[#D4AF37] animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center font-telugu text-xl font-bold text-[#D4AF37]">
                  ఆరు
                </div>
              </div>

              <div>
                <h3 className="font-cinzel text-lg font-bold text-[#FAF7F0]">
                  Connecting to Razorpay Bank Gateway
                </h3>
                <p className="text-xs text-[#A09A8E] max-w-sm mx-auto mt-1">
                  Performing 3D Secure cryptographic handshake. Please do not close or refresh this window...
                </p>
              </div>

              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#12141D] border border-[#252838] text-[11px] text-[#C5A059] font-mono">
                <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Authorizing ₹{finalPayable.toLocaleString('en-IN')} via 256-bit SSL</span>
              </div>
            </div>
          )}

          {/* ========================================================
              PAYMENT DECLINED ERROR SCREEN (Seamless Retries & Cart Saved)
             ======================================================== */}
          {step === 'declined' && (
            <div className="py-8 space-y-6 text-center">
              <div className="w-16 h-16 rounded-full bg-rose-950/60 border-2 border-rose-500 mx-auto flex items-center justify-center text-rose-400 shadow-[0_0_30px_rgba(244,63,94,0.25)]">
                <AlertCircle className="w-8 h-8" />
              </div>

              <div>
                <div className="text-[11px] uppercase tracking-[0.25em] text-rose-400 font-semibold mb-1">
                  Payment Authorization Declined
                </div>
                <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-[#FAF7F0]">
                  Transaction Could Not Be Completed
                </h3>
                <p className="text-xs text-[#A09A8E] mt-1 max-w-md mx-auto">
                  {declineReason} (Error Code: <span className="font-mono text-rose-300">RAZORPAY_3DS_TIMEOUT_701</span>)
                </p>
              </div>

              {/* Cart Preservation Confirmation Banner */}
              <div className="p-3.5 bg-[#171924] border border-[#2B2F42] rounded-sm max-w-md mx-auto text-xs text-[#C8C2B7] flex items-center gap-3 text-left">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-[#FAF7F0] font-medium">Your Couture Bag is Completely Safe.</span>
                  <p className="text-[10px] text-[#A09A8E]">No funds were deducted. Your items and size specifications remain saved in your cart.</p>
                </div>
              </div>

              {/* Retry & Alternate Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2 max-w-md mx-auto">
                <button
                  type="button"
                  onClick={() => {
                    setShouldSimulateDecline(false);
                    setStep('payment');
                  }}
                  className="w-full sm:w-auto px-6 py-3.5 bg-[#D4AF37] hover:bg-[#FFE59E] text-black font-semibold text-xs uppercase tracking-wider rounded-sm flex items-center justify-center gap-2 transition-all shadow-[0_4px_15px_rgba(212,175,55,0.25)]"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retry Payment</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPaymentMethod('upi');
                    setShouldSimulateDecline(false);
                    setStep('payment');
                  }}
                  className="w-full sm:w-auto px-6 py-3.5 bg-[#171924] hover:bg-[#222638] border border-[#2E344A] text-[#FAF7F0] text-xs font-semibold uppercase tracking-wider rounded-sm transition-all"
                >
                  <span>Try UPI / NetBanking</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStep('summary')}
                  className="w-full sm:w-auto px-4 py-3.5 text-[#A09A8E] hover:text-white text-xs underline underline-offset-4"
                >
                  Review Order
                </button>
              </div>
            </div>
          )}

          {/* ========================================================
              STEP 4: ORDER CONFIRMATION SCREEN
             ======================================================== */}
          {step === 'success' && placedOrder && (
            <div className="py-6 space-y-6 text-center">
              {/* Telugu Crest Emblem Badge */}
              <div className="w-16 h-16 rounded-full bg-gradient-to-b from-[#2E2618] to-[#120F09] border-2 border-[#D4AF37] mx-auto flex items-center justify-center text-[#D4AF37] shadow-[0_0_35px_rgba(212,175,55,0.35)]">
                <span className="font-telugu text-2xl font-bold">ఆరు</span>
              </div>

              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-[#D4AF37] font-semibold mb-1">
                  Commission Registered in Guild Ledger
                </div>
                <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#FAF7F0]">
                  Order Confirmed
                </h3>
                <div className="mt-2 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161824] border border-[#2E3348] text-xs font-mono">
                  <span className="text-[#A09A8E]">Order ID:</span>
                  <strong className="text-[#D4AF37]">{placedOrder.orderNumber}</strong>
                  <button
                    type="button"
                    onClick={handleCopyOrderId}
                    className="p-1 text-[#A09A8E] hover:text-white transition-colors"
                    title="Copy Order ID"
                  >
                    {copiedOrderId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Delivery Timeline Details */}
              <div className="p-4 bg-[#12141D] border border-[#252838] rounded-sm text-left max-w-lg mx-auto space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[#1F2230] text-xs">
                  <span className="text-[#A09A8E]">Estimated Delivery Timeline:</span>
                  <span className="font-mono text-[#D4AF37] font-bold">{placedOrder.estimatedDelivery}</span>
                </div>

                <div className="text-xs space-y-1">
                  <div className="text-[#FAF7F0] font-semibold flex items-center gap-2">
                    <Truck className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Armored White-Glove Dispatch Destination:</span>
                  </div>
                  <p className="text-[#A09A8E] text-[11px] pl-5">
                    {placedOrder.shippingAddress.fullName} • {placedOrder.shippingAddress.address}, {placedOrder.shippingAddress.city} ({placedOrder.shippingAddress.postalCode})
                  </p>
                </div>

                {/* Handloom Journey Milestones */}
                <div className="pt-2 border-t border-[#1F2230] space-y-2">
                  <div className="text-xs font-semibold text-[#FAF7F0] flex items-center gap-1.5 font-cinzel">
                    <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Next Steps in Handloom Creation:</span>
                  </div>
                  <ul className="space-y-1.5 text-[11px] text-[#C8C2B7] pl-4 list-disc">
                    <li>Kanchipuram Guild Master Weaver assigned for warp inspection.</li>
                    <li>24-Karat hallmarking certificate generated by government assay.</li>
                    <li>Live loom photos sent to your WhatsApp at each milestone.</li>
                  </ul>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <a
                  href={`https://wa.me/918008006600?text=${encodeURIComponent(`Hello AARU Atelier, I have placed order ${placedOrder.orderNumber}. Please send live loom photos to this number.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-6 py-3.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/60 text-emerald-300 text-xs font-semibold uppercase tracking-wider rounded-sm flex items-center justify-center gap-2 transition-all"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>Receive WhatsApp Updates</span>
                </a>

                <button
                  onClick={onClose}
                  className="w-full sm:w-auto px-8 py-3.5 bg-[#D4AF37] hover:bg-[#FFE59E] text-black text-xs font-semibold uppercase tracking-wider rounded-sm transition-all"
                >
                  Return to Atelier
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
