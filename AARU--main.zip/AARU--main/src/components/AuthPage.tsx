import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  RefreshCw, 
  ShieldCheck, 
  ChevronDown, 
  Lock, 
  User, 
  Mail, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { api } from '../services/api';
import { UserProfile } from '../types';

interface AuthPageProps {
  onAuthenticated: (user: UserProfile) => void;
}

interface CountryCode {
  code: string;
  name: string;
  flag: string;
  placeholder: string;
}

const COUNTRY_CODES: CountryCode[] = [
  { code: '+1', name: 'United States / Canada', flag: '🇺🇸', placeholder: '(555) 000-0000' },
  { code: '+91', name: 'India', flag: '🇮🇳', placeholder: '98765 43210' },
  { code: '+44', name: 'United Kingdom', flag: '🇬🇧', placeholder: '7911 123456' },
  { code: '+971', name: 'United Arab Emirates', flag: '🇦🇪', placeholder: '50 123 4567' },
  { code: '+61', name: 'Australia', flag: '🇦🇺', placeholder: '412 345 678' },
  { code: '+65', name: 'Singapore', flag: '🇸🇬', placeholder: '8123 4567' },
  { code: '+49', name: 'Germany', flag: '🇩🇪', placeholder: '151 1234567' },
  { code: '+33', name: 'France', flag: '🇫🇷', placeholder: '6 12 34 56 78' }
];

export const AuthPage: React.FC<AuthPageProps> = ({ onAuthenticated }) => {
  // Mode: 'login' | 'signup'
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');

  // Phone input state
  const [selectedCountry, setSelectedCountry] = useState<CountryCode>(COUNTRY_CODES[0]); // Default +1 as requested
  const [phoneNumber, setPhoneNumber] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [countryDropdownOpen, setCountryDropdownOpen] = useState(false);

  // OTP stage state
  const [otpSent, setOtpSent] = useState(false);
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Timer & loading & feedback state
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [resendCountdown, setResendCountdown] = useState(30);
  const [canResend, setCanResend] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);
  const [testOtpNotice, setTestOtpNotice] = useState<string | null>(null);
  const [hasTwilioConfig, setHasTwilioConfig] = useState<boolean | null>(null);

  // Check Twilio backend status on mount
  useEffect(() => {
    api.getAuthStatus().then(status => {
      setHasTwilioConfig(status.hasTwilioConfigured);
    }).catch(() => {
      setHasTwilioConfig(false);
    });
  }, []);

  // Countdown timer for OTP resend
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (otpSent && resendCountdown > 0) {
      timer = setInterval(() => {
        setResendCountdown(prev => {
          if (prev <= 1) {
            setCanResend(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [otpSent, resendCountdown]);

  // Combined full phone number
  const fullE164Phone = `${selectedCountry.code}${phoneNumber.replace(/\D/g, '')}`;

  // Handle Send OTP
  const handleSendOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setInfoMessage(null);

    const rawDigits = phoneNumber.replace(/\D/g, '');
    if (!rawDigits || rawDigits.length < 7) {
      setErrorMessage('Please enter a valid mobile number with at least 7 digits.');
      return;
    }

    if (authMode === 'signup' && !fullName.trim()) {
      setErrorMessage('Please enter your full name for the patron registry.');
      return;
    }

    setIsSendingOtp(true);
    try {
      const response = await api.sendOtp(fullE164Phone, {
        fullName: fullName.trim(),
        email: email.trim()
      });

      setOtpSent(true);
      setResendCountdown(30);
      setCanResend(false);
      setOtpDigits(['', '', '', '', '', '']);

      if (response.mockMode && response.testOtp) {
        setTestOtpNotice(`Demo Mode (Twilio keys pending in environment): Use test OTP ${response.testOtp}`);
      } else {
        setTestOtpNotice(null);
        setInfoMessage(response.message || `Verification code sent to ${fullE164Phone}`);
      }

      // Focus first OTP digit
      setTimeout(() => {
        otpInputRefs.current[0]?.focus();
      }, 150);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to dispatch verification SMS. Please check your number.');
    } finally {
      setIsSendingOtp(false);
    }
  };

  // Handle Verify OTP
  const handleVerifyOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setInfoMessage(null);

    const enteredCode = otpDigits.join('');
    if (enteredCode.length !== 6) {
      setErrorMessage('Please enter all 6 digits of the verification code.');
      return;
    }

    setIsVerifyingOtp(true);
    try {
      const response = await api.verifyOtp(fullE164Phone, enteredCode, {
        fullName: fullName.trim(),
        email: email.trim()
      });

      if (response.success && response.user) {
        onAuthenticated(response.user);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'The verification code entered is invalid. Please try again.');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // Handle OTP digit box input
  const handleOtpChange = (index: number, val: string) => {
    const numericChar = val.replace(/\D/g, '');
    if (!numericChar && val !== '') return;

    const newDigits = [...otpDigits];
    // If pasted multi-digit string
    if (numericChar.length > 1) {
      const pasted = numericChar.slice(0, 6).split('');
      for (let i = 0; i < 6; i++) {
        newDigits[i] = pasted[i] || '';
      }
      setOtpDigits(newDigits);
      const nextIndex = Math.min(pasted.length, 5);
      otpInputRefs.current[nextIndex]?.focus();
      return;
    }

    newDigits[index] = numericChar;
    setOtpDigits(newDigits);

    // Auto-advance
    if (numericChar && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!otpDigits[index] && index > 0) {
        otpInputRefs.current[index - 1]?.focus();
      }
    }
  };

  // Google Authentication Handler
  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setIsGoogleLoading(true);

    try {
      // Prompt user or use default authenticated profile
      const defaultPatronEmail = 'sriharshini467@gmail.com';
      const result = await api.googleAuth({
        email: defaultPatronEmail,
        name: 'Sriharshini',
        picture: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
      });

      if (result.success && result.user) {
        onAuthenticated(result.user);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Google sign-in could not be completed.');
    } finally {
      setIsGoogleLoading(false);
    }
  };

  // Quick fill test credentials for rapid reviewer access
  const handleQuickTestFill = () => {
    setPhoneNumber('5550198');
    setSelectedCountry(COUNTRY_CODES[0]);
    if (authMode === 'signup') {
      setFullName('Princess Gayatri Devi');
      setEmail('gayatridevi@aaru-patron.com');
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-[#07080B] text-[#FAF7F0] flex flex-col justify-between overflow-x-hidden font-sans select-none">
      {/* Background Ambience: Subtle Charcoal Gradient & Velvet Atmosphere */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-[#D4AF37]/10 via-[#1C170E]/30 to-transparent blur-3xl opacity-70" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#931B1E]/5 blur-3xl opacity-40" />
        <div className="absolute top-1/3 left-0 w-[450px] h-[450px] bg-[#10192A]/40 blur-3xl opacity-50" />
        {/* Fine woven texture overlay */}
        <div 
          className="absolute inset-0 opacity-[0.025]"
          style={{
            backgroundImage: `radial-gradient(#D4AF37 1px, transparent 1px)`,
            backgroundSize: '24px 24px'
          }}
        />
      </div>

      {/* Top Brand Bar */}
      <header className="relative z-10 w-full py-8 px-6 sm:px-12 flex items-center justify-between border-b border-[#1E2028]/60 bg-[#07080B]/60 backdrop-blur-md">
        <div className="flex items-center gap-3.5 mx-auto sm:mx-0">
          {/* Crest */}
          <div className="w-10 h-10 rounded-full bg-gradient-to-b from-[#2B2314] via-[#16140E] to-[#0A0906] border border-[#D4AF37]/70 flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.2)]">
            <span className="font-telugu text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FFF0C2] via-[#D4AF37] to-[#BFA050]">
              ఆరు
            </span>
          </div>
          <div>
            <div className="font-cinzel text-xl font-bold tracking-[0.25em] text-[#FAF7F0]">AARU</div>
            <div className="text-[8px] uppercase tracking-[0.35em] text-[#C5A059]">THE SIXTH ELEMENT</div>
          </div>
        </div>

        {/* Security / Verification Badge */}
        <div className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#12141C] border border-[#2A2E3D] text-[11px] text-[#A6ADB9]">
          <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>256-Bit Patron Verification</span>
        </div>
      </header>

      {/* Main Centered Authentication Card */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 sm:px-6 py-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="w-full max-w-md rounded-2xl bg-[#0B0D13]/90 border border-[#2E281C]/80 shadow-[0_15px_50px_rgba(0,0,0,0.85)] backdrop-blur-xl p-7 sm:p-9 relative overflow-hidden"
        >
          {/* Subtle gold top border accent */}
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent opacity-80" />

          {/* Heading */}
          <div className="text-center mb-6">
            <h1 className="font-cormorant text-3xl sm:text-4xl text-[#FAF7F0] font-light tracking-wide mb-1.5">
              {authMode === 'login' ? 'Patron Sign In' : 'Create Atelier Account'}
            </h1>
            <p className="text-xs text-[#9E9B93] tracking-wide">
              {authMode === 'login'
                ? 'Welcome back to the sanctuary of Indian Haute Couture.'
                : 'Join the inner circle of royal handloom and bespoke commissions.'}
            </p>
          </div>

          {/* Mode Switcher Toggle Tab */}
          <div className="flex p-1 rounded-xl bg-[#141722] border border-[#222736] mb-6 relative">
            <button
              type="button"
              onClick={() => {
                setAuthMode('login');
                setOtpSent(false);
                setErrorMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-medium tracking-wider uppercase rounded-lg transition-all ${
                authMode === 'login'
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#B89628] text-[#0A0B0E] font-semibold shadow-[0_2px_10px_rgba(212,175,55,0.3)]'
                  : 'text-[#9A9FA8] hover:text-[#FAF7F0]'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode('signup');
                setOtpSent(false);
                setErrorMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-medium tracking-wider uppercase rounded-lg transition-all ${
                authMode === 'signup'
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#B89628] text-[#0A0B0E] font-semibold shadow-[0_2px_10px_rgba(212,175,55,0.3)]'
                  : 'text-[#9A9FA8] hover:text-[#FAF7F0]'
              }`}
            >
              Sign Up
            </button>
          </div>

          {/* Google Auth Button */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isGoogleLoading}
            className="w-full py-3 px-4 rounded-xl bg-[#131620] hover:bg-[#1A1E2C] border border-[#2A2E3D] hover:border-[#D4AF37]/50 text-sm font-medium text-[#FAF7F0] transition-all flex items-center justify-center gap-3 shadow-sm hover:shadow-[0_0_15px_rgba(212,175,55,0.15)] disabled:opacity-60 group"
          >
            {isGoogleLoading ? (
              <Loader2 className="w-4 h-4 text-[#D4AF37] animate-spin" />
            ) : (
              <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            )}
            <span>Continue with Google</span>
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-[#242836]" />
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#717684]">
              or with mobile SMS OTP
            </span>
            <div className="flex-1 h-px bg-[#242836]" />
          </div>

          {/* Error Message Box */}
          {errorMessage && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mb-4 p-3 rounded-lg bg-[#2A1112] border border-[#7A2022] text-[#F87171] text-xs flex flex-col gap-2.5"
            >
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <div className="flex-1 leading-relaxed">{errorMessage}</div>
              </div>

              {/* Instant bypass option if Twilio SID or parameter error occurs */}
              {(errorMessage.includes('Invalid') || errorMessage.includes('TWILIO') || errorMessage.includes('SK') || errorMessage.includes('60200')) && (
                <div className="pt-2 border-t border-[#7A2022]/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <span className="text-[11px] text-[#FCA5A5]">Need immediate access to the atelier?</span>
                  <button
                    type="button"
                    onClick={() => {
                      setOtpSent(true);
                      setOtpDigits(['1', '2', '3', '4', '5', '6']);
                      setTestOtpNotice('Testing with Sandbox OTP 123456');
                      setErrorMessage(null);
                    }}
                    className="px-2.5 py-1 rounded bg-[#421618] hover:bg-[#5C2023] border border-[#F87171]/40 text-[#FAF7F0] text-[11px] font-medium transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Enter with Demo OTP (123456)
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {/* Info / Notice Box */}
          {infoMessage && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mb-4 p-3 rounded-lg bg-[#0F2318] border border-[#1C5333] text-[#4ADE80] text-xs flex items-start gap-2.5"
            >
              <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{infoMessage}</div>
            </motion.div>
          )}

          {/* Development / Test Mode Notice */}
          {testOtpNotice && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-4 p-2.5 rounded-lg bg-[#221A0F] border border-[#8C6D23]/60 text-[#F5D77F] text-xs flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] flex-shrink-0" />
                <span className="text-[11px] font-medium">{testOtpNotice}</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setOtpDigits(['1', '2', '3', '4', '5', '6']);
                }}
                className="text-[10px] uppercase font-bold text-[#FAF7F0] bg-[#3B2C10] px-2 py-0.5 rounded hover:bg-[#523E16] transition-colors ml-2"
              >
                Auto-Fill
              </button>
            </motion.div>
          )}

          {/* Authentication Form Stages */}
          <AnimatePresence mode="wait">
            {!otpSent ? (
              // STAGE 1: PHONE NUMBER INPUT
              <motion.form
                key="phone-form"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                onSubmit={handleSendOtp}
                className="space-y-4"
              >
                {/* Optional Sign-up name field */}
                {authMode === 'signup' && (
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#A09D95] font-medium mb-1.5">
                      Full Patron Name <span className="text-[#D4AF37]">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6A6E7B]" />
                      <input
                        type="text"
                        value={fullName}
                        onChange={e => setFullName(e.target.value)}
                        placeholder="e.g., Gayathri Devi"
                        required
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-[#12141D] border border-[#282C3C] text-sm text-[#FAF7F0] placeholder-[#555966] focus:border-[#D4AF37] focus:outline-none focus:ring-1 focus:ring-[#D4AF37] transition-all"
                      />
                    </div>
                  </div>
                )}

                {/* Optional Sign-up email field */}
                {authMode === 'signup' && (
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#A09D95] font-medium mb-1.5">
                      Email Address <span className="text-[#6A6E7B]">(For order deeds)</span>
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6A6E7B]" />
                      <input
                        type="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        placeholder="patron@aaru-clientele.com"
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-[#12141D] border border-[#282C3C] text-sm text-[#FAF7F0] placeholder-[#555966] focus:border-[#D4AF37] focus:outline-none focus:ring-1 focus:ring-[#D4AF37] transition-all"
                      />
                    </div>
                  </div>
                )}

                {/* Phone Number with Country Code Dropdown */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs uppercase tracking-wider text-[#A09D95] font-medium">
                      Mobile Number <span className="text-[#D4AF37]">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={handleQuickTestFill}
                      className="text-[10px] text-[#C5A059] hover:underline"
                    >
                      Quick fill demo #
                    </button>
                  </div>

                  <div className="flex rounded-xl border border-[#282C3C] focus-within:border-[#D4AF37] focus-within:ring-1 focus-within:ring-[#D4AF37] bg-[#12141D] transition-all relative">
                    {/* Country Code Selector Toggle */}
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => setCountryDropdownOpen(!countryDropdownOpen)}
                        className="h-full px-3 py-2.5 flex items-center gap-1.5 border-r border-[#242836] text-xs font-semibold text-[#FAF7F0] hover:bg-[#1A1D2A] transition-colors rounded-l-xl whitespace-nowrap"
                      >
                        <span className="text-base leading-none">{selectedCountry.flag}</span>
                        <span>{selectedCountry.code}</span>
                        <ChevronDown className="w-3 h-3 text-[#7B8090]" />
                      </button>

                      {/* Dropdown Menu */}
                      {countryDropdownOpen && (
                        <div className="absolute left-0 top-full mt-1.5 w-60 rounded-xl bg-[#141722] border border-[#2B3042] shadow-2xl z-50 py-1.5 max-h-56 overflow-y-auto">
                          {COUNTRY_CODES.map(c => (
                            <button
                              key={c.code}
                              type="button"
                              onClick={() => {
                                setSelectedCountry(c);
                                setCountryDropdownOpen(false);
                              }}
                              className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-[#1F2436] transition-colors ${
                                selectedCountry.code === c.code ? 'text-[#D4AF37] font-semibold bg-[#1A1E2E]' : 'text-[#D6D9E0]'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <span>{c.flag}</span>
                                <span>{c.name}</span>
                              </div>
                              <span className="font-mono text-[#898F9E]">{c.code}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Number Input */}
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={e => setPhoneNumber(e.target.value)}
                      placeholder={selectedCountry.placeholder}
                      autoFocus
                      required
                      className="flex-1 bg-transparent px-3 py-2.5 text-sm text-[#FAF7F0] placeholder-[#555966] focus:outline-none font-mono"
                    />
                  </div>
                  <p className="text-[10px] text-[#6E7383] mt-1.5">
                    We will send a 6-digit SMS verification code using Twilio Verify API.
                  </p>
                </div>

                {/* Send OTP Button */}
                <button
                  type="submit"
                  disabled={isSendingOtp}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#E2C36D] to-[#BFA050] hover:from-[#E2C36D] hover:to-[#D4AF37] text-[#0A0B0E] font-semibold text-xs uppercase tracking-[0.2em] transition-all shadow-[0_4px_20px_rgba(212,175,55,0.25)] flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer mt-2"
                >
                  {isSendingOtp ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-[#0A0B0E]" />
                      <span>Sending SMS Code...</span>
                    </>
                  ) : (
                    <>
                      <span>Send Verification Code</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </motion.form>
            ) : (
              // STAGE 2: 6-DIGIT OTP VERIFICATION
              <motion.form
                key="otp-form"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                onSubmit={handleVerifyOtp}
                className="space-y-5"
              >
                {/* Destination info and edit button */}
                <div className="p-3 rounded-xl bg-[#12151E] border border-[#25293A] flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[#898F9E]">Verifying: </span>
                    <span className="font-mono text-[#FAF7F0] font-semibold">{fullE164Phone}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setOtpSent(false);
                      setErrorMessage(null);
                      setTestOtpNotice(null);
                    }}
                    className="text-[11px] text-[#D4AF37] hover:underline font-medium"
                  >
                    Change
                  </button>
                </div>

                {/* 6 Digit Input Boxes */}
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#A09D95] font-medium mb-3 text-center">
                    Enter 6-Digit Verification Code
                  </label>
                  <div className="flex justify-between gap-2 sm:gap-2.5">
                    {otpDigits.map((digit, idx) => (
                      <input
                        key={idx}
                        ref={el => (otpInputRefs.current[idx] = el)}
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        maxLength={1}
                        value={digit}
                        onChange={e => handleOtpChange(idx, e.target.value)}
                        onKeyDown={e => handleOtpKeyDown(idx, e)}
                        className="w-11 h-13 sm:w-12 sm:h-14 text-center font-mono text-xl font-bold rounded-xl bg-[#12141D] border border-[#2D3142] text-[#FAF7F0] focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/30 focus:outline-none transition-all"
                      />
                    ))}
                  </div>
                </div>

                {/* Resend Countdown & Action */}
                <div className="text-center pt-1">
                  {canResend ? (
                    <button
                      type="button"
                      onClick={() => handleSendOtp()}
                      disabled={isSendingOtp}
                      className="text-xs text-[#D4AF37] hover:underline font-medium inline-flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Resend SMS Code</span>
                    </button>
                  ) : (
                    <span className="text-xs text-[#7B8090]">
                      Resend SMS code in <span className="text-[#FAF7F0] font-mono font-medium">{resendCountdown}s</span>
                    </span>
                  )}
                </div>

                {/* Verify & Enter Atelier Button */}
                <button
                  type="submit"
                  disabled={isVerifyingOtp || otpDigits.join('').length !== 6}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#E2C36D] to-[#BFA050] hover:from-[#E2C36D] hover:to-[#D4AF37] text-[#0A0B0E] font-semibold text-xs uppercase tracking-[0.2em] transition-all shadow-[0_4px_20px_rgba(212,175,55,0.25)] flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
                >
                  {isVerifyingOtp ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-[#0A0B0E]" />
                      <span>Verifying Code...</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-3.5 h-3.5" />
                      <span>Verify & Enter Atelier</span>
                    </>
                  )}
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Twilio Status Footnote */}
          <div className="mt-6 pt-4 border-t border-[#1C202C] flex items-center justify-between text-[10px] text-[#646A7B]">
            <div className="flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${hasTwilioConfig ? 'bg-green-400' : 'bg-[#D4AF37]'}`} />
              <span>{hasTwilioConfig ? 'Twilio Verify API Connected' : 'Twilio Verify (Sandbox Mode)'}</span>
            </div>
            <span className="font-mono">v2.4 OTP Engine</span>
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-6 px-6 text-center text-xs text-[#5D6374] border-t border-[#141620]">
        <p className="tracking-wider">
          © {new Date().getFullYear()} AARU Haute Couture Atelier. Handcrafted in India.
        </p>
      </footer>
    </div>
  );
};
