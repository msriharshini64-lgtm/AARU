import React, { useState } from 'react';
import { X, User, Package, Ruler, Sparkles, CheckCircle2, Clock, Truck, ShieldCheck, Heart, ChevronRight, Save, LogOut, ArrowRight, Trash2 } from 'lucide-react';
import { UserProfile, Order, Product } from '../types';
import { ELEMENT_METADATA } from '../data/mockData';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  orders: Order[];
  allProducts: Product[];
  onUpdateProfile: (updated: Partial<UserProfile>) => Promise<void>;
  currency: 'INR' | 'USD';
  onSelectProduct: (p: Product) => void;
  initialTab?: 'orders' | 'measurements' | 'quiz' | 'wishlist';
  onLogout?: () => void;
  onRemoveFromWishlist?: (productId: string) => void;
  onNavigateWishlistPage?: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  orders,
  allProducts,
  onUpdateProfile,
  currency,
  onSelectProduct,
  initialTab = 'orders',
  onLogout,
  onRemoveFromWishlist,
  onNavigateWishlistPage
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'measurements' | 'quiz' | 'wishlist'>(initialTab);
  const [measurements, setMeasurements] = useState(profile.measurements);
  const [savedSuccess, setSavedSuccess] = useState(false);
  // Quiz state - all hooks must be declared before any conditional return
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({});
  const [quizResult, setQuizResult] = useState<string | null>(profile.elementAffinity);

  // Sync activeTab when initialTab or isOpen changes
  React.useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  React.useEffect(() => {
    setMeasurements(profile.measurements);
  }, [profile.measurements]);

  if (!isOpen) return null;

  const handleSaveMeasurements = async (e: React.FormEvent) => {
    e.preventDefault();
    await onUpdateProfile({ measurements });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const wishlistedProducts = allProducts.filter(p => profile.wishlist.includes(p.id));

  const runQuizEvaluation = () => {
    // Simple heuristic mapping to elements
    const choices = Object.values(quizAnswers);
    if (choices.includes('aaru') || choices.length >= 2) {
      setQuizResult('aaru');
      onUpdateProfile({ elementAffinity: 'aaru' });
    } else {
      setQuizResult('ether');
      onUpdateProfile({ elementAffinity: 'ether' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="relative max-w-4xl w-full bg-[#0E1016] border border-[#3A3832] rounded-sm shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 bg-[#141620] border-b border-[#252838] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-b from-[#2E2618] to-[#120F09] border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] font-telugu text-lg font-bold">
              ఆరు
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-cinzel text-base font-bold text-[#FAF7F0] tracking-wider uppercase">
                  My Account & Saved Items
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40 uppercase font-semibold">
                  {profile.memberTier}
                </span>
              </div>
              <div className="text-[11px] text-[#A09A8E]">
                {profile.fullName} · {profile.email}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {onLogout && (
              <button
                type="button"
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                className="px-3 py-1 rounded-full border border-red-500/30 hover:border-red-500/60 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                title="Sign out of account"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-[#1E2130] text-[#A09A8E] hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 bg-[#11131A] border-b border-[#252838] flex items-center gap-4 text-xs overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('wishlist')}
            className={`py-3 font-medium border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'wishlist' ? 'border-[#D4AF37] text-[#D4AF37]' : 'border-transparent text-[#A09A8E] hover:text-white'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            <span>Wishlist ({wishlistedProducts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 font-medium border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'orders' ? 'border-[#D4AF37] text-[#D4AF37]' : 'border-transparent text-[#A09A8E] hover:text-white'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Order History ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('measurements')}
            className={`py-3 font-medium border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'measurements' ? 'border-[#D4AF37] text-[#D4AF37]' : 'border-transparent text-[#A09A8E] hover:text-white'
            }`}
          >
            <Ruler className="w-3.5 h-3.5" />
            <span>Saved Measurements</span>
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`py-3 font-medium border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'quiz' ? 'border-[#D4AF37] text-[#D4AF37]' : 'border-transparent text-[#A09A8E] hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Style Preferences</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* TAB 1: ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              {orders.length === 0 ? (
                <div className="text-center py-16 text-[#7A756C]">
                  <Package className="w-10 h-10 mx-auto opacity-40 mb-2" />
                  <p className="text-sm">No commissions currently registered.</p>
                </div>
              ) : (
                orders.map(order => (
                  <div
                    key={order.id}
                    className="p-5 bg-[#12141C] border border-[#252838] rounded-sm space-y-4"
                  >
                    {/* Order Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#22242E] gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-cinzel text-base font-bold text-[#FAF7F0]">
                            {order.orderNumber}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/40">
                            {order.status}
                          </span>
                        </div>
                        <div className="text-[11px] text-[#A09A8E] mt-0.5">
                          Commissioned on {order.date} · Estimated Dispatch: {order.estimatedDelivery}
                        </div>
                      </div>

                      <div className="text-sm font-mono font-bold text-[#D4AF37]">
                        {currency === 'INR' ? `₹${order.total.toLocaleString('en-IN')}` : `$${Math.round(order.total / 83)}`}
                      </div>
                    </div>

                    {/* Order Items */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {order.items.map((it, idx) => (
                        <div key={idx} className="flex items-center gap-3 p-2 bg-[#171924] rounded-sm">
                          <img
                            src={it.productImage}
                            alt={it.productName}
                            referrerPolicy="no-referrer"
                            className="w-12 h-14 object-cover rounded"
                          />
                          <div className="text-xs overflow-hidden">
                            <div className="font-medium text-[#FAF7F0] truncate font-cinzel">{it.productName}</div>
                            <div className="text-[#A09A8E]">Qty: {it.quantity} · Size: {it.size}</div>
                            {it.monogram && (
                              <div className="text-[10px] text-[#D4AF37] font-mono">Monogram: {it.monogram}</div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Tracking Milestones Timeline */}
                    <div className="pt-3 border-t border-[#22242E]">
                      <div className="text-xs uppercase tracking-widest text-[#C5A059] font-medium mb-3 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Order Tracking & Progress</span>
                      </div>

                      <div className="space-y-3 pl-2 relative border-l border-[#2E3345] ml-2">
                        {order.trackingMilestones.map((m, idx) => (
                          <div key={idx} className="relative pl-5 text-xs">
                            <span
                              className={`absolute -left-[9px] top-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                m.completed
                                  ? 'bg-[#D4AF37] border-black text-black'
                                  : 'bg-[#12141C] border-[#3A4058] text-transparent'
                              }`}
                            >
                              {m.completed && <CheckCircle2 className="w-3 h-3 fill-black" />}
                            </span>
                            <div className={`font-semibold ${m.completed ? 'text-[#FAF7F0]' : 'text-[#7A756C]'}`}>
                              {m.title}
                            </div>
                            <div className="text-[11px] text-[#A09A8E] mt-0.5">
                              {m.description}
                            </div>
                            <div className="text-[10px] font-mono text-[#6A655D] mt-0.5">
                              {m.date}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 2: MEASUREMENTS */}
          {activeTab === 'measurements' && (
            <form onSubmit={handleSaveMeasurements} className="max-w-xl mx-auto space-y-5">
              <div className="p-4 bg-[#141620] border border-[#252838] rounded-sm text-xs text-[#C8C2B7] space-y-1">
                <div className="font-semibold text-[#D4AF37] flex items-center gap-1.5">
                  <Ruler className="w-4 h-4" />
                  <span>Custom Tailoring Measurements</span>
                </div>
                <p className="text-[11px] text-[#A09A8E] leading-relaxed">
                  Measurements saved here are stored in your profile and automatically applied whenever you select custom sizing during checkout.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="text-[10px] text-[#A09A8E] uppercase block mb-1 font-mono">Bust / Chest (inches)</label>
                  <input
                    type="text"
                    value={measurements.bustChest}
                    onChange={e => setMeasurements({ ...measurements, bustChest: e.target.value })}
                    className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#A09A8E] uppercase block mb-1 font-mono">Natural Waist (inches)</label>
                  <input
                    type="text"
                    value={measurements.waist}
                    onChange={e => setMeasurements({ ...measurements, waist: e.target.value })}
                    className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#A09A8E] uppercase block mb-1 font-mono">Hips (inches)</label>
                  <input
                    type="text"
                    value={measurements.hips}
                    onChange={e => setMeasurements({ ...measurements, hips: e.target.value })}
                    className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#A09A8E] uppercase block mb-1 font-mono">Cross Shoulder (inches)</label>
                  <input
                    type="text"
                    value={measurements.shoulder}
                    onChange={e => setMeasurements({ ...measurements, shoulder: e.target.value })}
                    className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#A09A8E] uppercase block mb-1 font-mono">Height</label>
                  <input
                    type="text"
                    value={measurements.height}
                    onChange={e => setMeasurements({ ...measurements, height: e.target.value })}
                    className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#A09A8E] uppercase block mb-1 font-mono">Sleeve Length (inches)</label>
                  <input
                    type="text"
                    value={measurements.sleeveLength}
                    onChange={e => setMeasurements({ ...measurements, sleeveLength: e.target.value })}
                    className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="submit"
                  className="px-6 py-3 bg-[#D4AF37] hover:bg-[#E5C07B] text-black font-semibold text-xs uppercase tracking-wider rounded-sm flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Measurements</span>
                </button>

                {savedSuccess && (
                  <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Measurements Saved
                  </span>
                )}
              </div>
            </form>
          )}

          {/* TAB 3: QUIZ */}
          {activeTab === 'quiz' && (
            <div className="max-w-xl mx-auto space-y-6">
              <div className="text-center space-y-2">
                <div className="inline-block p-3 rounded-full bg-[#D4AF37]/10 text-[#D4AF37] font-telugu text-2xl font-bold">
                  ఆరు
                </div>
                <h3 className="font-cinzel text-xl font-bold text-[#FAF7F0]">
                  Style Preferences & Recommendations
                </h3>
                <p className="text-xs text-[#A09A8E]">
                  Answer a few simple questions to get curated styling, weave, and fabric suggestions.
                </p>
              </div>

              <div className="space-y-4 text-xs">
                <div className="p-4 bg-[#141620] border border-[#252838] rounded-sm space-y-2">
                  <div className="font-medium text-[#FAF7F0]">
                    1. When you attend an evening event, what texture do you prefer?
                  </div>
                  <div className="space-y-1.5 text-[#C8C2B7]">
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-[#1B1E2B] rounded">
                      <input
                        type="radio"
                        name="q1"
                        onChange={() => setQuizAnswers({ ...quizAnswers, 1: 'aaru' })}
                        className="accent-[#D4AF37]"
                      />
                      <span>Hand-spun silk with pure zari temple borders</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-[#1B1E2B] rounded">
                      <input
                        type="radio"
                        name="q1"
                        onChange={() => setQuizAnswers({ ...quizAnswers, 1: 'ether' })}
                        className="accent-[#D4AF37]"
                      />
                      <span>Deep indigo velvet with metallic hand embroidery</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-[#1B1E2B] rounded">
                      <input
                        type="radio"
                        name="q1"
                        onChange={() => setQuizAnswers({ ...quizAnswers, 1: 'fire' })}
                        className="accent-[#D4AF37]"
                      />
                      <span>Vibrant red Kadwa silks and copper brocades</span>
                    </label>
                  </div>
                </div>

                <div className="p-4 bg-[#141620] border border-[#252838] rounded-sm space-y-2">
                  <div className="font-medium text-[#FAF7F0]">
                    2. What quality most defines your ideal outfit?
                  </div>
                  <div className="space-y-1.5 text-[#C8C2B7]">
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-[#1B1E2B] rounded">
                      <input
                        type="radio"
                        name="q2"
                        onChange={() => setQuizAnswers({ ...quizAnswers, 2: 'aaru' })}
                        className="accent-[#D4AF37]"
                      />
                      <span>Master craftsmanship and authentic handloom heritage</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 hover:bg-[#1B1E2B] rounded">
                      <input
                        type="radio"
                        name="q2"
                        onChange={() => setQuizAnswers({ ...quizAnswers, 2: 'air' })}
                        className="accent-[#D4AF37]"
                      />
                      <span>Lightweight drape and effortless ease of movement</span>
                    </label>
                  </div>
                </div>

                <button
                  onClick={runQuizEvaluation}
                  className="w-full py-3 bg-[#D4AF37] hover:bg-[#FFE59E] text-black font-semibold uppercase tracking-wider rounded-sm text-xs transition-all cursor-pointer"
                >
                  Get Style Recommendations
                </button>

                {quizResult && (
                  <div className="p-4 bg-[#1A1813] border border-[#D4AF37] rounded-sm text-center space-y-1">
                    <div className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-semibold">
                      Your Style Match:
                    </div>
                    <div className="font-cinzel text-lg font-bold text-white flex items-center justify-center gap-2">
                      <span>{ELEMENT_METADATA[quizResult]?.name}</span>
                      <span className="font-telugu text-[#D4AF37]">{ELEMENT_METADATA[quizResult]?.teluguName}</span>
                    </div>
                    <p className="text-xs text-[#A09A8E]">
                      {ELEMENT_METADATA[quizResult]?.description}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: WISHLIST */}
          {activeTab === 'wishlist' && (
            <div>
              {wishlistedProducts.length > 0 && onNavigateWishlistPage && (
                <div className="flex justify-end mb-3">
                  <button
                    onClick={() => {
                      onClose();
                      onNavigateWishlistPage();
                    }}
                    className="text-xs text-[#D4AF37] hover:underline flex items-center gap-1 cursor-pointer font-medium"
                  >
                    <span>View full wishlist page</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {wishlistedProducts.length === 0 ? (
                <div className="text-center py-16 text-[#7A756C]">
                  <Heart className="w-10 h-10 mx-auto opacity-30 mb-2 text-[#D4AF37]" />
                  <p className="text-sm">Your wishlist is empty.</p>
                  <p className="text-xs text-[#8E92A4] mt-1">Tap the heart icon on any product to save your favorites here.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {wishlistedProducts.map(prod => (
                    <div
                      key={prod.id}
                      className="p-3 bg-[#13151D] border border-[#252838] hover:border-[#D4AF37] rounded-sm flex items-center gap-3 group transition-all relative"
                    >
                      <img
                        src={prod.images[0]}
                        alt={prod.name}
                        referrerPolicy="no-referrer"
                        onClick={() => {
                          onClose();
                          onSelectProduct(prod);
                        }}
                        className="w-16 h-20 object-cover rounded cursor-pointer"
                      />
                      <div className="overflow-hidden flex-1">
                        <div
                          onClick={() => {
                            onClose();
                            onSelectProduct(prod);
                          }}
                          className="text-xs font-semibold text-[#FAF7F0] group-hover:text-[#D4AF37] truncate font-cinzel cursor-pointer"
                        >
                          {prod.name}
                        </div>
                        <div className="text-[11px] text-[#A09A8E] mt-0.5">{prod.fabric}</div>
                        <div className="text-xs font-mono font-bold text-[#D4AF37] mt-2">
                          {currency === 'INR' ? `₹${prod.price.toLocaleString('en-IN')}` : `$${Math.round(prod.price / 83)}`}
                        </div>
                      </div>

                      {onRemoveFromWishlist && (
                        <button
                          onClick={() => onRemoveFromWishlist(prod.id)}
                          className="text-[#6A7084] hover:text-rose-400 p-1.5 transition-colors cursor-pointer"
                          title="Remove from wishlist"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
