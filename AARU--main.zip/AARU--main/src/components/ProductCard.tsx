import React, { useState } from 'react';
import {
  Heart,
  MessageCircle,
  Clock,
  Eye,
  ShoppingBag,
  CheckCircle2,
  Check
} from 'lucide-react';
import { Product, ProductAvailability } from '../types';

interface ProductCardProps {
  product: Product;
  currency: 'INR' | 'USD';
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, size?: string) => void;
  onWhatsAppInquiry: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currency,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
  onWhatsAppInquiry
}) => {
  const [currentImgIndex, setCurrentImgIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'Free Size');
  const [showSizePicker, setShowSizePicker] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const formattedPrice = currency === 'INR'
    ? `₹${product.price.toLocaleString('en-IN')}`
    : `$${Math.round(product.price / 83).toLocaleString('en-US')}`;

  const handleQuickAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();

    // If multiple sizes and picker not open, open size selection
    if (product.sizes.length > 1 && !showSizePicker) {
      setShowSizePicker(true);
      return;
    }

    onAddToCart(product, selectedSize);
    setJustAdded(true);
    setShowSizePicker(false);
    setTimeout(() => setJustAdded(false), 2200);
  };

  const handleSelectSizeAndAdd = (e: React.MouseEvent, size: string) => {
    e.stopPropagation();
    setSelectedSize(size);
    onAddToCart(product, size);
    setJustAdded(true);
    setShowSizePicker(false);
    setTimeout(() => setJustAdded(false), 2200);
  };

  return (
    <div
      id={`product-card-${product.id}`}
      className="group relative bg-[#0C0E15] border border-[#212433] hover:border-[#D4AF37]/80 rounded-sm overflow-hidden transition-all duration-500 flex flex-col justify-between shadow-lg hover:shadow-[0_12px_35px_rgba(0,0,0,0.75)]"
    >
      {/* Visual Image Media Container */}
      <div className="relative aspect-[3/4] overflow-hidden bg-[#141622]">
        <img
          src={product.images[currentImgIndex] || product.images[0]}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105 cursor-pointer"
          onClick={() => onQuickView(product)}
        />

        {/* Multiple image preview dots */}
        {product.images.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity z-10">
            {product.images.map((_, i) => (
              <button
                key={i}
                type="button"
                onMouseEnter={() => setCurrentImgIndex(i)}
                onClick={e => {
                  e.stopPropagation();
                  setCurrentImgIndex(i);
                }}
                className={`w-2 h-2 rounded-full transition-all ${
                  i === currentImgIndex ? 'bg-[#D4AF37] scale-125' : 'bg-white/50 hover:bg-white'
                }`}
                aria-label={`View image ${i + 1}`}
              />
            ))}
          </div>
        )}

        {/* Wishlist Button */}
        <button
          id={`wishlist-btn-${product.id}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md border transition-all z-10 ${
            isWishlisted
              ? 'bg-[#D4AF37] text-black border-[#D4AF37] shadow-[0_0_12px_rgba(212,175,55,0.4)]'
              : 'bg-[#0B0C12]/75 text-[#C8C2B7] hover:text-white border-[#2F3447]'
          }`}
          title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-black' : ''}`} />
        </button>

        {/* Availability Badge Overlay (Top Right Below Wishlist or Bottom Edge) */}
        <div className="absolute bottom-3 left-3 z-10">
          {product.availability === 'in_stock' ? (
            <span className="px-2 py-1 rounded-sm text-[10px] font-semibold tracking-wider uppercase backdrop-blur-md bg-[#091811]/90 text-emerald-400 border border-emerald-500/50 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Ready to Ship</span>
            </span>
          ) : (
            <span className="px-2 py-1 rounded-sm text-[10px] font-semibold tracking-wider uppercase backdrop-blur-md bg-[#18130B]/90 text-[#D4AF37] border border-[#D4AF37]/50 flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#D4AF37]" />
              <span>Made to Order</span>
            </span>
          )}
        </div>

        {/* DESKTOP HOVER QUICK ADD SLIDE-UP OVERLAY */}
        <div className="hidden lg:flex absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/95 via-black/80 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-300 z-20 flex-col gap-2">
          {/* If Size Picker is open */}
          {showSizePicker ? (
            <div className="bg-[#121420] border border-[#2B3044] rounded p-2.5 space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between text-[11px] text-[#A6ABB9]">
                <span className="font-semibold uppercase tracking-wider">Select Size for Quick Add:</span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowSizePicker(false);
                  }}
                  className="text-[#FAF7F0] hover:text-[#D4AF37]"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {product.sizes.map(size => (
                  <button
                    key={size}
                    type="button"
                    onClick={(e) => handleSelectSizeAndAdd(e, size)}
                    className="px-2.5 py-1 text-xs rounded bg-[#1C2133] hover:bg-[#D4AF37] hover:text-black text-[#FAF7F0] border border-[#2F364E] transition-colors"
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleQuickAddClick}
                disabled={justAdded}
                className={`flex-1 py-2.5 px-3 rounded-sm text-xs uppercase tracking-[0.15em] font-semibold flex items-center justify-center gap-2 transition-all shadow-lg ${
                  justAdded
                    ? 'bg-emerald-600 text-black border border-emerald-500'
                    : 'bg-[#D4AF37] hover:bg-[#E5C07B] text-black border border-[#D4AF37]'
                }`}
              >
                {justAdded ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Added to Bag</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Quick Add ({selectedSize})</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onQuickView(product);
                }}
                className="p-2.5 rounded-sm bg-[#121420]/90 hover:bg-[#1C2032] border border-[#2B3044] text-[#FAF7F0] hover:text-[#D4AF37] transition-colors"
                title="Examine Details"
              >
                <Eye className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Product Information Body */}
      <div className="p-4 sm:p-5 flex flex-col flex-grow justify-between">
        <div>
          {/* Artisan & Loom hours note */}
          <div className="flex items-center justify-between text-[11px] text-[#8E93A6] mb-2 font-mono">
            <span className="flex items-center gap-1 text-[#C5A059]">
              <Clock className="w-3 h-3 text-[#D4AF37]" />
              {product.artisan.loomHours} Loom Hours
            </span>
            <span className="truncate max-w-[130px]" title={product.weaveOrigin}>
              {product.weaveOrigin.split(',')[0]}
            </span>
          </div>

          <h3
            onClick={() => onQuickView(product)}
            className="font-cinzel text-sm sm:text-base font-bold text-[#FAF7F0] group-hover:text-[#D4AF37] transition-colors cursor-pointer leading-snug line-clamp-1 mb-1"
          >
            {product.name}
          </h3>

          <p className="text-xs text-[#8E93A6] font-light line-clamp-2 mb-3 leading-relaxed">
            {product.subtitle}
          </p>

          {/* Fabric & Color Attributes Row */}
          <div className="flex items-center gap-2 mb-3 text-[11px] text-[#B5AF9F]">
            <span className="flex items-center gap-1">
              <span
                className="w-2 h-2 rounded-full border border-black/40"
                style={{ backgroundColor: product.colorHex || '#D4AF37' }}
              />
              <span className="text-[#C8C3B6]">{product.color}</span>
            </span>
            <span className="text-[#4E5366]">·</span>
            <span className="truncate text-[#9FA4B8]">{product.fabric}</span>
          </div>
        </div>

        {/* Commerce Price & Mobile Quick Actions Row */}
        <div className="pt-3 border-t border-[#1C202E] flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-base sm:text-lg font-mono font-bold text-[#FAF7F0] tracking-tight">
                {formattedPrice}
              </div>
              {product.originalPrice && (
                <div className="text-[11px] text-[#696D80] line-through font-mono">
                  {currency === 'INR'
                    ? `₹${product.originalPrice.toLocaleString('en-IN')}`
                    : `$${Math.round(product.originalPrice / 83).toLocaleString('en-US')}`}
                </div>
              )}
            </div>

            {/* Direct WhatsApp Consultation Icon */}
            <button
              type="button"
              onClick={() => onWhatsAppInquiry(product)}
              className="p-2 rounded-sm bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-600/40 text-emerald-400 hover:text-emerald-300 transition-colors"
              title="Inquire via WhatsApp Business"
            >
              <MessageCircle className="w-4 h-4" />
            </button>
          </div>

          {/* MOBILE QUICK ADD BUTTON: Always permanently accessible on mobile touch */}
          <div className="lg:hidden flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleQuickAddClick}
              disabled={justAdded}
              className={`w-full py-2.5 px-3 rounded-sm text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md ${
                justAdded
                  ? 'bg-emerald-600 text-black border border-emerald-500'
                  : 'bg-[#181C2B] hover:bg-[#D4AF37] hover:text-black border border-[#2E354C] hover:border-[#D4AF37] text-[#FAF7F0]'
              }`}
            >
              {justAdded ? (
                <>
                  <Check className="w-3.5 h-3.5 text-black" />
                  <span>Added</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Quick Add</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => onQuickView(product)}
              className="py-2.5 px-3 rounded-sm bg-[#121420] border border-[#2B3044] text-[#FAF7F0] hover:text-[#D4AF37] text-xs font-semibold uppercase tracking-wider"
              title="Inspect"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
