import React, { useState } from 'react';
import { X, Heart, ShoppingBag, Trash2, ArrowRight, Check } from 'lucide-react';
import { Product, CartItem } from '../types';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistIds?: string[];
  wishlistProductIds?: string[];
  allProducts: Product[];
  currency?: 'INR' | 'USD';
  onRemoveFromWishlist?: (productId: string) => void;
  onRemoveWishlist?: (productId: string) => void;
  onAddToCart?: (item: CartItem) => void;
  onMoveToCart?: (productId: string, size?: string) => void;
  onMoveAllToCart?: () => void;
  onOpenCart?: () => void;
  onSelectProduct?: (product: Product) => void;
  onViewWishlistPage?: () => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistIds,
  wishlistProductIds,
  allProducts,
  currency = 'INR',
  onRemoveFromWishlist,
  onRemoveWishlist,
  onAddToCart,
  onMoveToCart,
  onMoveAllToCart,
  onOpenCart,
  onSelectProduct,
  onViewWishlistPage
}) => {
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({});
  const [addedItemIds, setAddedItemIds] = useState<Record<string, boolean>>({});

  if (!isOpen) return null;

  const rawIds = wishlistIds || wishlistProductIds || [];
  const wishlistedProducts = allProducts.filter(p => rawIds.includes(p.id));

  const handleSizeChange = (productId: string, size: string) => {
    setSelectedSizes(prev => ({ ...prev, [productId]: size }));
  };

  const handleRemove = (productId: string) => {
    if (onRemoveFromWishlist) {
      onRemoveFromWishlist(productId);
    } else if (onRemoveWishlist) {
      onRemoveWishlist(productId);
    }
  };

  const handlePushToCart = (product: Product) => {
    const size = selectedSizes[product.id] || product.sizes[0] || 'Standard';
    if (onAddToCart) {
      onAddToCart({
        product,
        size,
        quantity: 1
      });
    } else if (onMoveToCart) {
      onMoveToCart(product.id, size);
    }

    setAddedItemIds(prev => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedItemIds(prev => ({ ...prev, [product.id]: false }));
    }, 2000);
  };

  const handleMoveAll = () => {
    if (onMoveAllToCart) {
      onMoveAllToCart();
    } else if (onAddToCart) {
      wishlistedProducts.forEach(product => {
        const size = selectedSizes[product.id] || product.sizes[0] || 'Standard';
        onAddToCart({
          product,
          size,
          quantity: 1
        });
      });
    }
    if (onOpenCart) {
      onClose();
      onOpenCart();
    }
  };

  const formatPrice = (priceINR: number) => {
    if (currency === 'USD') {
      return `$${Math.round(priceINR / 83).toLocaleString()}`;
    }
    return `₹${priceINR.toLocaleString('en-IN')}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0E1016] border-l border-[#2E2C26] text-[#FAF7F0] shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-5 bg-[#141620] border-b border-[#252838] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#1C1820] border border-rose-500/40 flex items-center justify-center">
                <Heart className="w-4 h-4 text-rose-400 fill-rose-400/20" />
              </div>
              <div>
                <h2 className="font-cinzel text-base font-bold text-[#FAF7F0] tracking-wider uppercase">
                  Wishlist
                </h2>
                <div className="text-[11px] text-[#A09A8E]">
                  {wishlistedProducts.length} Saved Item{wishlistedProducts.length === 1 ? '' : 's'}
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-[#1E2130] text-[#A09A8E] hover:text-white transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Actions Bar when multiple items */}
          {wishlistedProducts.length > 1 && (
            <div className="px-5 py-2.5 bg-[#10121A] border-b border-[#1E2130] flex items-center justify-between text-xs">
              <span className="text-[11px] text-[#A09A8E]">Ready to order your saved items?</span>
              <button
                onClick={handleMoveAll}
                className="text-[11px] text-[#D4AF37] hover:text-white font-medium flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>Move All to Cart</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Items Container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
            {wishlistedProducts.length === 0 ? (
              <div className="text-center py-24 text-[#7A756C] space-y-3">
                <div className="w-14 h-14 mx-auto rounded-full bg-[#13151D] border border-[#252838] flex items-center justify-center">
                  <Heart className="w-6 h-6 text-[#D4AF37]/40" />
                </div>
                <h3 className="font-cinzel text-sm font-semibold text-[#FAF7F0]">
                  Your Wishlist is Empty
                </h3>
                <p className="text-xs font-light max-w-xs mx-auto text-[#8E92A4]">
                  Browse our collections and tap the heart icon on any item to save it here for later.
                </p>
                <button
                  onClick={onClose}
                  className="mt-3 px-5 py-2.5 rounded-full bg-[#1A1D28] hover:bg-[#242838] border border-[#D4AF37]/50 text-xs uppercase tracking-wider text-[#D4AF37] transition-all cursor-pointer"
                >
                  Browse Catalogue
                </button>
              </div>
            ) : (
              wishlistedProducts.map(product => {
                const isRecentlyAdded = addedItemIds[product.id];
                const activeSize = selectedSizes[product.id] || product.sizes[0] || 'Standard';

                return (
                  <div
                    key={product.id}
                    className="p-3.5 bg-[#13151D] border border-[#252838] hover:border-[#383D52] rounded-sm flex gap-3 relative group transition-all"
                  >
                    {/* Thumbnail */}
                    <div
                      className="cursor-pointer shrink-0 relative overflow-hidden rounded-sm"
                      onClick={() => {
                        if (onSelectProduct) {
                          onSelectProduct(product);
                          onClose();
                        }
                      }}
                    >
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-20 h-28 object-cover rounded-sm border border-[#2D3042] group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>

                    {/* Details & Actions */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-1">
                          <h4
                            onClick={() => {
                              if (onSelectProduct) {
                                onSelectProduct(product);
                                onClose();
                              }
                            }}
                            className="text-xs font-semibold text-[#FAF7F0] hover:text-[#D4AF37] truncate font-cinzel cursor-pointer transition-colors"
                          >
                            {product.name}
                          </h4>
                          <button
                            onClick={() => handleRemove(product.id)}
                            className="text-[#6C7184] hover:text-rose-400 p-1 transition-colors cursor-pointer"
                            title="Remove from Wishlist"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="text-[10px] text-[#A09A8E] mt-0.5 truncate">
                          {product.fabric} · {product.weaveOrigin}
                        </div>

                        <div className="text-xs font-mono font-bold text-[#D4AF37] mt-1.5">
                          {formatPrice(product.price)}
                        </div>

                        {/* Size Selection */}
                        <div className="mt-2 flex items-center gap-2">
                          <label className="text-[10px] text-[#7E8294] uppercase tracking-wider">Size:</label>
                          <select
                            value={activeSize}
                            onChange={e => handleSizeChange(product.id, e.target.value)}
                            className="bg-[#1C1F2B] border border-[#2E3346] text-[#FAF7F0] text-[10px] rounded px-2 py-0.5 focus:border-[#D4AF37] outline-none cursor-pointer"
                          >
                            {product.sizes.map(s => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Push to Active Cart Button */}
                      <div className="pt-2 mt-2 border-t border-[#1F2230] flex items-center justify-between gap-2">
                        <button
                          onClick={() => handlePushToCart(product)}
                          className={`flex-1 py-1.5 px-3 rounded text-[11px] font-medium tracking-wider uppercase flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            isRecentlyAdded
                              ? 'bg-emerald-600 text-white font-semibold'
                              : 'bg-[#1D202C] hover:bg-[#D4AF37] text-[#C8C2B7] hover:text-black border border-[#2F344A] hover:border-[#D4AF37]'
                          }`}
                        >
                          {isRecentlyAdded ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-white" />
                              <span>Added to Cart</span>
                            </>
                          ) : (
                            <>
                              <ShoppingBag className="w-3.5 h-3.5" />
                              <span>Add to Cart</span>
                            </>
                          )}
                        </button>

                        {isRecentlyAdded && onOpenCart && (
                          <button
                            onClick={() => {
                              onClose();
                              onOpenCart();
                            }}
                            className="text-[10px] uppercase text-[#D4AF37] hover:text-white underline tracking-wider cursor-pointer"
                          >
                            View Cart
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer */}
          {wishlistedProducts.length > 0 && (
            <div className="p-4 bg-[#141620] border-t border-[#252838] space-y-2">
              <div className="flex gap-2">
                {onViewWishlistPage && (
                  <button
                    onClick={() => {
                      onClose();
                      onViewWishlistPage();
                    }}
                    className="flex-1 py-2.5 bg-[#171924] hover:bg-[#202434] border border-[#2B3042] text-[#C8C2B7] hover:text-white text-xs font-medium uppercase tracking-wider rounded-sm transition-all cursor-pointer"
                  >
                    View Full Page
                  </button>
                )}
                {onOpenCart && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenCart();
                    }}
                    className="flex-1 py-2.5 bg-[#1B1E2B] hover:bg-[#25293B] border border-[#2E344A] hover:border-[#D4AF37] text-[#FAF7F0] hover:text-[#D4AF37] text-xs font-semibold uppercase tracking-wider rounded-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>View Cart</span>
                  </button>
                )}
              </div>
              <div className="text-center text-[10px] text-[#7E8294]">
                Saved to your account
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
