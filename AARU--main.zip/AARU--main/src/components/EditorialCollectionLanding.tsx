import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Award,
  Clock,
  ShieldCheck,
  Compass,
  ArrowRight,
  Filter,
  SlidersHorizontal,
  Eye,
  ShoppingBag,
  Heart,
  ChevronRight,
  Check,
  Calendar,
  Layers,
  Feather
} from 'lucide-react';
import { Product, EditorialCollection, ElementType } from '../types';
import { EDITORIAL_COLLECTIONS, INITIAL_PRODUCTS } from '../data/mockData';
import { api } from '../services/api';

interface EditorialCollectionLandingProps {
  collectionId: string;
  onSelectCollection: (id: string) => void;
  onSelectProduct: (product: Product) => void;
  onQuickViewProduct: (product: Product) => void;
  onAddToCart: (product: Product, size?: string) => void;
  onOpenQuiz?: () => void;
  onOpenConsultation?: () => void;
  currency: 'INR' | 'USD';
  formatPrice: (price: number) => string;
  wishlist: string[];
  onToggleWishlist: (productId: string) => void;
}

export const EditorialCollectionLanding: React.FC<EditorialCollectionLandingProps> = ({
  collectionId,
  onSelectCollection,
  onSelectProduct,
  onQuickViewProduct,
  onAddToCart,
  onOpenQuiz,
  onOpenConsultation,
  currency,
  formatPrice,
  wishlist,
  onToggleWishlist
}) => {
  const [collection, setCollection] = useState<EditorialCollection>(() => {
    return EDITORIAL_COLLECTIONS.find(c => c.id === collectionId) || EDITORIAL_COLLECTIONS[0];
  });
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Sub-filter & sorting within this collection
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [onlyReadyToShip, setOnlyReadyToShip] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'hours-desc'>('featured');
  const [quickAddedId, setQuickAddedId] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    api.getEditorialCollectionById(collectionId).then(col => {
      if (!isMounted) return;
      if (col) {
        setCollection(col);
        if (col.products && col.products.length > 0) {
          setProducts(col.products);
        } else {
          // Match by element
          const matched = INITIAL_PRODUCTS.filter(p => {
            if (col.element === 'aaru') return p.element === 'aaru';
            return p.element === col.element;
          });
          setProducts(matched);
        }
      } else {
        const fallback = EDITORIAL_COLLECTIONS[0];
        setCollection(fallback);
        setProducts(INITIAL_PRODUCTS.filter(p => p.element === fallback.element));
      }
      setLoading(false);
    });

    return () => {
      isMounted = false;
    };
  }, [collectionId]);

  // Derived filtered products
  const filteredProducts = products.filter(p => {
    if (selectedCategory !== 'all' && p.category.toLowerCase() !== selectedCategory.toLowerCase()) {
      return false;
    }
    if (onlyReadyToShip && p.availability !== 'in_stock') {
      return false;
    }
    return true;
  });

  if (sortBy === 'price-asc') {
    filteredProducts.sort((a, b) => a.price - b.price);
  } else if (sortBy === 'price-desc') {
    filteredProducts.sort((a, b) => b.price - a.price);
  } else if (sortBy === 'hours-desc') {
    filteredProducts.sort((a, b) => b.artisan.loomHours - a.artisan.loomHours);
  }

  const handleQuickAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, product.sizes[0] || 'Free Size');
    setQuickAddedId(product.id);
    setTimeout(() => {
      setQuickAddedId(null);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-[#090A0E] text-[#FAF7F0]">
      {/* 1. Collection Switcher Header Bar */}
      <div className="bg-[#0D0F16] border-b border-[#1A1D28] sticky top-20 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#A09A8E]">REALMS:</span>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            {EDITORIAL_COLLECTIONS.map(col => {
              const isCurrent = col.id === collection.id;
              return (
                <button
                  key={col.id}
                  id={`collection-tab-${col.id}`}
                  onClick={() => onSelectCollection(col.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-medium tracking-wider uppercase transition-all whitespace-nowrap flex items-center gap-2 border ${
                    isCurrent
                      ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-semibold shadow-[0_0_12px_rgba(212,175,55,0.3)]'
                      : 'bg-[#131620] text-[#A09A8E] border-[#222738] hover:border-[#D4AF37]/50 hover:text-[#FAF7F0]'
                  }`}
                >
                  <span className="font-telugu text-xs">{col.teluguTitle.split(' ')[0]}</span>
                  <span>{col.title.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 2. Premium Visual Campaign Header */}
      <section className="relative min-h-[70vh] lg:min-h-[80vh] flex items-center justify-center overflow-hidden">
        {/* Hero Background Image with Atmospheric Multi-Stop Gradients */}
        <div className="absolute inset-0 z-0">
          <img
            src={collection.heroImage}
            alt={collection.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
          />
          {/* Gradient Overlays for Readability and Mood */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#090A0E] via-[#090A0E]/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#090A0E] via-[#090A0E]/40 to-[#090A0E]/80" />
          <div className="absolute inset-0 bg-black/30" />
        </div>

        {/* Campaign Hero Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10 w-full">
          <div className="max-w-3xl">
            {/* Telugu Badge & Realm Tag */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-black/60 border border-[#D4AF37] flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.25)]">
                <span className="font-telugu text-lg font-bold text-[#D4AF37]">
                  {collection.teluguTitle.split(' ')[0]}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-[0.28em] text-[#D4AF37] font-semibold">
                  HAUTE COUTURE ARCHIVAL CAMPAIGN
                </span>
                <span className="text-xs text-[#C5A059] font-telugu">
                  {collection.teluguTitle}
                </span>
              </div>
            </div>

            {/* Custom Campaign Title */}
            <h1 className="font-cinzel text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#FAF7F0] leading-tight drop-shadow-lg">
              {collection.title}
            </h1>

            {/* Poetic Subtitle */}
            <p className="mt-4 text-base sm:text-lg lg:text-xl text-[#EDE8DF] font-sans font-light leading-relaxed max-w-2xl drop-shadow">
              {collection.subtitle}
            </p>

            {/* Mood Quote Callout */}
            <div className="mt-8 p-5 sm:p-6 rounded-2xl bg-[#090A0E]/85 backdrop-blur-md border border-[#D4AF37]/40 max-w-xl shadow-2xl relative">
              <div className="text-2xl text-[#D4AF37] font-serif leading-none mb-1">“</div>
              <p className="font-serif italic text-sm sm:text-base text-[#FAF7F0] leading-relaxed">
                {collection.moodQuote}
              </p>
              <div className="mt-3 flex items-center justify-between border-t border-[#232738] pt-2 text-xs text-[#A09A8E]">
                <span>— {collection.quoteAuthor}</span>
                <span className="text-[10px] uppercase tracking-widest text-[#D4AF37]">AARU MANIFESTO</span>
              </div>
            </div>

            {/* Action Bar */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a
                href="#collection-creations"
                className="px-6 py-3 rounded-full bg-[#D4AF37] hover:bg-[#E5C158] text-[#090A0E] text-xs font-bold tracking-[0.16em] uppercase transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] flex items-center gap-2"
              >
                <span>Explore Creations ({filteredProducts.length})</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              {onOpenConsultation && (
                <button
                  onClick={onOpenConsultation}
                  className="px-6 py-3 rounded-full bg-[#121520]/80 hover:bg-[#1C2030] text-[#FAF7F0] border border-[#2B3045] hover:border-[#D4AF37] text-xs font-semibold tracking-wider uppercase transition-all flex items-center gap-2 backdrop-blur-sm"
                >
                  <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Atelier Consultation</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 3. Brand Storytelling & Craftsmanship Breakdown */}
      <section className="py-16 sm:py-24 bg-[#0B0D13] border-t border-b border-[#1A1D28] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Brand Storytelling & Philosophy (7 Cols) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="flex items-center gap-2">
                <Feather className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-[11px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
                  PHILOSOPHY &amp; WEAVER'S LINEAGE
                </span>
              </div>

              <h2 className="font-cinzel text-2xl sm:text-3xl lg:text-4xl font-bold text-[#FAF7F0] leading-tight">
                {collection.concept}
              </h2>

              <div className="space-y-4 text-sm sm:text-base text-[#A09A8E] font-sans leading-relaxed">
                {collection.philosophyStory.map((para, i) => (
                  <p key={i} className={i === 0 ? 'text-[#FAF7F0] font-normal' : ''}>
                    {para}
                  </p>
                ))}
              </div>

              {/* Element Color Palette Chips */}
              <div className="pt-4 flex items-center gap-3">
                <span className="text-[11px] uppercase tracking-widest text-[#7E8294]">Color Palette:</span>
                <div className="flex items-center gap-2">
                  {collection.palette.map((color, idx) => (
                    <div
                      key={idx}
                      className="w-6 h-6 rounded-full border border-white/20 shadow-sm"
                      style={{ backgroundColor: color }}
                      title={`Palette Tone ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: Craft Heritage Metrics Grid (5 Cols) */}
            <div className="lg:col-span-5 bg-[#10131C] rounded-2xl p-6 sm:p-8 border border-[#202538] shadow-2xl space-y-5">
              <div className="flex items-center justify-between border-b border-[#1E2333] pb-4">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#D4AF37] font-bold">
                    CRAFT HERITAGE AUDIT
                  </span>
                  <h3 className="font-cinzel text-lg font-bold text-[#FAF7F0]">
                    Guild Loom Technical Standards
                  </h3>
                </div>
                <Award className="w-6 h-6 text-[#D4AF37]" />
              </div>

              {/* Metric 1: Loom Technique */}
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#171B26] border border-[#262C40] text-[#D4AF37] mt-0.5">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#7E8294] block">Loom Technique</span>
                  <span className="text-xs sm:text-sm font-medium text-[#FAF7F0]">
                    {collection.craftHeritage.loomTechnique}
                  </span>
                </div>
              </div>

              {/* Metric 2: Zari Hallmark */}
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#171B26] border border-[#262C40] text-[#D4AF37] mt-0.5">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#7E8294] block">Zari Hallmark Guarantee</span>
                  <span className="text-xs sm:text-sm font-medium text-[#FAF7F0]">
                    {collection.craftHeritage.zariStandard}
                  </span>
                </div>
              </div>

              {/* Metric 3: Origin Guild */}
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#171B26] border border-[#262C40] text-[#D4AF37] mt-0.5">
                  <Compass className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#7E8294] block">Artisan Origin Guild</span>
                  <span className="text-xs sm:text-sm font-medium text-[#FAF7F0]">
                    {collection.craftHeritage.originGuild}
                  </span>
                </div>
              </div>

              {/* Metric 4: Average Loom Hours */}
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-[#171B26] border border-[#262C40] text-[#D4AF37] mt-0.5">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#7E8294] block">Loom Dedication</span>
                  <span className="text-xs sm:text-sm font-medium text-[#FAF7F0]">
                    ~{collection.craftHeritage.avgLoomHours} Manual Weaving Hours per Silhouette
                  </span>
                </div>
              </div>

              {/* Metric 5: Certification */}
              <div className="flex items-start gap-3 border-t border-[#1E2333] pt-4">
                <div className="p-2 rounded-lg bg-[#171B26] border border-[#262C40] text-emerald-400 mt-0.5">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#7E8294] block">Authenticity Documentation</span>
                  <span className="text-xs font-mono text-emerald-400">
                    {collection.craftHeritage.textileCertification}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Underlying Product Grid with Smooth Gradient Blend */}
      <section id="collection-creations" className="py-20 bg-gradient-to-b from-[#0B0D13] via-[#090A0E] to-[#07080B] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Sub-Header & In-Page Filter Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 mb-8 border-b border-[#1D212F]">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                <span className="text-xs uppercase tracking-[0.2em] text-[#D4AF37] font-semibold">
                  CURATED SILHOUETTES
                </span>
              </div>
              <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#FAF7F0] mt-1">
                The {collection.title.split(' ')[0]} Wardrobe
              </h3>
            </div>

            {/* Controls: Category Filter, Ready to Ship Toggle, and Sort */}
            <div className="flex flex-wrap items-center gap-3">
              {/* Category Dropdown */}
              <div className="flex items-center gap-1.5 bg-[#121520] border border-[#252A3C] px-3 py-1.5 rounded-lg text-xs">
                <span className="text-[#7E8294]">Category:</span>
                <select
                  id="collection-cat-filter"
                  value={selectedCategory}
                  onChange={e => setSelectedCategory(e.target.value)}
                  className="bg-transparent text-[#FAF7F0] focus:outline-none cursor-pointer"
                >
                  <option value="all" className="bg-[#121520]">All Silhouettes</option>
                  <option value="saree" className="bg-[#121520]">Sarees</option>
                  <option value="sherwani" className="bg-[#121520]">Sherwanis</option>
                  <option value="gown" className="bg-[#121520]">Gowns &amp; Capes</option>
                  <option value="lehenga" className="bg-[#121520]">Lehengas</option>
                  <option value="stole" className="bg-[#121520]">Pashminas &amp; Stoles</option>
                </select>
              </div>

              {/* Ready to Ship Quick Filter */}
              <button
                id="collection-ready-filter"
                onClick={() => setOnlyReadyToShip(!onlyReadyToShip)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 border ${
                  onlyReadyToShip
                    ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                    : 'bg-[#121520] border-[#252A3C] text-[#A09A8E] hover:text-[#FAF7F0]'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${onlyReadyToShip ? 'bg-emerald-400' : 'bg-[#555]'}`} />
                <span>Ready to Ship Only</span>
              </button>

              {/* Sort Picker */}
              <div className="flex items-center gap-1.5 bg-[#121520] border border-[#252A3C] px-3 py-1.5 rounded-lg text-xs">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#D4AF37]" />
                <select
                  id="collection-sort-picker"
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value as any)}
                  className="bg-transparent text-[#FAF7F0] focus:outline-none cursor-pointer"
                >
                  <option value="featured" className="bg-[#121520]">Featured Lineage</option>
                  <option value="price-asc" className="bg-[#121520]">Price: Low to High</option>
                  <option value="price-desc" className="bg-[#121520]">Price: High to Low</option>
                  <option value="hours-desc" className="bg-[#121520]">Most Loom Hours</option>
                </select>
              </div>
            </div>
          </div>

          {/* Product Grid */}
          {loading ? (
            <div className="py-20 text-center text-[#A09A8E]">
              <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="text-xs uppercase tracking-widest">Retrieving collection registry from vault...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-16 text-center bg-[#10131D] rounded-2xl border border-[#202538] p-8 max-w-lg mx-auto">
              <p className="text-[#FAF7F0] font-cinzel text-lg mb-2">No silhouettes match this combination</p>
              <p className="text-xs text-[#A09A8E] mb-4">Try clearing the Ready to Ship filter or resetting category.</p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setOnlyReadyToShip(false);
                }}
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-black text-xs font-bold uppercase tracking-wider"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {filteredProducts.map(product => {
                const isWishlisted = wishlist.includes(product.id);
                const isQuickAdded = quickAddedId === product.id;

                return (
                  <div
                    key={product.id}
                    id={`collection-product-card-${product.id}`}
                    onClick={() => onSelectProduct(product)}
                    className="group bg-[#0F121B] rounded-2xl overflow-hidden border border-[#1E2333] hover:border-[#D4AF37]/70 transition-all duration-500 flex flex-col cursor-pointer shadow-lg hover:shadow-[0_10px_30px_rgba(0,0,0,0.6)]"
                  >
                    {/* Product Image Stage */}
                    <div className="relative aspect-[3/4] overflow-hidden bg-[#161924]">
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                      />
                      {product.images[1] && (
                        <img
                          src={product.images[1]}
                          alt={product.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover object-center absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                        />
                      )}

                      {/* Top Badges */}
                      <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
                        {product.availability === 'in_stock' ? (
                          <span className="text-[9px] uppercase tracking-wider bg-emerald-950/90 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-800/80 font-semibold backdrop-blur-sm">
                            Ready to Ship
                          </span>
                        ) : (
                          <span className="text-[9px] uppercase tracking-wider bg-[#1B1E2B]/90 text-[#D4AF37] px-2.5 py-1 rounded-full border border-[#D4AF37]/30 font-semibold backdrop-blur-sm">
                            Made to Order
                          </span>
                        )}

                        {/* Wishlist Button */}
                        <button
                          id={`wishlist-btn-${product.id}`}
                          onClick={e => {
                            e.stopPropagation();
                            onToggleWishlist(product.id);
                          }}
                          aria-label="Toggle wishlist"
                          className="p-2 rounded-full bg-black/60 hover:bg-black/90 text-[#FAF7F0] border border-white/10 hover:border-[#D4AF37] transition-all backdrop-blur-sm"
                        >
                          <Heart
                            className={`w-3.5 h-3.5 ${
                              isWishlisted ? 'fill-red-500 text-red-500' : 'text-[#FAF7F0]'
                            }`}
                          />
                        </button>
                      </div>

                      {/* Quick View Floating Pill on Hover */}
                      <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex gap-2 z-10">
                        <button
                          id={`quickview-btn-${product.id}`}
                          onClick={e => {
                            e.stopPropagation();
                            onQuickViewProduct(product);
                          }}
                          className="flex-1 py-2 rounded-xl bg-[#090A0E]/90 hover:bg-black text-[#FAF7F0] border border-white/20 text-[11px] font-medium tracking-wider uppercase backdrop-blur-md flex items-center justify-center gap-1.5 transition-all"
                        >
                          <Eye className="w-3.5 h-3.5 text-[#D4AF37]" />
                          <span>Quick View</span>
                        </button>

                        <button
                          id={`quickadd-btn-${product.id}`}
                          onClick={e => handleQuickAdd(product, e)}
                          className={`px-3 py-2 rounded-xl text-[11px] font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-1 shadow-md ${
                            isQuickAdded
                              ? 'bg-emerald-600 text-white'
                              : 'bg-[#D4AF37] hover:bg-[#E5C158] text-black'
                          }`}
                          title="Quick Add to Bag"
                        >
                          {isQuickAdded ? <Check className="w-3.5 h-3.5" /> : <ShoppingBag className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {/* Product Details */}
                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between text-[10px] text-[#7E8294] uppercase tracking-wider mb-1">
                          <span>{product.fabric}</span>
                          <span className="font-mono text-[#D4AF37]">{product.artisan.loomHours}h loom</span>
                        </div>

                        <h4 className="font-cinzel text-base font-bold text-[#FAF7F0] group-hover:text-[#D4AF37] transition-colors line-clamp-1">
                          {product.name}
                        </h4>

                        <p className="text-xs text-[#A09A8E] mt-1 line-clamp-2 font-sans">
                          {product.subtitle}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-[#1C2030] flex items-center justify-between">
                        <div>
                          <span className="font-mono text-base font-bold text-[#FAF7F0]">
                            {formatPrice(product.price)}
                          </span>
                          {product.originalPrice && (
                            <span className="ml-2 font-mono text-xs text-[#62677C] line-through">
                              {formatPrice(product.originalPrice)}
                            </span>
                          )}
                        </div>

                        <span className="text-xs text-[#D4AF37] group-hover:translate-x-1 transition-transform flex items-center gap-1 font-medium">
                          <span>Details</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* 5. Bespoke Commission & Concierge Banner */}
      <section className="py-16 bg-[#0E1119] border-t border-[#1E2333]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center gap-2 bg-[#D4AF37]/10 border border-[#D4AF37]/40 px-3.5 py-1.5 rounded-full text-xs text-[#D4AF37]">
            <Sparkles className="w-3.5 h-3.5" />
            <span className="tracking-widest uppercase">BESPOKE ATELIER COMMISSION</span>
          </div>
          <h3 className="font-cinzel text-3xl sm:text-4xl font-bold text-[#FAF7F0]">
            Commission an Heirloom in {collection.title}
          </h3>
          <p className="text-sm text-[#A09A8E] max-w-2xl mx-auto font-sans leading-relaxed">
            Require custom pallu motifs, pure 24k bullion embroidery, or private family monogramming? Schedule a private digital or in-person consultation with our senior courtier.
          </p>
          <div className="pt-2 flex justify-center gap-4">
            {onOpenConsultation && (
              <button
                id="bespoke-commission-btn"
                onClick={onOpenConsultation}
                className="px-6 py-3 rounded-full bg-[#D4AF37] hover:bg-[#E5C158] text-[#090A0E] text-xs font-bold tracking-[0.16em] uppercase transition-all shadow-lg"
              >
                Schedule Couture Consultation
              </button>
            )}
            {onOpenQuiz && (
              <button
                onClick={onOpenQuiz}
                className="px-6 py-3 rounded-full bg-[#161925] hover:bg-[#202538] text-[#FAF7F0] border border-[#2B3045] text-xs font-semibold tracking-wider uppercase transition-all"
              >
                Discover Your Elemental Affinity
              </button>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};
