import React, { useState } from 'react';
import { BookOpen, Sparkles, Feather, Clock, ArrowRight, ShieldCheck, CheckCircle, ChevronRight, X } from 'lucide-react';
import { EditorialStory, Product } from '../types';

interface EditorialStoryProps {
  stories: EditorialStory[];
  onSelectProduct: (product: Product) => void;
  allProducts: Product[];
  onCloseReaderMode?: () => void;
}

export const EditorialStorySection: React.FC<EditorialStoryProps> = ({
  stories,
  onSelectProduct,
  allProducts
}) => {
  const [activeStoryIndex, setActiveStoryIndex] = useState(0);
  const [readerModalOpen, setReaderModalOpen] = useState(false);

  const activeStory = stories[activeStoryIndex] || stories[0];
  const featured = allProducts.filter(p => activeStory?.featuredProducts?.includes(p.id));

  return (
    <section id="the-sixth-element-story" className="py-20 bg-[#090A0E] text-[#FAF7F0] border-b border-[#25231F] relative">
      {/* Decorative Watermark: The Telugu Crest "ఆరు" in Background */}
      <div className="absolute right-4 top-10 opacity-[0.03] select-none pointer-events-none font-telugu text-[260px] sm:text-[380px] font-bold text-[#D4AF37] leading-none">
        ఆరు
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 pb-6 border-b border-[#25231F]">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-[#D4AF37] mb-2 font-medium">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Editorial Storytelling · Brand Philosophy</span>
            </div>
            <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold tracking-[0.15em] text-[#FAF7F0] uppercase">
              The Sixth Element (ఆరవ తత్వం)
            </h2>
          </div>

          <div className="mt-4 md:mt-0 flex items-center gap-3">
            {stories.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => setActiveStoryIndex(idx)}
                className={`text-xs px-3.5 py-1.5 rounded-sm border transition-all ${
                  idx === activeStoryIndex
                    ? 'border-[#D4AF37] text-[#D4AF37] bg-[#D4AF37]/10'
                    : 'border-[#3A3832] text-[#A09A8E] hover:text-white'
                }`}
              >
                {s.chapter}
              </button>
            ))}
          </div>
        </div>

        {/* Main Editorial Showcase Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left: Editorial Image with Artisan Seal */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/5] overflow-hidden rounded-sm border border-[#3A3832] shadow-[0_10px_40px_rgba(0,0,0,0.8)]">
              <img
                src={activeStory.image}
                alt={activeStory.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transition-transform duration-1000 hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10] via-transparent to-transparent opacity-80"></div>

              {/* Floating Telugu Crest Monogram on the Image */}
              <div className="absolute top-6 left-6 bg-[#0B0C10]/90 backdrop-blur-md border border-[#D4AF37]/60 px-4 py-2 rounded flex items-center gap-2.5">
                <span className="font-telugu text-xl font-bold text-[#D4AF37]">ఆరు</span>
                <div className="text-[10px] uppercase tracking-widest text-[#E5C07B] font-medium leading-tight">
                  <div>Heritage</div>
                  <div className="text-white/70">Signature</div>
                </div>
              </div>

              {/* Quote Ribbon at bottom */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#0B0C10]/95 backdrop-blur-md border border-[#3A3832] rounded">
                <p className="font-cormorant italic text-lg sm:text-xl text-[#FFE59E] leading-snug">
                  &ldquo;{activeStory.quote}&rdquo;
                </p>
                <div className="text-[11px] text-[#A09A8E] mt-2 tracking-wider uppercase font-sans">
                  — {activeStory.author}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Narrative Content */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center gap-3 text-xs text-[#C5A059] tracking-widest uppercase mb-3">
                <Feather className="w-3.5 h-3.5" />
                <span>{activeStory.chapter}</span>
                <span>·</span>
                <Clock className="w-3 h-3 text-[#A09A8E]" />
                <span className="text-[#A09A8E]">{activeStory.readTime}</span>
              </div>

              <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#FAF7F0] tracking-wide leading-tight mb-2">
                {activeStory.title}
              </h3>

              {activeStory.teluguTitle && (
                <div className="font-telugu text-lg sm:text-xl text-[#D4AF37] font-semibold mb-4">
                  {activeStory.teluguTitle}
                </div>
              )}

              <p className="font-cormorant text-xl italic text-[#E5C07B] leading-relaxed mb-6">
                {activeStory.subtitle}
              </p>

              <div className="space-y-4 text-[#C8C2B7] text-sm sm:text-base font-light leading-relaxed">
                {activeStory.content.slice(0, 3).map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>
            </div>

            {/* Curated Pieces from this chapter */}
            {featured.length > 0 && (
              <div className="pt-4 border-t border-[#25231F]">
                <div className="text-xs uppercase tracking-[0.2em] text-[#D4AF37] mb-3 font-medium">
                  Creations Born of This Chapter:
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {featured.map(product => (
                    <div
                      key={product.id}
                      onClick={() => onSelectProduct(product)}
                      className="p-2.5 bg-[#13151D] border border-[#2D2A24] hover:border-[#D4AF37] rounded cursor-pointer transition-all flex items-center gap-3 group"
                    >
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 object-cover rounded"
                      />
                      <div className="overflow-hidden">
                        <div className="text-xs font-medium text-white truncate group-hover:text-[#D4AF37] transition-colors">
                          {product.name}
                        </div>
                        <div className="text-[10px] text-[#A09A8E]">{product.artisan.region}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Read Full Chapter in Immersive Reader Mode */}
            <div className="pt-2 flex items-center gap-4">
              <button
                onClick={() => setReaderModalOpen(true)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#1A1813] hover:bg-[#252219] border border-[#D4AF37] text-[#FAF7F0] text-xs uppercase tracking-[0.2em] font-semibold transition-all group"
              >
                <BookOpen className="w-4 h-4 text-[#D4AF37]" />
                <span>Read Unabridged Editorial</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>

        {/* Editorial Pillars: The Anatomy of the Sixth Element */}
        <div className="mt-20 pt-12 border-t border-[#25231F] grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 bg-[#0E1016] border border-[#25231F] rounded-sm hover:border-[#D4AF37]/50 transition-colors">
            <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37] font-telugu text-xl font-bold mb-4">
              ౧
            </div>
            <h4 className="font-cinzel text-lg font-bold text-[#FAF7F0] mb-2 tracking-wider">
              The Telugu Etymology & Monogram
            </h4>
            <p className="text-xs sm:text-sm text-[#A09A8E] leading-relaxed">
              In Telugu script, <span className="font-telugu text-[#D4AF37] font-semibold">ఆరు</span> signifies the sacred number 6. It represents the human soul breathing spirit into the 5 inert cosmic elements. A golden seal of this glyph is woven into each hemline.
            </p>
          </div>

          <div className="p-6 bg-[#0E1016] border border-[#25231F] rounded-sm hover:border-[#D4AF37]/50 transition-colors">
            <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37] font-telugu text-xl font-bold mb-4">
              ౨
            </div>
            <h4 className="font-cinzel text-lg font-bold text-[#FAF7F0] mb-2 tracking-wider">
              24k Tested Silver-Gilt Zari
            </h4>
            <p className="text-xs sm:text-sm text-[#A09A8E] leading-relaxed">
              We exclusively use tested real silver wire electroplated in pure 24-karat gold, rejecting commercial metallic plastic. Each piece carries an authenticated Silk Mark and Handloom Board certificate.
            </p>
          </div>

          <div className="p-6 bg-[#0E1016] border border-[#25231F] rounded-sm hover:border-[#D4AF37]/50 transition-colors">
            <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37] font-telugu text-xl font-bold mb-4">
              ౩
            </div>
            <h4 className="font-cinzel text-lg font-bold text-[#FAF7F0] mb-2 tracking-wider">
              The Korvai & Pit-Loom Discipline
            </h4>
            <p className="text-xs sm:text-sm text-[#A09A8E] leading-relaxed">
              Requiring two master weavers working in rhythmic unison for 300 to 500 hours, Korvai interlocks the contrasting borders into the body without weak seams, creating heirloom garments that survive centuries.
            </p>
          </div>
        </div>
      </div>

      {/* Reader Modal (Full Editorial Experience) */}
      {readerModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#07080B]/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="relative max-w-3xl w-full bg-[#0E1016] border border-[#3A3832] rounded-sm shadow-2xl p-6 sm:p-10 my-8">
            <button
              onClick={() => setReaderModalOpen(false)}
              className="absolute top-6 right-6 text-[#A09A8E] hover:text-white p-2 rounded-full bg-[#181A22] border border-[#3A3832]"
              aria-label="Close reader"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 text-xs uppercase tracking-[0.25em] text-[#D4AF37] mb-4">
              <Sparkles className="w-4 h-4" />
              <span>AARU Atelier Chronicles · Unabridged Reader</span>
            </div>

            <h2 className="font-cinzel text-2xl sm:text-4xl font-bold text-[#FAF7F0] tracking-wide mb-2 leading-tight">
              {activeStory.title}
            </h2>

            {activeStory.teluguTitle && (
              <div className="font-telugu text-xl text-[#D4AF37] font-semibold mb-6">
                {activeStory.teluguTitle}
              </div>
            )}

            <div className="p-4 bg-[#141620] border-l-2 border-[#D4AF37] mb-8">
              <p className="font-cormorant italic text-xl text-[#FFE59E]">
                &ldquo;{activeStory.quote}&rdquo;
              </p>
              <div className="text-xs text-[#A09A8E] mt-2 uppercase tracking-widest font-sans">
                Curated by {activeStory.author}
              </div>
            </div>

            <div className="space-y-6 text-[#D5CEBF] text-base sm:text-lg font-light leading-relaxed font-serif">
              {activeStory.content.map((p, idx) => (
                <p key={idx} className="first-letter:text-4xl first-letter:font-bold first-letter:text-[#D4AF37] first-letter:mr-2">
                  {p}
                </p>
              ))}
            </div>

            <div className="mt-10 pt-6 border-t border-[#25231F] flex justify-between items-center text-xs text-[#A09A8E]">
              <div>AARU Edition No. {activeStory.id.toUpperCase()}</div>
              <button
                onClick={() => setReaderModalOpen(false)}
                className="px-6 py-2 bg-[#D4AF37] text-black font-semibold uppercase tracking-wider rounded-sm hover:bg-[#FFE59E]"
              >
                Close Reading
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
