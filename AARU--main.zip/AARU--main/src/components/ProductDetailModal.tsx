import React, { useState } from 'react';
import { X, Sparkles, MessageCircle, ShieldCheck, Clock, Check, Heart, Ruler, Scissors, Award } from 'lucide-react';
import { Product, CartItem } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  currency: 'INR' | 'USD';
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
  onAddToCart: (item: CartItem) => void;
  onWhatsAppInquiry: (product: Product, customText?: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  currency,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onWhatsAppInquiry
}) => {
  if (!product) return null;

  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || 'Standard');
  const [isBespokeMode, setIsBespokeMode] = useState(false);
  const [monogramText, setMonogramText] = useState('');
  const [measurements, setMeasurements] = useState({
    bustChest: '',
    waist: '',
    hips: '',
    height: '',
    shoulder: ''
  });
  const [addedAnimation, setAddedAnimation] = useState(false);

  const formattedPrice = currency === 'INR'
    ? `₹${product.price.toLocaleString('en-IN')}`
    : `$${Math.round(product.price / 83).toLocaleString('en-US')}`;

  const handleAdd = () => {
    const item: CartItem = {
      product,
      size: isBespokeMode ? 'Bespoke Custom Tailored' : selectedSize,
      quantity: 1,
      customMeasurements: isBespokeMode ? measurements : undefined,
      monogram: monogramText.trim() ? monogramText.trim() : undefined
    };
    onAddToCart(item);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
      onClose();
    }, 900);
  };

  const handleWhatsAppClick = () => {
    const customMsg = `Hello AARU Atelier, I am inquiring about "${product.name}" (${formattedPrice}). I would like to arrange a bespoke sizing consultation for this piece.`;
    onWhatsAppInquiry(product, customMsg);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="relative max-w-5xl w-full bg-[#0E1016] border border-[#3A3832] rounded-sm shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Top Bar with Close Button */}
        <div className="px-6 py-4 bg-[#12141C] border-b border-[#25231F] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-telugu text-xl font-bold text-[#D4AF37]">ఆరు</span>
            <span className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-medium">
              Ref: {product.id.toUpperCase()}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-[#1C1F2B] hover:bg-[#2A2E40] text-[#A09A8E] hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Image Gallery */}
          <div className="lg:col-span-6 space-y-4">
            <div className="aspect-[3/4] rounded-sm overflow-hidden bg-[#161822] border border-[#2A2824] relative">
              <img
                src={product.images[activeImageIdx] || product.images[0]}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-top"
              />
            </div>

            {/* Thumbnail Selectors */}
            {product.images.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIdx(idx)}
                    className={`w-16 h-20 rounded-sm overflow-hidden border-2 transition-all shrink-0 ${
                      activeImageIdx === idx ? 'border-[#D4AF37] scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Master Artisan Card */}
            <div className="p-4 bg-[#141620] border border-[#25231F] rounded-sm">
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-2">
                <Award className="w-4 h-4" />
                <span>Master Artisan Provenance</span>
              </div>
              <div className="text-sm font-semibold text-[#FAF7F0]">{product.artisan.name}</div>
              <div className="text-xs text-[#A09A8E] mt-0.5">
                {product.artisan.region} · {product.artisan.experienceYears} Years Master Weaver Experience
              </div>
              <div className="mt-3 flex items-center justify-between text-xs font-mono text-[#C5A059] pt-2 border-t border-[#22242E]">
                <span>Loom Duration: {product.artisan.loomHours} Dedicated Hours</span>
                <span className="flex items-center gap-1 text-emerald-400">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  GI Tag Certified
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Specifications & Bespoke Tailoring */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs uppercase tracking-[0.2em] text-[#C5A059] font-medium">
                  {product.category.toUpperCase()} · {product.weaveOrigin}
                </span>
                <button
                  onClick={() => onToggleWishlist(product.id)}
                  className={`p-2 rounded-full border transition-all ${
                    isWishlisted ? 'bg-[#D4AF37] text-black border-[#D4AF37]' : 'border-[#3A3832] text-[#A09A8E] hover:text-white'
                  }`}
                  title={isWishlisted ? 'Wishlisted' : 'Save to Wishlist'}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-black' : ''}`} />
                </button>
              </div>

              <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#FAF7F0] leading-tight mb-2">
                {product.name}
              </h2>

              <p className="font-cormorant italic text-lg text-[#E5C07B] mb-4">
                &ldquo;{product.editorialNote}&rdquo;
              </p>

              {/* Price */}
              <div className="flex items-baseline gap-4 mb-4 pb-4 border-b border-[#25231F]">
                <span className="text-2xl sm:text-3xl font-mono font-bold text-[#FAF7F0]">
                  {formattedPrice}
                </span>
                <span className="text-xs text-[#A09A8E]">
                  Inclusive of luxury teakwood archival packaging & bespoke fitting concierge
                </span>
              </div>

              <p className="text-sm text-[#C8C2B7] font-light leading-relaxed mb-6">
                {product.description}
              </p>

              {/* Sizing & Bespoke Mode Toggle */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs uppercase tracking-wider font-semibold text-[#FAF7F0] flex items-center gap-1.5">
                    <Ruler className="w-3.5 h-3.5 text-[#D4AF37]" />
                    Select Size or Custom Tailoring
                  </span>
                  <button
                    onClick={() => setIsBespokeMode(!isBespokeMode)}
                    className="text-xs text-[#D4AF37] hover:underline flex items-center gap-1 font-medium"
                  >
                    <Scissors className="w-3.5 h-3.5" />
                    {isBespokeMode ? 'Switch to Standard Sizes' : 'Need Made-to-Measure?'}
                  </button>
                </div>

                {!isBespokeMode ? (
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map(size => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-4 py-2 text-xs rounded-sm border transition-all ${
                          selectedSize === size
                            ? 'bg-[#D4AF37] text-black font-semibold border-[#D4AF37]'
                            : 'bg-[#141620] text-[#C8C2B7] border-[#3A3832] hover:border-[#D4AF37]'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 bg-[#141620] border border-[#D4AF37]/50 rounded-sm space-y-3">
                    <div className="text-xs text-[#E5C07B] font-medium">
                      Bespoke Made-to-Measure (Atelier Master Tailor Input)
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                      <div>
                        <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">Bust / Chest (in)</label>
                        <input
                          type="text"
                          value={measurements.bustChest}
                          onChange={e => setMeasurements({ ...measurements, bustChest: e.target.value })}
                          placeholder="e.g. 36"
                          className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-2.5 py-1.5 text-[#F5F2EA]"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">Waist (in)</label>
                        <input
                          type="text"
                          value={measurements.waist}
                          onChange={e => setMeasurements({ ...measurements, waist: e.target.value })}
                          placeholder="e.g. 29"
                          className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-2.5 py-1.5 text-[#F5F2EA]"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">Shoulder (in)</label>
                        <input
                          type="text"
                          value={measurements.shoulder}
                          onChange={e => setMeasurements({ ...measurements, shoulder: e.target.value })}
                          placeholder="e.g. 15.5"
                          className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-2.5 py-1.5 text-[#F5F2EA]"
                        />
                      </div>
                    </div>
                    <p className="text-[11px] text-[#A09A8E] italic">
                      *Our Senior Couturier will verify your measurements via WhatsApp Business before final cutting.
                    </p>
                  </div>
                )}
              </div>

              {/* Bespoke Monogramming Option */}
              <div className="mb-6 p-4 bg-[#141620] border border-[#25231F] rounded-sm">
                <label className="text-xs uppercase tracking-wider font-semibold text-[#FAF7F0] flex items-center justify-between mb-2">
                  <span>Complimentary Monogramming in 24k Gold Thread</span>
                  <span className="font-telugu text-sm text-[#D4AF37]">ఆరు ముద్ర</span>
                </label>
                <input
                  type="text"
                  value={monogramText}
                  onChange={e => setMonogramText(e.target.value.toUpperCase().slice(0, 10))}
                  placeholder="Enter initials or name (e.g. AARU · MR)"
                  className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-xs font-mono text-[#F5F2EA] tracking-widest placeholder-[#6B665E]"
                />
                <p className="text-[10px] text-[#A09A8E] mt-1.5">
                  Micro-embroidered onto the saree pallu or sherwani inner silk lining.
                </p>
              </div>

              {/* Key Heritage Highlights */}
              <div className="space-y-1.5 mb-6 text-xs text-[#C8C2B7]">
                {product.details.map((dt, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-[#D4AF37] mt-0.5 shrink-0" />
                    <span>{dt}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Row */}
            <div className="pt-4 border-t border-[#25231F] space-y-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleAdd}
                  disabled={addedAnimation}
                  className="flex-1 py-4 bg-gradient-to-r from-[#D4AF37] via-[#DFBF58] to-[#C5A059] hover:opacity-95 text-black font-semibold text-xs uppercase tracking-[0.25em] rounded-sm transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(212,175,55,0.3)]"
                >
                  {addedAnimation ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Couture Bag</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Commission Creation ({formattedPrice})</span>
                    </>
                  )}
                </button>

                {/* Direct WhatsApp Consultation */}
                <button
                  onClick={handleWhatsAppClick}
                  className="px-4 py-4 rounded-sm bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 transition-colors flex items-center gap-2 text-xs uppercase tracking-wider font-semibold"
                  title="WhatsApp Couturier"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span className="hidden sm:inline">WhatsApp Couturier</span>
                </button>
              </div>

              <div className="text-center text-[11px] text-[#A09A8E] flex items-center justify-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Insured White Glove Courier · Lifetime Archival Restoration Guarantee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
