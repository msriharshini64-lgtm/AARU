import React, { useState } from 'react';
import { X, Bell, CheckCheck, Sparkles, Package, Shield, Send, AlertCircle, Check } from 'lucide-react';
import { NotificationItem } from '../types';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onMarkRead: (id: string) => void;
  onTriggerTestPush: (type: 'order' | 'recommendation' | 'atelier') => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
  onMarkRead,
  onTriggerTestPush
}) => {
  const [filter, setFilter] = useState<'all' | 'order' | 'recommendation' | 'atelier'>('all');
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default'
  );
  const [requestFeedback, setRequestFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleRequestPushPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const perm = await Notification.requestPermission();
        setPermissionStatus(perm);
        if (perm === 'granted') {
          setRequestFeedback('Browser Push Alerts activated!');
          new Notification('AARU Atelier', {
            body: 'Push alerts enabled. You will receive live updates on your handloom orders and VIP style curations.',
            icon: '/assets/aistudio/logo.png'
          });
        } else {
          setRequestFeedback('Push permissions declined or blocked in browser.');
        }
      } catch {
        setRequestFeedback('In-app push notifications remain active.');
      }
    } else {
      setRequestFeedback('In-app push notifications active for this session.');
    }
  };

  const filtered = filter === 'all'
    ? notifications
    : notifications.filter(n => n.type === filter);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0E1016] border-l border-[#2E2C26] text-[#FAF7F0] shadow-2xl flex flex-col">
          {/* Header */}
          <div className="p-5 bg-[#141620] border-b border-[#252838] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Bell className="w-5 h-5 text-[#D4AF37]" />
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#D4AF37] animate-ping"></span>
              </div>
              <div>
                <h2 className="font-cinzel text-base font-bold text-[#FAF7F0] tracking-wider uppercase">
                  Alerts & Push Center
                </h2>
                <div className="text-[10px] text-[#A09A8E] flex items-center gap-1.5">
                  <span>AARU Patron Broadcast</span>
                  <span>·</span>
                  <span className="font-telugu text-[#D4AF37]">ఆరు నోటిఫికేషన్లు</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onMarkAllRead}
                className="text-[11px] text-[#C5A059] hover:text-[#FAF7F0] flex items-center gap-1 font-medium transition-colors"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Mark All</span>
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-[#1E2130] text-[#A09A8E] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Native Browser Push Permission Box */}
          <div className="p-4 bg-[#181B26] border-b border-[#2A2E40] text-xs">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="font-semibold text-[#FAF7F0] flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Real-Time Push Alerts</span>
                </div>
                <p className="text-[11px] text-[#A09A8E] leading-relaxed">
                  Receive instant notifications when your handloom piece progresses through the loom and when bespoke style curations drop.
                </p>
              </div>

              {permissionStatus !== 'granted' ? (
                <button
                  onClick={handleRequestPushPermission}
                  className="shrink-0 px-3 py-1.5 bg-[#D4AF37] hover:bg-[#E5C07B] text-black font-semibold text-[10px] uppercase tracking-wider rounded-sm transition-all"
                >
                  Enable Push
                </button>
              ) : (
                <span className="shrink-0 px-2 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] rounded flex items-center gap-1 font-mono">
                  <Check className="w-3 h-3" /> Enabled
                </span>
              )}
            </div>

            {requestFeedback && (
              <div className="mt-2 text-[10px] text-[#D4AF37] font-mono flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                <span>{requestFeedback}</span>
              </div>
            )}
          </div>

          {/* Test Push Triggers (Allows the user to test push notification features easily) */}
          <div className="p-3 bg-[#11131A] border-b border-[#252838] flex items-center justify-between gap-2 text-[10px]">
            <span className="text-[#A09A8E] uppercase tracking-wider font-semibold">Test Alerts:</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onTriggerTestPush('order')}
                className="px-2.5 py-1 bg-[#1A1E2B] hover:bg-[#252B3E] text-[#FAF7F0] rounded border border-[#3A4058] flex items-center gap-1 transition-colors"
                title="Simulate loom order update push notification"
              >
                <Package className="w-3 h-3 text-[#D4AF37]" />
                <span>Order Update</span>
              </button>

              <button
                onClick={() => onTriggerTestPush('recommendation')}
                className="px-2.5 py-1 bg-[#1A1E2B] hover:bg-[#252B3E] text-[#FAF7F0] rounded border border-[#3A4058] flex items-center gap-1 transition-colors"
                title="Simulate personalized fashion recommendation alert"
              >
                <Sparkles className="w-3 h-3 text-purple-400" />
                <span>Style Rec</span>
              </button>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="px-4 pt-3 flex items-center gap-2 border-b border-[#252838] text-xs">
            <button
              onClick={() => setFilter('all')}
              className={`pb-2.5 px-1 font-medium border-b-2 transition-all ${
                filter === 'all'
                  ? 'border-[#D4AF37] text-[#D4AF37]'
                  : 'border-transparent text-[#A09A8E] hover:text-white'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('order')}
              className={`pb-2.5 px-1 font-medium border-b-2 transition-all ${
                filter === 'order'
                  ? 'border-[#D4AF37] text-[#D4AF37]'
                  : 'border-transparent text-[#A09A8E] hover:text-white'
              }`}
            >
              Orders ({notifications.filter(n => n.type === 'order').length})
            </button>
            <button
              onClick={() => setFilter('recommendation')}
              className={`pb-2.5 px-1 font-medium border-b-2 transition-all ${
                filter === 'recommendation'
                  ? 'border-[#D4AF37] text-[#D4AF37]'
                  : 'border-transparent text-[#A09A8E] hover:text-white'
              }`}
            >
              Curations ({notifications.filter(n => n.type === 'recommendation').length})
            </button>
          </div>

          {/* Notifications List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-[#7A756C] text-xs space-y-2">
                <Bell className="w-8 h-8 mx-auto opacity-40" />
                <p>No alerts in this category.</p>
              </div>
            ) : (
              filtered.map(item => (
                <div
                  key={item.id}
                  onClick={() => onMarkRead(item.id)}
                  className={`p-3.5 rounded-sm border transition-all cursor-pointer relative ${
                    !item.read
                      ? 'bg-[#181B26] border-[#D4AF37]/50 shadow-md'
                      : 'bg-[#11131A] border-[#252838] opacity-75 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">
                      {item.type === 'order' ? (
                        <div className="w-7 h-7 rounded-full bg-amber-950/80 border border-amber-700/60 flex items-center justify-center text-[#D4AF37]">
                          <Package className="w-3.5 h-3.5" />
                        </div>
                      ) : item.type === 'recommendation' ? (
                        <div className="w-7 h-7 rounded-full bg-purple-950/80 border border-purple-700/60 flex items-center justify-center text-purple-400">
                          <Sparkles className="w-3.5 h-3.5" />
                        </div>
                      ) : (
                        <div className="w-7 h-7 rounded-full bg-emerald-950/80 border border-emerald-700/60 flex items-center justify-center text-emerald-400">
                          <Shield className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-xs font-semibold text-[#FAF7F0] truncate">
                          {item.title}
                        </div>
                        <span className="text-[10px] text-[#A09A8E] font-mono shrink-0">
                          {item.timestamp}
                        </span>
                      </div>

                      <p className="text-xs text-[#C8C2B7] font-light mt-1 leading-relaxed">
                        {item.message}
                      </p>

                      {!item.read && (
                        <div className="mt-2 flex items-center gap-1 text-[10px] text-[#D4AF37] font-semibold">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]"></span>
                          <span>Unread Push Alert</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-4 bg-[#141620] border-t border-[#252838] text-center text-xs text-[#A09A8E]">
            <p>AARU Sixth Element Push Dispatch Service</p>
          </div>
        </div>
      </div>
    </div>
  );
};
