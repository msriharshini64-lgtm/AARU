import React from 'react';
import { MessageCircle, Sparkles, Shield, ArrowUp, Mail, MapPin } from 'lucide-react';

interface FooterProps {
  onSelectStory: () => void;
  onOpenConsultation: () => void;
  onSelectElement: (elem: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectStory,
  onOpenConsultation,
  onSelectElement
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#07080B] text-[#FAF7F0] border-t border-[#25231F] relative overflow-hidden">
      {/* Decorative Telugu Monogram Background */}
      <div className="absolute left-8 -bottom-10 opacity-[0.025] select-none pointer-events-none font-telugu text-[300px] font-bold text-[#D4AF37] leading-none">
        ఆరు
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-16">
          {/* Col 1 & 2: Brand Heritage & Telugu Crest */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-b from-[#2E2618] to-[#120F09] border border-[#D4AF37] flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.25)]">
                <span className="font-telugu text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FFF2CC] via-[#D4AF37] to-[#B38F2C]">
                  ఆరు
                </span>
              </div>
              <div>
                <span className="font-cinzel text-2xl font-bold tracking-[0.25em] text-[#FAF7F0]">
                  AARU
                </span>
                <div className="text-[9px] uppercase tracking-[0.35em] text-[#D4AF37] font-medium">
                  The Sixth Element
                </div>
              </div>
            </div>

            <p className="text-xs text-[#A09A8E] font-light leading-relaxed max-w-sm">
              Rooted in the Telugu heritage of &ldquo;ఆరు&rdquo; (Six), AARU represents the immortal Sixth Element: The living soul of the handloom master artisan uniting Earth, Water, Fire, Air, and Ether into immortal couture.
            </p>

            <div className="pt-2">
              <a
                href="https://wa.me/918008006600?text=Hello%20AARU%20Atelier,%20I%20would%20like%20to%20inquire%20about%20your%20bespoke%20services."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-600/50 text-emerald-300 text-xs rounded transition-all group"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                <span>WhatsApp Business Concierge</span>
                <span className="text-[10px] bg-emerald-800/40 text-emerald-300 px-1.5 py-0.5 rounded">Active</span>
              </a>
            </div>
          </div>

          {/* Col 3: The Elemental Realms */}
          <div className="space-y-3">
            <div className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
              The Elemental Realms
            </div>
            <ul className="space-y-2 text-xs text-[#A09A8E]">
              <li>
                <button onClick={() => onSelectElement('earth')} className="hover:text-white transition-colors">
                  Prithvi (Earth Silks)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectElement('water')} className="hover:text-white transition-colors">
                  Jala (Fluid Drapes)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectElement('fire')} className="hover:text-white transition-colors">
                  Agni (Molten Zari)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectElement('air')} className="hover:text-white transition-colors">
                  Vayu (Organza Clouds)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectElement('ether')} className="hover:text-white transition-colors">
                  Akasha (Astral Velvet)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectElement('aaru')} className="text-[#D4AF37] hover:underline font-medium">
                  Āru (The Sixth Element) ★
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Atelier & Concierge */}
          <div className="space-y-3">
            <div className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
              Bespoke Concierge
            </div>
            <ul className="space-y-2 text-xs text-[#A09A8E]">
              <li>
                <button onClick={onOpenConsultation} className="hover:text-white transition-colors">
                  WhatsApp Sizing & Fitting
                </button>
              </li>
              <li>
                <button onClick={onSelectStory} className="hover:text-white transition-colors">
                  The Sixth Element Manifesto
                </button>
              </li>
              <li>
                <button onClick={onOpenConsultation} className="hover:text-white transition-colors">
                  Request 24k Zari Certificate
                </button>
              </li>
              <li>
                <span className="text-[#6A655D]">Private Salon Bookings</span>
              </li>
              <li>
                <span className="text-[#6A655D]">Loom Mark India Verification</span>
              </li>
            </ul>
          </div>

          {/* Col 5: Global Ateliers */}
          <div className="space-y-3">
            <div className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
              Atelier Sanctums
            </div>
            <div className="space-y-3 text-xs text-[#A09A8E]">
              <div>
                <div className="font-medium text-[#FAF7F0] flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#D4AF37]" />
                  Hyderabad Atelier
                </div>
                <div className="text-[11px] text-[#7A756C]">Road No. 36, Jubilee Hills, Hyderabad</div>
              </div>
              <div>
                <div className="font-medium text-[#FAF7F0] flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#D4AF37]" />
                  London Private Salon
                </div>
                <div className="text-[11px] text-[#7A756C]">Mount Street, Mayfair, London W1K</div>
              </div>
              <div>
                <div className="font-medium text-[#FAF7F0] flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#D4AF37]" />
                  Milan Guild Archive
                </div>
                <div className="text-[11px] text-[#7A756C]">Via Montenapoleone, Milan</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Banner */}
        <div className="pt-8 border-t border-[#201E1A] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7A756C]">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} AARU Haute Couture.</span>
            <span>All rights reserved.</span>
            <span className="font-telugu text-sm text-[#D4AF37]/80">ఆరు చేనేత వైభవం</span>
          </div>

          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1 text-[#A09A8E]">
              <Shield className="w-3.5 h-3.5 text-[#D4AF37]" />
              GI Certified Handlooms
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded bg-[#13151D] hover:bg-[#1E2130] text-[#A09A8E] hover:text-[#D4AF37] transition-colors"
              title="Return to pinnacle"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
