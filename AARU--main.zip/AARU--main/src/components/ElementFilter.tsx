import React from 'react';
import { Sparkles, SlidersHorizontal } from 'lucide-react';
import { ELEMENT_METADATA } from '../data/mockData';

interface ElementFilterProps {
  selectedElement: string;
  onSelectElement: (element: string) => void;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  selectedSort: string;
  onSelectSort: (sort: string) => void;
  productCount: number;
}

const CATEGORIES = [
  { id: 'all', label: 'All Silhouettes' },
  { id: 'saree', label: 'Haute Sarees' },
  { id: 'lehenga', label: 'Bridal Lehengas' },
  { id: 'sherwani', label: 'Royal Sherwanis' },
  { id: 'cape-gown', label: 'Capes & Gowns' },
  { id: 'kurta', label: 'Bespoke Kurtas' },
  { id: 'stole', label: 'Pashmina Stoles' }
];

export const ElementFilter: React.FC<ElementFilterProps> = ({
  selectedElement,
  onSelectElement,
  selectedCategory,
  onSelectCategory,
  selectedSort,
  onSelectSort,
  productCount
}) => {
  const currentMeta = ELEMENT_METADATA[selectedElement] || ELEMENT_METADATA.all;

  return (
    <div className="bg-[#0B0C10] border-b border-[#25231F] py-8 text-[#FAF7F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Elemental Realms Selector */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[11px] uppercase tracking-[0.3em] text-[#D4AF37] font-semibold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Elemental Curations (పంచభూతాలు & ఆరు)
            </span>
            <span className="text-xs text-[#A09A8E] font-mono">
              Showing {productCount} Masterpiece{productCount === 1 ? '' : 's'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            {Object.entries(ELEMENT_METADATA).map(([key, meta]) => {
              const isSelected = selectedElement === key;
              const isAaru = key === 'aaru';

              return (
                <button
                  key={key}
                  onClick={() => onSelectElement(key)}
                  className={`p-3 rounded-sm text-left transition-all relative overflow-hidden border ${
                    isSelected
                      ? isAaru
                        ? 'bg-[#211B10] border-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.25)]'
                        : 'bg-[#151720] border-[#D4AF37]'
                      : 'bg-[#0E1016] border-[#25231F] hover:border-[#3A3832]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className="text-[10px] uppercase tracking-wider font-semibold"
                      style={{ color: meta.color }}
                    >
                      {key === 'all' ? 'All' : key.toUpperCase()}
                    </span>
                    <span className="font-telugu text-sm font-medium text-[#C5A059]">
                      {meta.teluguName}
                    </span>
                  </div>
                  <div className="text-xs font-medium text-[#F5F2EA] truncate">
                    {meta.name.split(' (')[0]}
                  </div>
                  {isAaru && (
                    <div className="mt-1 text-[9px] uppercase tracking-widest text-[#D4AF37] font-semibold">
                      ★ Signature
                    </div>
                  )}
                  {isSelected && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#D4AF37]"></span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Highlight Banner of Selected Element */}
        <div className="p-4 bg-[#11131A] border border-[#25231F] rounded-sm mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className="w-3 h-3 rounded-full shrink-0 shadow-sm"
              style={{ backgroundColor: currentMeta.color }}
            ></div>
            <div>
              <div className="text-sm font-semibold text-[#FAF7F0]">
                {currentMeta.name} <span className="font-telugu text-[#D4AF37] ml-1">({currentMeta.teluguName})</span>
              </div>
              <div className="text-xs text-[#A09A8E] mt-0.5 font-light">
                {currentMeta.description}
              </div>
            </div>
          </div>
          <div className="shrink-0 text-xs font-mono text-[#D4AF37] bg-[#1B1E28] px-3 py-1.5 rounded border border-[#2D303E]">
            Theme: {currentMeta.concept}
          </div>
        </div>

        {/* Secondary Filters: Silhouette Category & Sorting */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-2">
          {/* Silhouette Categories */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`text-xs px-3.5 py-1.5 rounded-full whitespace-nowrap transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-[#D4AF37] text-black font-semibold'
                    : 'bg-[#14161E] text-[#C8C2B7] hover:text-white border border-[#25231F]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-3 self-end md:self-auto">
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="text-xs text-[#A09A8E] uppercase tracking-wider hidden sm:inline">Sort:</span>
            <select
              value={selectedSort}
              onChange={e => onSelectSort(e.target.value)}
              className="bg-[#14161E] border border-[#3A3832] text-xs text-[#FAF7F0] rounded px-3 py-1.5 focus:outline-none focus:border-[#D4AF37] cursor-pointer"
            >
              <option value="featured">Editorial Curation</option>
              <option value="hours-desc">Artisan Loom Hours (High to Low)</option>
              <option value="price-desc">Price (Haute Couture to Accessible)</option>
              <option value="price-asc">Price (Accessible to Haute)</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
