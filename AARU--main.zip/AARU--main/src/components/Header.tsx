import React, { useState } from 'react';
import { Search, ShoppingBag, Bell, User, MessageCircle, Heart, X, Sparkles, Compass, ChevronDown, LogOut } from 'lucide-react';
import { Product, UserProfile } from '../types';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  unreadNotifications: number;
  currentUser?: UserProfile | null;
  onLogout?: () => void;
  onOpenCart: () => void;
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
  onOpenWishlist?: () => void;
  onOpenConsultation: () => void;
  onOpenQuiz?: () => void;
  onOpenSearch?: () => void;
  onSelectStory: () => void;
  onSelectCollection: (element?: string) => void;
  onSelectCategory?: (category: string) => void;
  onNavigateHome?: () => void;
  onNavigateReadyToShip?: () => void;
  onNavigateSareesReadyToShip?: () => void;
  onNavigateCollections?: (id?: string) => void;
  onNavigateShopTheLook?: () => void;
  onNavigateCatalogue?: () => void;
  onNavigateWishlist?: () => void;
  currentView?: string;
  currency: 'INR' | 'USD';
  onToggleCurrency: () => void;
  onSearchSelect: (product: Product) => void;
  allProducts: Product[];
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  unreadNotifications,
  currentUser,
  onLogout,
  onOpenCart,
  onOpenNotifications,
  onOpenProfile,
  onOpenWishlist,
  onOpenConsultation,
  onOpenQuiz,
  onOpenSearch,
  onSelectStory,
  onSelectCollection,
  onSelectCategory,
  onNavigateHome,
  onNavigateReadyToShip,
  onNavigateSareesReadyToShip,
  onNavigateCollections,
  onNavigateShopTheLook,
  onNavigateCatalogue,
  onNavigateWishlist,
  currentView,
  currency,
  onToggleCurrency,
  onSearchSelect,
  allProducts
}) => {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const searchResults = searchQuery.trim()
    ? allProducts.filter(p =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.element.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.fabric.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  return (
    <header className="sticky top-0 z-40 bg-[#060709]/95 backdrop-blur-md border-b border-[#1E2028]">
      {/* Main Navbar: Spacious, High-Fashion Luxury Proportions */}
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 h-24 flex items-center justify-between gap-6 lg:gap-8">
        {/* Brand Left Identity: Telugu Crest + AARU + The Sixth Element */}
        <div
          onClick={() => {
            if (onNavigateHome) onNavigateHome();
            else onSelectCollection('all');
          }}
          className="cursor-pointer flex items-center gap-3 sm:gap-3.5 flex-shrink-0 group select-none"
        >
          {/* Circular Telugu Logo Crest: ఆరు */}
          <div className="relative flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-b from-[#252015] via-[#15130D] to-[#0A0906] border border-[#D4AF37]/80 shadow-[0_0_18px_rgba(212,175,55,0.25)] group-hover:border-[#D4AF37] transition-all">
            <span className="font-telugu text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FFF0C2] via-[#D4AF37] to-[#BFA050] tracking-tight">
              ఆరు
            </span>
          </div>

          {/* English Brand Name & Subtitle */}
          <div className="flex flex-col text-left">
            <span className="font-cinzel text-2xl sm:text-3xl font-bold tracking-[0.28em] text-[#FAF7F0] group-hover:text-[#D4AF37] transition-colors leading-none">
              AARU
            </span>
            <span className="text-[8.5px] sm:text-[9px] uppercase tracking-[0.4em] text-[#C5A059] font-medium mt-1">
              THE SIXTH ELEMENT
            </span>
          </div>
        </div>

        {/* Search Pill Trigger */}
        <div className="hidden md:flex items-center">
          <button
            onClick={() => {
              if (onOpenSearch) {
                onOpenSearch();
              } else {
                setSearchOpen(!searchOpen);
              }
            }}
            className="flex items-center gap-2.5 px-4 py-2 rounded-full bg-[#10121A] hover:bg-[#161924] border border-[#2B3040] hover:border-[#D4AF37] text-xs text-[#9B9DA8] transition-all group"
          >
            <Search className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="text-[11px] tracking-widest uppercase">SEARCH</span>
            <span className="text-[9px] font-mono text-[#62677C] bg-[#161925] border border-[#25293A] px-1.5 py-0.5 rounded">⌘K</span>
          </button>
        </div>

        {/* Navigation Links in Center - Generous Padding & Spacing */}
        <nav className="hidden lg:flex items-center gap-8 xl:gap-10 text-[12px] uppercase tracking-[0.22em] font-medium text-[#C8C2B7]">
          <button
            onClick={() => {
              if (onNavigateCatalogue) onNavigateCatalogue();
              else onSelectCollection('all');
            }}
            className={`transition-colors py-1.5 whitespace-nowrap ${
              currentView === 'catalogue' ? 'text-[#D4AF37] font-semibold border-b border-[#D4AF37]' : 'hover:text-[#D4AF37]'
            }`}
          >
            All Clothing
          </button>

          <button
            onClick={() => {
              if (onNavigateCollections) onNavigateCollections('aaru');
              else onSelectCollection('all');
            }}
            className={`transition-colors py-1.5 whitespace-nowrap ${
              currentView === 'collection' ? 'text-[#D4AF37] font-semibold border-b border-[#D4AF37]' : 'hover:text-[#D4AF37]'
            }`}
          >
            Collections
          </button>

          <button
            onClick={() => {
              if (onNavigateShopTheLook) onNavigateShopTheLook();
              else onSelectCollection('all');
            }}
            className={`transition-colors py-1.5 whitespace-nowrap ${
              currentView === 'shop-the-look' ? 'text-[#D4AF37] font-semibold border-b border-[#D4AF37]' : 'hover:text-[#D4AF37]'
            }`}
          >
            Shop the Look
          </button>

          <button
            onClick={() => {
              if (onNavigateReadyToShip) onNavigateReadyToShip();
              else if (onSelectCategory) onSelectCategory('Ready to Ship');
            }}
            className={`transition-colors py-1.5 whitespace-nowrap flex items-center gap-1.5 ${
              currentView === 'ready-to-ship' ? 'text-emerald-400 font-semibold' : 'hover:text-[#D4AF37]'
            }`}
          >
            <span className="w-1.5 h-3 bg-emerald-500 rounded-full inline-block"></span>
            <span>Ready to Ship</span>
          </button>

          <button
            onClick={() => {
              if (onNavigateSareesReadyToShip) onNavigateSareesReadyToShip();
              else if (onSelectCategory) onSelectCategory('Sarees');
            }}
            className={`transition-colors py-1.5 whitespace-nowrap ${
              currentView === 'sarees-ready-to-ship' ? 'text-[#D4AF37] font-semibold border-b border-[#D4AF37]' : 'hover:text-[#D4AF37]'
            }`}
          >
            Sarees
          </button>
        </nav>

        {/* Right Nav Utilities: Spacious, comfortable touch targets */}
        <div className="flex items-center gap-3 sm:gap-3.5">
          {/* Mobile Search Button */}
          <button
            onClick={() => {
              if (onOpenSearch) {
                onOpenSearch();
              } else {
                setSearchOpen(!searchOpen);
              }
            }}
            className="md:hidden p-2.5 text-[#C8C2B7] hover:text-[#D4AF37]"
            title="Search"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* 1. Account Pill */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-full bg-[#10121A] hover:bg-[#171A26] border border-[#2B3040] hover:border-[#D4AF37] text-xs text-[#FAF7F0] transition-all cursor-pointer"
              title="Account & Orders"
            >
              <User className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="hidden sm:inline text-[11px] font-medium tracking-wider uppercase truncate max-w-[110px]">
                {currentUser ? (currentUser.fullName.split(' ')[0] || 'ACCOUNT') : 'ACCOUNT'}
              </span>
              <ChevronDown className="w-3 h-3 text-[#A09A8E]" />
            </button>

            {onLogout && (
              <button
                onClick={onLogout}
                className="hidden lg:flex items-center justify-center w-8 h-8 rounded-full bg-[#141620] hover:bg-red-950/40 border border-[#242838] hover:border-red-500/50 text-[#8E94A5] hover:text-red-400 transition-all cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* 2. Wishlist Pill */}
          <button
            onClick={onOpenWishlist || onOpenProfile}
            className="flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-full bg-[#10121A] hover:bg-[#171A26] border border-[#2B3040] hover:border-[#D4AF37] text-xs text-[#FAF7F0] transition-all cursor-pointer"
            title="Wishlist / Saved Items"
          >
            <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400/20" />
            {wishlistCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-[#8E3B20] text-white text-[10px] font-bold flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
            <span className="hidden sm:inline text-[11px] font-medium tracking-wider uppercase">WISHLIST</span>
          </button>

          {/* 3. Cart Pill */}
          <button
            onClick={onOpenCart}
            className="flex items-center gap-2 px-4 sm:px-4.5 py-2 rounded-full bg-[#10121A] hover:bg-[#171A26] border border-[#2B3040] hover:border-[#D4AF37] text-xs text-[#FAF7F0] transition-all cursor-pointer"
            title="Shopping Cart"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="hidden sm:inline text-[11px] font-medium tracking-wider uppercase">CART</span>
            <span className="w-4 h-4 rounded-full bg-[#D4AF37] text-black text-[10px] font-bold flex items-center justify-center">
              {cartCount}
            </span>
          </button>

          {/* 4. WhatsApp Pill Button */}
          <button
            onClick={onOpenConsultation}
            className="flex items-center gap-2 px-4 sm:px-4.5 py-2 rounded-full bg-[#0D1C14] hover:bg-[#132A1E] border border-emerald-600/60 hover:border-emerald-500 text-emerald-400 text-xs transition-all cursor-pointer"
            title="Style Consultation"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline text-[11px] font-medium tracking-wider uppercase">WHATSAPP</span>
          </button>
        </div>
      </div>

      {/* Expandable Search Drawer */}
      {searchOpen && (
        <div className="bg-[#0C0E14] border-t border-[#232736] px-4 py-4 sm:px-8 animate-in fade-in duration-200">
          <div className="max-w-3xl mx-auto relative">
            <div className="relative flex items-center">
              <Search className="w-5 h-5 text-[#D4AF37] absolute left-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search by weave (Kanchipuram, Banarasi, Jamdani), element (Agni, Akasha), or garment..."
                className="w-full bg-[#07080C] border border-[#303546] focus:border-[#D4AF37] rounded-full pl-11 pr-10 py-3 text-sm text-[#F5F2EA] focus:outline-none placeholder-[#7A7E8C]"
                autoFocus
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 text-[#A09A8E] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Live Search Quick Results */}
            {searchResults.length > 0 && (
              <div className="mt-3 bg-[#0A0C12] border border-[#232736] rounded-xl overflow-hidden shadow-2xl">
                {searchResults.map(prod => (
                  <div
                    key={prod.id}
                    onClick={() => {
                      onSearchSelect(prod);
                      setSearchOpen(false);
                      setSearchQuery('');
                    }}
                    className="p-3 hover:bg-[#141722] cursor-pointer flex items-center justify-between border-b border-[#1A1D28] last:border-0 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={prod.images[0]}
                        alt={prod.name}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 object-cover rounded"
                      />
                      <div>
                        <div className="text-xs font-medium text-[#FAF7F0] flex items-center gap-2">
                          <span>{prod.name}</span>
                          <span className="font-telugu text-[11px] text-[#D4AF37]">{prod.teluguName}</span>
                        </div>
                        <div className="text-[10px] text-[#8C8F9E]">{prod.fabric} · {prod.element.toUpperCase()}</div>
                      </div>
                    </div>
                    <div className="text-xs text-[#D4AF37] font-mono">
                      {currency === 'INR' ? `₹${prod.priceINR.toLocaleString('en-IN')}` : `$${prod.priceUSD.toLocaleString()}`}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0E1015] border-t border-[#2A2824] px-6 py-6 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#2A2824]">
            <span className="font-telugu text-xl text-[#D4AF37]">ఆరు</span>
            <span className="font-cinzel text-lg tracking-widest text-white">AARU ATELIER</span>
          </div>
          <div className="flex flex-col space-y-3 text-sm uppercase tracking-widest text-[#C8C2B7]">
            <button
              onClick={() => {
                if (onNavigateCatalogue) onNavigateCatalogue();
                else onSelectCollection('all');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 hover:text-[#D4AF37]"
            >
              All Clothing
            </button>
            <button
              onClick={() => {
                if (onNavigateCollections) onNavigateCollections('aaru');
                else onSelectCollection('all');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 hover:text-[#D4AF37]"
            >
              Collections
            </button>
            <button
              onClick={() => {
                if (onNavigateShopTheLook) onNavigateShopTheLook();
                else onSelectCollection('all');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 hover:text-[#D4AF37]"
            >
              Shop the Look
            </button>
            <button
              onClick={() => {
                if (onNavigateReadyToShip) onNavigateReadyToShip();
                else if (onSelectCategory) onSelectCategory('Ready to Ship');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-emerald-400 font-medium flex items-center gap-2"
            >
              <span className="w-1.5 h-3 bg-emerald-500 rounded-full inline-block"></span>
              Ready to Ship
            </button>
            <button
              onClick={() => {
                if (onNavigateSareesReadyToShip) onNavigateSareesReadyToShip();
                else if (onSelectCategory) onSelectCategory('Sarees');
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-[#D4AF37]"
            >
              Sarees
            </button>
            <button
              onClick={() => {
                onOpenWishlist ? onOpenWishlist() : onOpenProfile();
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-rose-300 flex items-center justify-between cursor-pointer"
            >
              <span>Wishlist</span>
              {wishlistCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-[#8E3B20] text-white text-[11px] font-bold">
                  {wishlistCount}
                </span>
              )}
            </button>
            <button
              onClick={() => {
                onOpenConsultation();
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-[#D4AF37]"
            >
              Book Style Consultation
            </button>
            <button
              onClick={() => {
                onOpenProfile();
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 hover:text-white"
            >
              My Account & Orders
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
