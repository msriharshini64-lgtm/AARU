import React, { useState } from 'react';
import { X, MessageCircle, Video, Calendar, Sparkles, CheckCircle2, Clock, ShieldCheck } from 'lucide-react';
import { ConsultationRequest } from '../types';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Partial<ConsultationRequest>) => Promise<void>;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  onSubmit
}) => {
  const [channel, setChannel] = useState<'whatsapp' | 'video_call'>('whatsapp');
  const [clientName, setClientName] = useState('Gayathri Rao');
  const [email, setEmail] = useState('gayathri.rao@aaru-clientele.com');
  const [phone, setPhone] = useState('+91 98490 12345');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [coutureInterest, setCoutureInterest] = useState('The Sovereign Āru Kanjeevaram Saree Bespoke Drapery');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit({
      clientName,
      email,
      phone,
      preferredChannel: channel,
      preferredDate: date,
      coutureInterest,
      measurementsNotes: notes
    });
    setSubmitted(true);
  };

  const handleOpenWhatsAppDirect = () => {
    const text = encodeURIComponent(
      `Hello AARU Atelier, I am booking a consultation for: "${coutureInterest}". My name is ${clientName}. I would like to consult via WhatsApp Business.`
    );
    window.open(`https://wa.me/918008006600?text=${text}`, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="relative max-w-xl w-full bg-[#0E1016] border border-[#3A3832] rounded-sm shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="px-6 py-4 bg-[#141620] border-b border-[#25231F] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-telugu text-xl font-bold text-[#D4AF37]">ఆరు</span>
            <div>
              <h2 className="font-cinzel text-base font-bold text-[#FAF7F0] tracking-wider uppercase">
                Custom Clothing & Couture Consultation
              </h2>
              <div className="text-[10px] text-[#A09A8E]">
                Direct WhatsApp Business & Private Salon Appointments
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#1E2130] text-[#A09A8E] hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
            <div className="p-3 bg-[#13151D] border border-[#252838] rounded-sm text-xs text-[#C8C2B7] space-y-1">
              <div className="font-semibold text-[#D4AF37] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Dedicated Couturier Attention</span>
              </div>
              <p className="text-[11px] text-[#A09A8E]">
                Whether you desire custom blouse sculpting, heirloom bridal lehengas, or pure 24k gold monogramming, our senior design team will guide you step-by-step.
              </p>
            </div>

            {/* Channel Choice */}
            <div>
              <label className="text-[10px] text-[#A09A8E] uppercase block mb-1.5 font-semibold">
                Consultation Medium
              </label>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <button
                  type="button"
                  onClick={() => setChannel('whatsapp')}
                  className={`p-3 rounded-sm border text-left flex items-center gap-2.5 transition-all ${
                    channel === 'whatsapp'
                      ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300'
                      : 'bg-[#141620] border-[#252838] text-[#A09A8E]'
                  }`}
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <div>
                    <div className="font-semibold text-white">WhatsApp Business</div>
                    <div className="text-[10px]">Instant chat & media exchange</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setChannel('video_call')}
                  className={`p-3 rounded-sm border text-left flex items-center gap-2.5 transition-all ${
                    channel === 'video_call'
                      ? 'bg-[#1C1A28] border-[#8B5CF6] text-purple-300'
                      : 'bg-[#141620] border-[#252838] text-[#A09A8E]'
                  }`}
                >
                  <Video className="w-4 h-4 text-purple-400" />
                  <div>
                    <div className="font-semibold text-white">Private Video Fitting</div>
                    <div className="text-[10px]">30 min live atelier camera</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">Your Name</label>
                <input
                  type="text"
                  required
                  value={clientName}
                  onChange={e => setClientName(e.target.value)}
                  className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                />
              </div>

              <div>
                <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">WhatsApp Phone Number</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">Creation or Silhouette of Interest</label>
                <input
                  type="text"
                  required
                  value={coutureInterest}
                  onChange={e => setCoutureInterest(e.target.value)}
                  placeholder="e.g. Sovereign Āru Saree / Bridal Lehenga / Custom Sherwani"
                  className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                />
              </div>

              <div>
                <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">Preferred Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                />
              </div>

              <div>
                <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">Patron Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
                />
              </div>
            </div>

            <div className="text-xs">
              <label className="text-[10px] text-[#A09A8E] uppercase block mb-1">
                Custom Measurement or Styling Notes (Optional)
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Mention specific blouse necklines, sleeve lengths, drape preference, or wedding dates..."
                className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-[#D4AF37] rounded px-3 py-2 text-[#F5F2EA]"
              />
            </div>

            {/* Direct WhatsApp Callout */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                type="submit"
                className="flex-1 py-3.5 bg-[#D4AF37] hover:bg-[#E5C07B] text-black font-semibold text-xs uppercase tracking-wider rounded-sm transition-all"
              >
                Schedule Consultation
              </button>

              <button
                type="button"
                onClick={handleOpenWhatsAppDirect}
                className="px-5 py-3.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-600/50 text-emerald-300 font-semibold text-xs uppercase tracking-wider rounded-sm flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>Chat Instantly on WhatsApp</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-950 border border-emerald-500 mx-auto flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-7 h-7" />
            </div>

            <h3 className="font-cinzel text-xl font-bold text-[#FAF7F0]">
              Consultation Scheduled
            </h3>

            <p className="text-xs text-[#A09A8E] max-w-sm mx-auto">
              Our Senior Couturier will reach out to you at <span className="text-white font-mono">{phone}</span> on WhatsApp Business shortly.
            </p>

            <div className="pt-4">
              <button
                onClick={handleOpenWhatsAppDirect}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-black font-semibold text-xs uppercase tracking-wider rounded-sm flex items-center justify-center gap-2 mx-auto"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Open WhatsApp Chat Now</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
