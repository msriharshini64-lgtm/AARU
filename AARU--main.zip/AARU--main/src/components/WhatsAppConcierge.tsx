import React, { useState } from 'react';
import { MessageCircle, X, ChevronRight, Sparkles, Shield, Clock, Send } from 'lucide-react';
import { WHATSAPP_CONSULTATION_TEMPLATES } from '../data/mockData';

interface WhatsAppConciergeProps {
  onOpenBookingModal: () => void;
}

export const WhatsAppConcierge: React.FC<WhatsAppConciergeProps> = ({ onOpenBookingModal }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [customMsg, setCustomMsg] = useState('');

  const WHATSAPP_NUMBER = '918008006600'; // Atelier VIP Concierge line

  const handleOpenWhatsApp = (text: string) => {
    const encoded = encodeURIComponent(text);
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleSubmitCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMsg.trim()) return;
    handleOpenWhatsApp(customMsg);
    setCustomMsg('');
    setIsOpen(false);
  };

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="group flex items-center gap-2.5 px-4 py-2.5 bg-[#09150E]/95 hover:bg-[#0E2016] text-[#FAF7F0] rounded-full border border-emerald-600/70 hover:border-emerald-500 shadow-[0_8px_30px_rgba(0,0,0,0.8)] hover:shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all cursor-pointer"
            aria-label="Open WhatsApp Couturier Concierge"
          >
            <span className="font-telugu font-bold text-base text-[#FAF7F0] leading-none">
              ఆరు
            </span>
            <div className="relative flex items-center justify-center w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 group-hover:scale-110 transition-transform">
              <MessageCircle className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-400 rounded-full animate-ping"></span>
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-400 rounded-full"></span>
            </div>
          </button>
        )}

        {/* Expanded Concierge Card */}
        {isOpen && (
          <div className="w-[340px] sm:w-[380px] bg-[#0E1016] border border-[#3A3832] rounded-sm shadow-[0_15px_50px_rgba(0,0,0,0.9)] overflow-hidden animate-in slide-in-from-bottom-5 duration-300">
            {/* Header */}
            <div className="p-4 bg-[#141620] border-b border-[#2A2824] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-950 border border-emerald-500/60 flex items-center justify-center text-emerald-400 font-telugu text-lg">
                  ఆరు
                </div>
                <div>
                  <div className="text-xs font-bold text-[#FAF7F0] tracking-wider uppercase flex items-center gap-1.5">
                    <span>AARU VIP Concierge</span>
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  </div>
                  <div className="text-[10px] text-[#A09A8E]">
                    Bespoke Clothing & Custom Consultation Desk
                  </div>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1 text-[#A09A8E] hover:text-white rounded-full hover:bg-[#1F2230]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body */}
            <div className="p-4 space-y-3 max-h-[360px] overflow-y-auto">
              <div className="p-3 bg-[#171924] rounded border border-[#252838] text-xs text-[#C8C2B7] leading-relaxed">
                <div className="font-semibold text-[#D4AF37] mb-1 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  Namaste from the AARU Atelier
                </div>
                Connect directly with our senior couturiers on WhatsApp Business for fabric swatches, custom sizing, or private salon fittings.
              </div>

              <div className="text-[11px] uppercase tracking-wider text-[#A09A8E] font-semibold">
                Direct Consultation Topics:
              </div>

              {/* Quick Choice Buttons */}
              <button
                onClick={() => handleOpenWhatsApp(WHATSAPP_CONSULTATION_TEMPLATES.bespoke)}
                className="w-full p-2.5 rounded-sm bg-[#12141C] hover:bg-[#1B1E2B] border border-[#2A2824] hover:border-[#D4AF37] text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-medium text-[#FAF7F0] group-hover:text-[#D4AF37]">
                    Bespoke Couture Commission
                  </div>
                  <div className="text-[10px] text-[#A09A8E]">The Sixth Element custom silhouette</div>
                </div>
                <ChevronRight className="w-4 h-4 text-[#A09A8E] group-hover:text-[#D4AF37] group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => handleOpenWhatsApp(WHATSAPP_CONSULTATION_TEMPLATES.sizing)}
                className="w-full p-2.5 rounded-sm bg-[#12141C] hover:bg-[#1B1E2B] border border-[#2A2824] hover:border-[#D4AF37] text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-medium text-[#FAF7F0] group-hover:text-[#D4AF37]">
                    Made-to-Measure Sizing Help
                  </div>
                  <div className="text-[10px] text-[#A09A8E]">Video guidance with master tailor</div>
                </div>
                <ChevronRight className="w-4 h-4 text-[#A09A8E] group-hover:text-[#D4AF37] group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => handleOpenWhatsApp(WHATSAPP_CONSULTATION_TEMPLATES.swatches)}
                className="w-full p-2.5 rounded-sm bg-[#12141C] hover:bg-[#1B1E2B] border border-[#2A2824] hover:border-[#D4AF37] text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-medium text-[#FAF7F0] group-hover:text-[#D4AF37]">
                    Request 24k Zari & Swatch Kit
                  </div>
                  <div className="text-[10px] text-[#A09A8E]">Delivered in luxury velvet envelope</div>
                </div>
                <ChevronRight className="w-4 h-4 text-[#A09A8E] group-hover:text-[#D4AF37] group-hover:translate-x-0.5 transition-transform" />
              </button>

              {/* Custom message prompt */}
              <form onSubmit={handleSubmitCustom} className="pt-2 border-t border-[#252838]">
                <div className="relative flex items-center">
                  <input
                    type="text"
                    value={customMsg}
                    onChange={e => setCustomMsg(e.target.value)}
                    placeholder="Type custom inquiry for WhatsApp..."
                    className="w-full bg-[#0B0C10] border border-[#3A3832] focus:border-emerald-500 rounded pl-3 pr-9 py-2 text-xs text-[#FAF7F0] focus:outline-none placeholder-[#6B665E]"
                  />
                  <button
                    type="submit"
                    className="absolute right-2 text-emerald-400 hover:text-emerald-300 p-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            </div>

            {/* Footer with Schedule link */}
            <div className="p-3 bg-[#0B0C10] border-t border-[#22242E] flex items-center justify-between text-[11px] text-[#A09A8E]">
              <span className="flex items-center gap-1 text-emerald-400">
                <Clock className="w-3 h-3" />
                Response within ~15 mins
              </span>
              <button
                onClick={() => {
                  setIsOpen(false);
                  onOpenBookingModal();
                }}
                className="text-[#D4AF37] hover:underline font-medium"
              >
                Schedule Video Fitting
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
