import React, { useState } from 'react';
import {
  Sparkles,
  ShoppingBag,
  Check,
  ChevronLeft,
  ChevronRight,
  Eye,
  ArrowRight,
  Layers,
  ShieldCheck,
  Info
} from 'lucide-react';
import { Product, ShopTheLookEnsemble, ShopTheLookPiece } from '../types';
import { SHOP_THE_LOOKS } from '../data/mockData';

interface ShopTheLookProps {
  looks?: ShopTheLookEnsemble[];
  currency: 'INR' | 'USD';
  formatPrice: (price: number) => string;
  onAddToCart: (product: Product, size?: string) => void;
  onQuickViewProduct: (product: Product) => void;
  onViewProductDetails?: (productId: string) => void;
  onNavigateCatalogue?: () => void;
}

export const ShopTheLook: React.FC<ShopTheLookProps> = ({
  looks = SHOP_THE_LOOKS,
  currency,
  formatPrice,
  onAddToCart,
  onQuickViewProduct,
  onViewProductDetails,
  onNavigateCatalogue
}) => {
  const [activeLookIndex, setActiveLookIndex] = useState<number>(0);
  const [activeHotspotIndex, setActiveHotspotIndex] = useState<number | null>(0);
  const [addedPieceIds, setAddedPieceIds] = useState<Record<string, boolean>>({});
  const [isBundleAdded, setIsBundleAdded] = useState(false);

  const currentLook = looks[activeLookIndex] || looks[0];

  const handleNextLook = () => {
    setActiveLookIndex(prev => (prev + 1) % looks.length);
    setActiveHotspotIndex(0);
    setIsBundleAdded(false);
  };

  const handlePrevLook = () => {
    setActiveLookIndex(prev => (prev - 1 + looks.length) % looks.length);
    setActiveHotspotIndex(0);
    setIsBundleAdded(false);
  };

  const handleAddPiece = (piece: ShopTheLookPiece) => {
    onAddToCart(piece.product, piece.product.sizes[0] || 'Free Size');
    setAddedPieceIds(prev => ({ ...prev, [piece.productId]: true }));
    setTimeout(() => {
      setAddedPieceIds(prev => ({ ...prev, [piece.productId]: false }));
    }, 2200);
  };

  const handleAddCompleteLook = () => {
    currentLook.pieces.forEach(p => {
      onAddToCart(p.product, p.product.sizes[0] || 'Free Size');
    });
    setIsBundleAdded(true);
    setTimeout(() => {
      setIsBundleAdded(false);
    }, 2800);
  };

  const totalBundlePrice = currentLook.pieces.reduce((sum, p) => sum + p.product.price, 0);

  return (
    <section id="shop-the-look-section" className="py-20 bg-[#07080B] text-[#FAF7F0] border-t border-[#1E2230] relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#161B2E]/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#1E2230]">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-px bg-[#D4AF37]" />
              <span className="text-[11px] uppercase tracking-[0.24em] text-[#D4AF37] font-medium">
                ATELIER ENSEMBLE STYLING
              </span>
            </div>
            <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#FAF7F0] tracking-wide">
              Shop The Look
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#A09A8E] max-w-2xl font-sans">
              Discover complete master-styled silhouettes curated by our lead couturiers. Hover over hotspots or browse the carousel beneath to acquire individual pieces or the complete look.
            </p>
          </div>

          {/* Look Navigation Controls */}
          <div className="mt-6 md:mt-0 flex items-center gap-3">
            <div className="text-right mr-3 hidden sm:block">
              <span className="text-xs uppercase tracking-widest text-[#7E8294] block">LOOKBOOK</span>
              <span className="font-mono text-sm text-[#D4AF37] font-semibold">
                0{activeLookIndex + 1} / 0{looks.length}
              </span>
            </div>
            <button
              id="look-prev-btn"
              onClick={handlePrevLook}
              aria-label="Previous styled look"
              className="p-3 rounded-full bg-[#12141D] border border-[#252A3D] text-[#FAF7F0] hover:text-[#D4AF37] hover:border-[#D4AF37] transition-all"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              id="look-next-btn"
              onClick={handleNextLook}
              aria-label="Next styled look"
              className="p-3 rounded-full bg-[#12141D] border border-[#252A3D] text-[#FAF7F0] hover:text-[#D4AF37] hover:border-[#D4AF37] transition-all"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Look Selector Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {looks.map((look, idx) => (
            <button
              key={look.id}
              id={`look-tab-${look.id}`}
              onClick={() => {
                setActiveLookIndex(idx);
                setActiveHotspotIndex(0);
                setIsBundleAdded(false);
              }}
              className={`px-4 py-2.5 rounded-full text-xs font-medium uppercase tracking-[0.14em] whitespace-nowrap transition-all border ${
                activeLookIndex === idx
                  ? 'bg-[#D4AF37] text-[#0A0B0E] border-[#D4AF37] font-semibold shadow-[0_0_15px_rgba(212,175,55,0.3)]'
                  : 'bg-[#10121A] text-[#A09A8E] border-[#222738] hover:border-[#D4AF37]/60 hover:text-[#FAF7F0]'
              }`}
            >
              Look 0{idx + 1}: {look.title.split(' ')[1] || look.title}
            </button>
          ))}
        </div>

        {/* Main Look Showcase: Grid with Interactive Image Card + Editorial & Bundle Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left: Lifestyle Imagery Card with Interactive Shoppable Hotspots (7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="relative rounded-2xl overflow-hidden bg-[#10121A] border border-[#222738] aspect-[3/4] sm:aspect-[4/5] shadow-2xl group">
              {/* Main Image */}
              <img
                src={currentLook.heroLifestyleImage}
                alt={currentLook.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#090A0E] via-transparent to-black/30 pointer-events-none" />

              {/* Look Tag Badge on Top Left */}
              <div className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-[#090A0E]/80 backdrop-blur-md border border-[#D4AF37]/40 px-3.5 py-1.5 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span className="text-[10px] uppercase tracking-[0.18em] text-[#FAF7F0] font-medium">
                  {currentLook.occasion}
                </span>
              </div>

              {/* Interactive Shoppable Hotspots */}
              {currentLook.pieces.map((piece, pIdx) => {
                const isActive = activeHotspotIndex === pIdx;
                return (
                  <div
                    key={piece.productId}
                    className="absolute z-30 transform -translate-x-1/2 -translate-y-1/2"
                    style={{ left: `${piece.hotspot.x}%`, top: `${piece.hotspot.y}%` }}
                  >
                    {/* Hotspot Pulse Button */}
                    <button
                      id={`hotspot-btn-${piece.productId}`}
                      onClick={() => setActiveHotspotIndex(isActive ? null : pIdx)}
                      onMouseEnter={() => setActiveHotspotIndex(pIdx)}
                      aria-label={`View piece: ${piece.hotspot.label}`}
                      className="relative flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 group/btn"
                    >
                      {/* Pulsing Aura */}
                      <span className={`absolute inset-0 rounded-full bg-[#D4AF37]/50 ${isActive ? 'animate-ping' : 'animate-pulse'}`} />
                      {/* Inner Ring */}
                      <span className={`relative flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8 rounded-full border-2 transition-all shadow-lg ${
                        isActive
                          ? 'bg-[#D4AF37] border-white text-black scale-110'
                          : 'bg-[#0E1017]/90 border-[#D4AF37] text-[#D4AF37] hover:scale-110'
                      }`}>
                        <span className="font-mono text-xs font-bold">0{pIdx + 1}</span>
                      </span>
                    </button>

                    {/* Floating Popover Card on Active Hotspot */}
                    {isActive && (
                      <div className="absolute left-1/2 bottom-full mb-3 -translate-x-1/2 w-64 sm:w-72 bg-[#0C0E14]/95 backdrop-blur-md border border-[#D4AF37]/70 rounded-xl p-3.5 shadow-[0_10px_30px_rgba(0,0,0,0.8)] z-40 animate-fadeIn">
                        <div className="flex gap-3 items-center">
                          <img
                            src={piece.product.images[0]}
                            alt={piece.product.name}
                            referrerPolicy="no-referrer"
                            className="w-14 h-18 object-cover rounded border border-[#252A3C] flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <span className="text-[9px] uppercase tracking-wider text-[#D4AF37] font-semibold block truncate">
                              {piece.hotspot.role}
                            </span>
                            <h4 className="text-xs font-cinzel font-bold text-[#FAF7F0] truncate">
                              {piece.product.name}
                            </h4>
                            <div className="mt-1 font-mono text-xs text-[#D4AF37] font-semibold">
                              {formatPrice(piece.product.price)}
                            </div>
                          </div>
                        </div>

                        <p className="mt-2 text-[10px] text-[#A09A8E] line-clamp-2 border-t border-[#1C2030] pt-2 italic">
                          "{piece.stylingTip}"
                        </p>

                        <div className="mt-3 flex gap-2">
                          <button
                            id={`popover-add-btn-${piece.productId}`}
                            onClick={() => handleAddPiece(piece)}
                            className="flex-1 py-1.5 px-3 rounded-lg bg-[#D4AF37] hover:bg-[#E5C158] text-black text-[11px] font-bold tracking-wider uppercase flex items-center justify-center gap-1.5 transition-colors"
                          >
                            {addedPieceIds[piece.productId] ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-950" />
                                <span>Added</span>
                              </>
                            ) : (
                              <>
                                <ShoppingBag className="w-3.5 h-3.5" />
                                <span>Add to Bag</span>
                              </>
                            )}
                          </button>
                          <button
                            id={`popover-view-btn-${piece.productId}`}
                            onClick={() => onQuickViewProduct(piece.product)}
                            className="p-1.5 rounded-lg bg-[#181B26] hover:bg-[#252A3C] border border-[#2C3246] text-[#FAF7F0] transition-colors"
                            title="Quick View Silhouette"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Bottom Caption Overlay */}
              <div className="absolute bottom-4 left-4 right-4 z-20 flex justify-between items-end bg-[#090A0E]/80 backdrop-blur-sm p-4 rounded-xl border border-[#1E2230]">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-telugu text-sm text-[#D4AF37]">
                      {currentLook.teluguTitle || 'సార్వభౌమ అలంకరణ'}
                    </span>
                    <span className="text-[#3A4056]">•</span>
                    <span className="text-[11px] text-[#A09A8E] font-medium">
                      Curated by {currentLook.curator.name}
                    </span>
                  </div>
                  <h3 className="font-cinzel text-lg sm:text-xl font-bold text-[#FAF7F0] mt-0.5">
                    {currentLook.title}
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase tracking-wider text-[#A09A8E] block">Ensemble Total</span>
                  <span className="font-mono text-base font-bold text-[#D4AF37]">
                    {formatPrice(totalBundlePrice)}
                  </span>
                </div>
              </div>
            </div>

            {/* Instruction Tip */}
            <div className="flex items-center gap-2 text-xs text-[#7E8294] px-2">
              <Info className="w-4 h-4 text-[#D4AF37]" />
              <span>Click or tap any numbered gold hotspot on the model to reveal garment details and add to your bag.</span>
            </div>
          </div>

          {/* Right: Editorial Narrative + Linked Product Pieces Breakdown (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* Editorial Story Box */}
            <div className="bg-[#10121A] rounded-2xl p-6 border border-[#1F2436] relative">
              <div className="flex items-center gap-2 mb-2">
                <Layers className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#D4AF37] font-medium">
                  COUTURIER STYLING DIARY
                </span>
              </div>
              <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-[#FAF7F0] mb-2">
                {currentLook.subtitle}
              </h3>
              <p className="text-xs sm:text-sm text-[#A09A8E] font-sans leading-relaxed">
                {currentLook.story}
              </p>

              {/* Curator Quote */}
              <div className="mt-4 pt-4 border-t border-[#1C2030] flex items-center justify-between text-xs text-[#7E8294]">
                <div>
                  <span className="text-[#FAF7F0] font-semibold block">{currentLook.curator.name}</span>
                  <span className="text-[11px] text-[#A09A8E]">{currentLook.curator.role}</span>
                </div>
                <div className="w-8 h-8 rounded-full bg-[#181B26] border border-[#2D3347] flex items-center justify-center text-[#D4AF37] font-telugu text-sm">
                  ఆరు
                </div>
              </div>
            </div>

            {/* Curated Pieces in this Look */}
            <div>
              <div className="flex items-center justify-between mb-3 px-1">
                <span className="text-xs uppercase tracking-[0.16em] text-[#FAF7F0] font-semibold flex items-center gap-1.5">
                  <span>Pieces in this Ensemble</span>
                  <span className="text-xs font-mono text-[#D4AF37]">({currentLook.pieces.length})</span>
                </span>
                <span className="text-[11px] text-[#A09A8E]">Available individually</span>
              </div>

              <div className="space-y-3">
                {currentLook.pieces.map((piece, pIdx) => {
                  const isHovered = activeHotspotIndex === pIdx;
                  return (
                    <div
                      key={piece.productId}
                      id={`piece-card-${piece.productId}`}
                      onMouseEnter={() => setActiveHotspotIndex(pIdx)}
                      className={`p-3.5 rounded-xl border transition-all duration-300 flex items-center gap-4 ${
                        isHovered
                          ? 'bg-[#151926] border-[#D4AF37] shadow-[0_4px_20px_rgba(212,175,55,0.15)]'
                          : 'bg-[#0E1017] border-[#1D2233] hover:border-[#2C334A]'
                      }`}
                    >
                      {/* Piece Number & Thumbnail */}
                      <div className="relative flex-shrink-0">
                        <img
                          src={piece.product.images[0]}
                          alt={piece.product.name}
                          referrerPolicy="no-referrer"
                          className="w-16 h-20 object-cover rounded-lg border border-[#252A3D]"
                        />
                        <span className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-[#D4AF37] text-black font-mono text-[10px] font-bold flex items-center justify-center">
                          0{pIdx + 1}
                        </span>
                      </div>

                      {/* Info & Action */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] uppercase tracking-wider text-[#D4AF37] font-semibold">
                            {piece.hotspot.role}
                          </span>
                          {piece.product.availability === 'in_stock' && (
                            <span className="text-[8px] uppercase tracking-wider bg-emerald-950/80 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-800/60">
                              Ready to Ship
                            </span>
                          )}
                        </div>

                        <h4 className="font-cinzel text-sm font-bold text-[#FAF7F0] truncate mt-0.5">
                          {piece.product.name}
                        </h4>

                        <p className="text-[11px] text-[#8E8B82] truncate mt-0.5">
                          {piece.product.fabric} • {piece.product.weaveOrigin.split(',')[0]}
                        </p>

                        <div className="mt-1.5 flex items-center justify-between">
                          <span className="font-mono text-xs text-[#D4AF37] font-semibold">
                            {formatPrice(piece.product.price)}
                          </span>

                          <div className="flex items-center gap-2">
                            <button
                              id={`quick-view-piece-${piece.productId}`}
                              onClick={() => onQuickViewProduct(piece.product)}
                              className="text-[11px] text-[#A09A8E] hover:text-[#FAF7F0] underline underline-offset-4"
                            >
                              Details
                            </button>
                            <button
                              id={`add-piece-${piece.productId}`}
                              onClick={() => handleAddPiece(piece)}
                              className={`py-1 px-3 rounded-lg text-xs font-semibold tracking-wider uppercase transition-all flex items-center gap-1 ${
                                addedPieceIds[piece.productId]
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-[#D4AF37] hover:bg-[#E5C158] text-black'
                              }`}
                            >
                              {addedPieceIds[piece.productId] ? (
                                <>
                                  <Check className="w-3 h-3" />
                                  <span>Added</span>
                                </>
                              ) : (
                                <>
                                  <ShoppingBag className="w-3 h-3" />
                                  <span>Add</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Add Complete Ensemble Action Box */}
            <div className="bg-gradient-to-b from-[#191D2B] to-[#10121A] rounded-2xl p-6 border border-[#D4AF37]/40 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#D4AF37] font-bold block">
                    COMPLETE LOOK BUNDLE
                  </span>
                  <h4 className="font-cinzel text-base font-bold text-[#FAF7F0]">
                    Acquire Full {currentLook.pieces.length}-Piece Ensemble
                  </h4>
                </div>
                <div className="text-right">
                  <span className="font-mono text-lg sm:text-xl font-bold text-[#D4AF37]">
                    {formatPrice(totalBundlePrice)}
                  </span>
                </div>
              </div>

              {currentLook.bundleSavingsNote && (
                <div className="flex items-start gap-2 bg-[#0A0B0E]/60 p-2.5 rounded-lg border border-[#23283B] text-[11px] text-[#A09A8E]">
                  <ShieldCheck className="w-4 h-4 text-[#D4AF37] flex-shrink-0 mt-0.5" />
                  <span>{currentLook.bundleSavingsNote}</span>
                </div>
              )}

              <button
                id="add-full-look-bundle-btn"
                onClick={handleAddCompleteLook}
                className={`w-full py-3.5 px-6 rounded-xl font-cinzel text-xs sm:text-sm font-bold tracking-[0.18em] uppercase transition-all duration-300 flex items-center justify-center gap-2 shadow-lg ${
                  isBundleAdded
                    ? 'bg-emerald-600 text-white shadow-emerald-900/40'
                    : 'bg-[#D4AF37] hover:bg-[#E5C158] text-[#0A0B0E] shadow-[0_0_20px_rgba(212,175,55,0.25)]'
                }`}
              >
                {isBundleAdded ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Complete Look Added to Bag</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add Complete Look to Bag</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Editorial Callout */}
        <div className="mt-16 text-center">
          <p className="text-xs text-[#7E8294] font-sans tracking-wider uppercase mb-2">
            LOOKING FOR A CUSTOM COUTURE ENSEMBLE?
          </p>
          <button
            onClick={() => onNavigateCatalogue && onNavigateCatalogue()}
            className="inline-flex items-center gap-2 text-sm text-[#D4AF37] hover:text-[#FAF7F0] transition-colors font-cinzel tracking-widest border-b border-[#D4AF37]/50 pb-1"
          >
            <span>Explore All Atelier Silhouettes &amp; Heritage Weaves</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
