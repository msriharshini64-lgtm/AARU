import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  Sparkles,
  ArrowRight,
  Clock,
  CheckCircle2,
  Tag,
  Compass,
  Layers,
  Flame,
  Droplets,
  Wind,
  Globe,
  SlidersHorizontal,
  CornerDownLeft,
  History
} from 'lucide-react';
import { Product, SearchResponse, ElementType } from '../types';
import { api } from '../services/api';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: 'INR' | 'USD';
  onSelectProduct: (product: Product) => void;
  onSelectCollection: (element: string) => void;
  onSelectCategory: (category: string) => void;
}

const ELEMENT_ICONS: Record<string, any> = {
  aaru: Sparkles,
  ether: Globe,
  fire: Flame,
  water: Droplets,
  earth: Compass,
  air: Wind
};

const POPULAR_SEARCH_TAGS = [
  'Kanchipuram Silk',
  '24k Gold Zari',
  'Banarasi Kadwa',
  'Celestial Velvet Cape',
  'Pochampally Ikat',
  'Changthangi Pashmina',
  'Bridal Wedding'
];

const POPULAR_CATEGORIES = [
  { label: 'Heritage Sarees', value: 'saree' },
  { label: 'Bridal Lehengas', value: 'lehenga' },
  { label: 'Celestial Cape-Gowns', value: 'cape-gown' },
  { label: 'Regal Sherwanis', value: 'sherwani' },
  { label: 'Couture Kurta Sets', value: 'kurta' },
  { label: 'Pashmina Stoles', value: 'stole' }
];

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  currency,
  onSelectProduct,
  onSelectCollection,
  onSelectCategory
}) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchData, setSearchData] = useState<SearchResponse | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'products' | 'collections'>('all');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('aaru_recent_searches');
      return saved ? JSON.parse(saved) : ['Kanchipuram', 'Banarasi Kadwa', 'The Sixth Element'];
    } catch {
      return ['Kanchipuram', 'Banarasi Kadwa', 'The Sixth Element'];
    }
  });

  const inputRef = useRef<HTMLInputElement>(null);

  // Focus on mount and lock body scroll
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setTimeout(() => inputRef.current?.focus(), 80);
    } else {
      document.body.style.overflow = '';
      setQuery('');
      setSearchData(null);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Global shortcut escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Debounced search query
  useEffect(() => {
    if (!isOpen) return;

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await api.search({ q: query.trim() || undefined });
        setSearchData(res);
      } catch (err) {
        console.error('Search query failed:', err);
      } finally {
        setLoading(false);
      }
    }, 180);

    return () => clearTimeout(timer);
  }, [query, isOpen]);

  const saveRecentSearch = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    const updated = [trimmed, ...recentSearches.filter(s => s.toLowerCase() !== trimmed.toLowerCase())].slice(0, 5);
    setRecentSearches(updated);
    try {
      localStorage.setItem('aaru_recent_searches', JSON.stringify(updated));
    } catch {
      // Ignore
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      saveRecentSearch(query.trim());
    }
  };

  const handleSelectTag = (tag: string) => {
    setQuery(tag);
    saveRecentSearch(tag);
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem('aaru_recent_searches');
  };

  if (!isOpen) return null;

  const matchedProducts = searchData?.products || [];
  const matchedCollections = searchData?.collections || [];
  const hasResults = matchedProducts.length > 0 || matchedCollections.length > 0;
  const isZeroState = query.trim().length > 0 && !hasResults && !loading;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl mx-auto my-auto max-h-[90vh] bg-[#0A0C13] border border-[#262A3B] rounded-xl shadow-[0_25px_60px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Search Header Form */}
        <form onSubmit={handleSearchSubmit} className="p-4 sm:p-6 border-b border-[#1E2232] relative bg-[#0E111B]">
          <div className="relative flex items-center">
            <div className="absolute left-4 flex items-center gap-2 pointer-events-none">
              <Search className="w-5 h-5 text-[#D4AF37]" />
              <span className="font-telugu text-sm text-[#D4AF37]/80 hidden sm:inline">ఆరు</span>
            </div>

            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search by silk weave, element (Agni, Akasha), color, artisan, occasion, or garment..."
              className="w-full bg-[#06070B] border border-[#2D3349] focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] rounded-lg pl-14 sm:pl-20 pr-24 py-3.5 sm:py-4 text-sm sm:text-base text-[#FAF7F0] placeholder-[#6E7387] focus:outline-none transition-all shadow-inner"
            />

            <div className="absolute right-3.5 flex items-center gap-2">
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  className="p-1 rounded text-[#7B8094] hover:text-[#FAF7F0] hover:bg-[#1E2232] transition-colors"
                  aria-label="Clear search input"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="hidden sm:inline-flex items-center gap-1 text-[11px] font-mono text-[#8C91A5] bg-[#161926] border border-[#2B3044] px-2.5 py-1 rounded"
              >
                <span>ESC</span>
              </button>
            </div>
          </div>

          {/* Quick Filter Tabs */}
          <div className="flex items-center gap-2 mt-4 pt-2 border-t border-[#191D2C] overflow-x-auto text-xs scrollbar-none">
            <span className="text-[#686D82] text-[11px] uppercase tracking-wider font-semibold mr-1 flex items-center gap-1">
              <SlidersHorizontal className="w-3 h-3 text-[#D4AF37]" /> Filter:
            </span>
            {(['all', 'products', 'collections'] as const).map(tab => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${
                  activeTab === tab
                    ? 'bg-[#D4AF37] text-black font-semibold shadow-sm'
                    : 'bg-[#141724] text-[#A2A7BD] hover:bg-[#1C2032] hover:text-[#FAF7F0] border border-[#252A3D]'
                }`}
              >
                {tab === 'all' && `All Results (${matchedProducts.length + matchedCollections.length})`}
                {tab === 'products' && `Creations (${matchedProducts.length})`}
                {tab === 'collections' && `Elemental Realms (${matchedCollections.length})`}
              </button>
            ))}
          </div>
        </form>

        {/* Search Body Content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6 max-h-[60vh]">
          {/* Loading Indicator */}
          {loading && (
            <div className="py-8 text-center text-[#9E9B93] flex items-center justify-center gap-2 text-xs">
              <span className="w-4 h-4 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin"></span>
              <span>Scanning AARU Atelier archives...</span>
            </div>
          )}

          {/* 1. INITIAL STATE (No query entered yet) */}
          {!query.trim() && !loading && (
            <div className="space-y-6">
              {/* Recent Searches */}
              {recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center justify-between text-xs text-[#8C91A5] uppercase tracking-wider mb-2.5">
                    <span className="flex items-center gap-1.5 font-semibold">
                      <History className="w-3.5 h-3.5 text-[#D4AF37]" />
                      Recent Inquiries
                    </span>
                    <button
                      onClick={clearRecentSearches}
                      className="text-[11px] text-[#696E82] hover:text-[#D4AF37] transition-colors"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {recentSearches.map((term, i) => (
                      <button
                        key={i}
                        onClick={() => handleSelectTag(term)}
                        className="px-3 py-1.5 rounded-md bg-[#131623] hover:bg-[#1C2032] border border-[#252A3C] text-xs text-[#E1DCD2] hover:text-[#FAF7F0] transition-colors flex items-center gap-1.5"
                      >
                        <Clock className="w-3 h-3 text-[#7B8094]" />
                        <span>{term}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Trending Discovery Tags */}
              <div>
                <div className="text-xs text-[#8C91A5] uppercase tracking-wider font-semibold mb-2.5 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                  Trending Weaves & Search Terms
                </div>
                <div className="flex flex-wrap gap-2">
                  {POPULAR_SEARCH_TAGS.map((tag, i) => (
                    <button
                      key={i}
                      onClick={() => handleSelectTag(tag)}
                      className="px-3 py-1.5 rounded-md bg-[#11131E] hover:bg-[#D4AF37]/10 border border-[#262B3D] hover:border-[#D4AF37]/50 text-xs text-[#C8C3B6] hover:text-[#D4AF37] transition-all flex items-center gap-1.5"
                    >
                      <Tag className="w-3 h-3 text-[#D4AF37]/70" />
                      <span>{tag}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Signature Categories Bar */}
              <div>
                <div className="text-xs text-[#8C91A5] uppercase tracking-wider font-semibold mb-3 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#D4AF37]" />
                  Explore Haute Couture Categories
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {POPULAR_CATEGORIES.map(cat => (
                    <button
                      key={cat.value}
                      onClick={() => {
                        onSelectCategory(cat.value);
                        onClose();
                      }}
                      className="p-3 text-left rounded-lg bg-[#111420] hover:bg-[#181D2E] border border-[#24293C] hover:border-[#D4AF37]/60 group transition-all"
                    >
                      <div className="text-xs font-semibold text-[#FAF7F0] group-hover:text-[#D4AF37] flex items-center justify-between">
                        <span>{cat.label}</span>
                        <ArrowRight className="w-3 h-3 text-[#5A6076] group-hover:text-[#D4AF37] group-hover:translate-x-0.5 transition-all" />
                      </div>
                      <div className="text-[10px] text-[#7F8498] mt-0.5">Browse Category</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Collections Quick Discovery */}
              <div>
                <div className="text-xs text-[#8C91A5] uppercase tracking-wider font-semibold mb-3 flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-[#D4AF37]" />
                  Browse By Collection
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {matchedCollections.map(col => {
                    const Icon = ELEMENT_ICONS[col.id] || Sparkles;
                    return (
                      <button
                        key={col.id}
                        onClick={() => {
                          onSelectCollection(col.id);
                          onClose();
                        }}
                        className="p-3 text-left rounded-lg bg-[#111420] hover:bg-[#181D2E] border border-[#24293C] hover:border-[#D4AF37]/60 group transition-all flex items-start gap-2.5"
                      >
                        <div className="p-2 rounded-md bg-[#1D2235] text-[#D4AF37] group-hover:scale-110 transition-transform">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-semibold text-[#FAF7F0] group-hover:text-[#D4AF37] flex items-center gap-1">
                            <span className="truncate">{col.name.split(' (')[0]}</span>
                            <span className="font-telugu text-[10px] text-[#D4AF37]">{col.teluguName.split(' ')[0]}</span>
                          </div>
                          <div className="text-[10px] text-[#7F8498] truncate">{col.concept}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* 2. ZERO-RESULT STATE (Query entered with no matches) */}
          {isZeroState && (
            <div className="py-8 text-center space-y-6">
              <div className="w-14 h-14 mx-auto rounded-full bg-[#181B28] border border-[#30364C] flex items-center justify-center text-[#D4AF37]">
                <Search className="w-6 h-6 opacity-60" />
              </div>

              <div className="max-w-md mx-auto space-y-2">
                <h4 className="font-cinzel text-lg font-bold text-[#FAF7F0]">
                  No Products Found Matching &ldquo;{query}&rdquo;
                </h4>
                <p className="text-xs text-[#9095AB] leading-relaxed font-light">
                  We couldn&apos;t find any products matching your search. Explore our popular categories below or contact us directly.
                </p>
              </div>

              {/* Guide users back to popular categories */}
              <div className="max-w-xl mx-auto pt-2">
                <div className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
                  Browse Popular Categories
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  {POPULAR_CATEGORIES.map(cat => (
                    <button
                      key={cat.value}
                      onClick={() => {
                        onSelectCategory(cat.value);
                        onClose();
                      }}
                      className="px-3.5 py-1.5 rounded-full bg-[#131726] hover:bg-[#D4AF37] hover:text-black border border-[#2B3148] hover:border-[#D4AF37] text-xs font-medium text-[#FAF7F0] transition-all"
                    >
                      {cat.label}
                    </button>
                  ))}
                  <button
                    onClick={() => {
                      onSelectCollection('aaru');
                      onClose();
                    }}
                    className="px-3.5 py-1.5 rounded-full bg-[#20180D] hover:bg-[#D4AF37] hover:text-black border border-[#D4AF37]/60 text-xs font-medium text-[#D4AF37] transition-all"
                  >
                    The Sixth Element (ఆరు)
                  </button>
                </div>
              </div>

              {/* Commission Bespoke Action */}
              <div className="pt-4 border-t border-[#1C2030] flex flex-col sm:flex-row items-center justify-center gap-3">
                <a
                  href={`https://wa.me/918008006600?text=Hello%20AARU%20Atelier,%20I%20am%20searching%20for%20a%20bespoke%20creation%20matching%20"${encodeURIComponent(query)}"`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2 rounded-sm bg-emerald-600 hover:bg-emerald-500 text-black text-xs font-bold uppercase tracking-wider transition-colors inline-flex items-center gap-2"
                >
                  <span>Request Custom Loom Weave on WhatsApp</span>
                </a>
                <button
                  onClick={() => setQuery('')}
                  className="px-5 py-2 rounded-sm bg-[#151825] hover:bg-[#1E2336] text-[#FAF7F0] text-xs font-medium uppercase tracking-wider transition-colors border border-[#2A3046]"
                >
                  Clear Search & View All
                </button>
              </div>
            </div>
          )}

          {/* 3. MATCHED RESULTS (Products & Collections) */}
          {query.trim() && hasResults && !loading && (
            <div className="space-y-6">
              {/* Matched Collections (if activeTab is 'all' or 'collections') */}
              {(activeTab === 'all' || activeTab === 'collections') && matchedCollections.length > 0 && (
                <div>
                  <div className="text-xs text-[#8C91A5] uppercase tracking-wider font-semibold mb-3 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Compass className="w-3.5 h-3.5 text-[#D4AF37]" />
                      Matching Elemental Realms ({matchedCollections.length})
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {matchedCollections.map(col => {
                      const Icon = ELEMENT_ICONS[col.id] || Sparkles;
                      return (
                        <div
                          key={col.id}
                          onClick={() => {
                            saveRecentSearch(col.name);
                            onSelectCollection(col.id);
                            onClose();
                          }}
                          className="p-3.5 rounded-lg bg-[#111420] hover:bg-[#191F32] border border-[#23283B] hover:border-[#D4AF37]/60 cursor-pointer transition-all flex items-center justify-between group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-2.5 rounded-md bg-[#1C2133] text-[#D4AF37] group-hover:scale-105 transition-transform">
                              <Icon className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="text-sm font-semibold text-[#FAF7F0] group-hover:text-[#D4AF37] flex items-center gap-2">
                                <span>{col.name}</span>
                                <span className="font-telugu text-xs text-[#D4AF37]">{col.teluguName}</span>
                              </div>
                              <div className="text-xs text-[#7F859A]">{col.description}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-mono text-[#D4AF37] bg-[#1C2030] px-2 py-1 rounded">
                              {col.productCount} Weaves
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Matched Products (if activeTab is 'all' or 'products') */}
              {(activeTab === 'all' || activeTab === 'products') && matchedProducts.length > 0 && (
                <div>
                  <div className="text-xs text-[#8C91A5] uppercase tracking-wider font-semibold mb-3 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-[#D4AF37]" />
                      Masterpieces ({matchedProducts.length})
                    </span>
                    <span className="text-[11px] text-[#696E82]">Click silhouette to inspect</span>
                  </div>

                  <div className="divide-y divide-[#181C2B] bg-[#0E111C] border border-[#212638] rounded-lg overflow-hidden">
                    {matchedProducts.map(product => {
                      const formattedPrice = currency === 'INR'
                        ? `₹${product.price.toLocaleString('en-IN')}`
                        : `$${Math.round(product.price / 83).toLocaleString('en-US')}`;

                      return (
                        <div
                          key={product.id}
                          onClick={() => {
                            saveRecentSearch(product.name);
                            onSelectProduct(product);
                            onClose();
                          }}
                          className="p-3.5 sm:p-4 hover:bg-[#161B2B] cursor-pointer transition-all flex items-center justify-between gap-4 group"
                        >
                          <div className="flex items-center gap-3.5 min-w-0">
                            <img
                              src={product.images[0]}
                              alt={product.name}
                              referrerPolicy="no-referrer"
                              className="w-14 h-16 sm:w-16 sm:h-20 object-cover object-top rounded-md border border-[#292F44] group-hover:border-[#D4AF37] transition-colors flex-shrink-0"
                            />
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-[#1C2133] text-[#D4AF37] font-semibold border border-[#2B324A]">
                                  {product.category.toUpperCase()}
                                </span>
                                <span className="text-[10px] text-[#7A7F94] font-mono">
                                  {product.artisan.loomHours} Loom Hours
                                </span>
                              </div>
                              <h5 className="font-cinzel text-sm sm:text-base font-bold text-[#FAF7F0] group-hover:text-[#D4AF37] transition-colors truncate">
                                {product.name}
                              </h5>
                              <p className="text-xs text-[#8F94A8] line-clamp-1 font-light">
                                {product.subtitle}
                              </p>
                              <div className="text-[11px] text-[#C5A059] mt-0.5 flex items-center gap-2">
                                <span>{product.fabric}</span>
                                <span className="text-[#555A70]">·</span>
                                <span>{product.color}</span>
                              </div>
                            </div>
                          </div>

                          <div className="text-right flex-shrink-0">
                            <div className="text-sm sm:text-base font-mono font-bold text-[#FAF7F0]">
                              {formattedPrice}
                            </div>
                            <div className="text-[10px] mt-1 flex items-center justify-end gap-1">
                              {product.availability === 'in_stock' ? (
                                <span className="text-emerald-400 flex items-center gap-1 font-medium">
                                  <CheckCircle2 className="w-3 h-3" /> Ready to Ship
                                </span>
                              ) : (
                                <span className="text-[#C5A059] font-medium">Made to Order</span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Navigation Hints */}
        <div className="p-3.5 sm:p-4 bg-[#090B11] border-t border-[#191C28] flex items-center justify-between text-[11px] text-[#696E82] font-mono">
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline">Press ESC to dismiss</span>
            <span>Abstracted Search Engine v1.0</span>
          </div>
          <button
            onClick={() => {
              onSelectCategory('all');
              onClose();
            }}
            className="text-[#D4AF37] hover:underline flex items-center gap-1 font-sans text-xs"
          >
            <span>Explore Full Catalogue</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
