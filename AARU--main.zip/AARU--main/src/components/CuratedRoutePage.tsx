import React, { useState, useEffect } from 'react';
import {
  PackageCheck,
  Truck,
  ShieldCheck,
  Clock,
  Filter,
  SlidersHorizontal,
  Eye,
  ShoppingBag,
  Heart,
  Check,
  ChevronRight,
  Sparkles,
  RotateCcw,
  ArrowRight
} from 'lucide-react';
import { Product } from '../types';
import { api } from '../services/api';

interface CuratedRoutePageProps {
  mode: 'ready-to-ship' | 'sarees-ready-to-ship';
  onSwitchMode: (mode: 'ready-to-ship' | 'sarees-ready-to-ship') => void;
  onSelectProduct: (product: Product) => void;
  onQuickViewProduct: (product: Product) => void;
  onAddToCart: (product: Product, size?: string) => void;
  currency: 'INR' | 'USD';
  formatPrice: (price: number) => string;
  wishlist: string[];
  onToggleWishlist: (productId: string) => void;
  onNavigateHome?: () => void;
  onNavigateCatalogue?: () => void;
}

export const CuratedRoutePage: React.FC<CuratedRoutePageProps> = ({
  mode,
  onSwitchMode,
  onSelectProduct,
  onQuickViewProduct,
  onAddToCart,
  currency,
  formatPrice,
  wishlist,
  onToggleWishlist,
  onNavigateHome,
  onNavigateCatalogue
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [meta, setMeta] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Sub-filter states
  const [selectedFabric, setSelectedFabric] = useState<string>('all');
  const [selectedColor, setSelectedColor] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'hours-desc'>('featured');
  const [quickAddedId, setQuickAddedId] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    const fetchData = async () => {
      if (mode === 'sarees-ready-to-ship') {
        const res = await api.getSareesReadyToShip({ sort: sortBy });
        if (isMounted) {
          setProducts(res.data);
          setMeta(res.meta);
          setLoading(false);
        }
      } else {
        const res = await api.getReadyToShip({ sort: sortBy });
        if (isMounted) {
          setProducts(res.data);
          setMeta(res.meta);
          setLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [mode, sortBy]);

  // Derived filtered items
  const filteredProducts = products.filter(p => {
    if (selectedFabric !== 'all' && !p.fabric.toLowerCase().includes(selectedFabric.toLowerCase())) {
      return false;
    }
    if (selectedColor !== 'all' && !p.color.toLowerCase().includes(selectedColor.toLowerCase())) {
      return false;
    }
    return true;
  });

  const availableFabrics = Array.from(new Set(products.map(p => p.fabric)));
  const availableColors = Array.from(new Set(products.map(p => p.color.split(' ')[0])));

  const handleQuickAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, product.sizes[0] || 'Free Size');
    setQuickAddedId(product.id);
    setTimeout(() => {
      setQuickAddedId(null);
    }, 2000);
  };

  const isSareeMode = mode === 'sarees-ready-to-ship';

  return (
    <div className="min-h-screen bg-[#07080B] text-[#FAF7F0] pb-24">
      {/* 1. Header Banner & URL Badge */}
      <section className="relative pt-12 pb-14 bg-gradient-to-b from-[#11141F] via-[#0D0F17] to-[#07080B] border-b border-[#1E2333] overflow-hidden">
        {/* Subtle Background Glow */}
        <div className="absolute top-0 right-1/4 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-10 left-1/4 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Breadcrumb & URL Pill */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-2 text-xs text-[#7E8294]">
              <button onClick={onNavigateHome} className="hover:text-[#D4AF37] transition-colors">
                Atelier Home
              </button>
              <span>/</span>
              <span className="text-[#A09A8E]">Curated Dispatch</span>
              <span>/</span>
              <span className="text-[#FAF7F0] font-semibold">
                {isSareeMode ? 'Sarees – Ready to Ship' : 'Ready to Ship'}
              </span>
            </div>

            {/* Direct URL Indicator Badge */}
            <div className="flex items-center gap-2 bg-[#121520] border border-emerald-500/40 px-3.5 py-1.5 rounded-full text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-emerald-400 text-[11px] font-medium">
                {isSareeMode ? '/sarees-ready-to-ship' : '/ready-to-ship'}
              </span>
              <span className="text-[#4E546B]">|</span>
              <span className="text-[#A09A8E] text-[10px] uppercase tracking-wider font-semibold">
                LIVE VAULT SYNC
              </span>
            </div>
          </div>

          {/* Curated Route Title */}
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-telugu text-base text-[#D4AF37]">
                {meta?.teluguTitle || (isSareeMode ? 'తక్షణ పట్టు చీరలు' : 'తక్షణ లభ్యత')}
              </span>
              <span className="text-[#3A4056]">•</span>
              <span className="text-[10px] uppercase tracking-[0.24em] text-emerald-400 font-bold">
                GUARANTEED 24-HOUR WHITE-GLOVE DISPATCH
              </span>
            </div>

            <h1 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#FAF7F0]">
              {meta?.title || (isSareeMode ? 'Sarees – Ready to Ship' : 'Ready to Ship Creations')}
            </h1>

            <p className="mt-3 text-sm sm:text-base text-[#A09A8E] font-sans leading-relaxed">
              {meta?.description ||
                'Silhouettes that have achieved complete loom weaving, hallmark certifications, and final archival inspection. Preserved in climate-controlled velvet vaults for immediate dispatch.'}
            </p>
          </div>

          {/* Value Assurance Cards Bar */}
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#0F121A]/80 border border-[#202538] rounded-xl p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-950/60 border border-emerald-800/40 text-emerald-400">
                <Truck className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-[#FAF7F0] block">24h Courier Handover</span>
                <span className="text-[10px] text-[#7E8294]">Complimentary white-glove transit</span>
              </div>
            </div>

            <div className="bg-[#0F121A]/80 border border-[#202538] rounded-xl p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#181C29] border border-[#2B3248] text-[#D4AF37]">
                <PackageCheck className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-[#FAF7F0] block">Teakwood Presentation Box</span>
                <span className="text-[10px] text-[#7E8294]">Velvet-lined heirloom packaging</span>
              </div>
            </div>

            <div className="bg-[#0F121A]/80 border border-[#202538] rounded-xl p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#181C29] border border-[#2B3248] text-[#D4AF37]">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-[#FAF7F0] block">24K Zari Hallmark</span>
                <span className="text-[10px] text-[#7E8294]">Silk Mark &amp; bullion guarantee</span>
              </div>
            </div>

            <div className="bg-[#0F121A]/80 border border-[#202538] rounded-xl p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#181C29] border border-[#2B3248] text-[#D4AF37]">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-[#FAF7F0] block">Zero Loom Wait Time</span>
                <span className="text-[10px] text-[#7E8294]">In-stock physical inventory</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Route Switching Navigation Tabs */}
      <div className="bg-[#0B0D14] border-b border-[#1A1E2C] sticky top-20 z-20 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
          {/* Mode Switcher Tabs */}
          <div className="flex items-center gap-3">
            <button
              id="route-tab-all"
              onClick={() => onSwitchMode('ready-to-ship')}
              className={`px-4 py-2 rounded-full text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 border ${
                !isSareeMode
                  ? 'bg-emerald-600 text-white border-emerald-500 font-semibold shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                  : 'bg-[#121520] text-[#A09A8E] border-[#222738] hover:text-[#FAF7F0]'
              }`}
            >
              <PackageCheck className="w-3.5 h-3.5" />
              <span>All Ready to Ship ({mode === 'ready-to-ship' ? products.length : 'All'})</span>
            </button>

            <button
              id="route-tab-sarees"
              onClick={() => onSwitchMode('sarees-ready-to-ship')}
              className={`px-4 py-2 rounded-full text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 border ${
                isSareeMode
                  ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-semibold shadow-[0_0_12px_rgba(212,175,55,0.3)]'
                  : 'bg-[#121520] text-[#A09A8E] border-[#222738] hover:text-[#FAF7F0]'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sarees – Ready to Ship ({isSareeMode ? products.length : 'Drapes'})</span>
            </button>
          </div>

          {/* Right: Sub-Filter Controls */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Fabric Picker */}
            {availableFabrics.length > 1 && (
              <div className="flex items-center gap-1.5 bg-[#121520] border border-[#23283B] px-3 py-1.5 rounded-lg text-xs">
                <span className="text-[#7E8294]">Fabric:</span>
                <select
                  id="route-fabric-select"
                  value={selectedFabric}
                  onChange={e => setSelectedFabric(e.target.value)}
                  className="bg-transparent text-[#FAF7F0] focus:outline-none cursor-pointer"
                >
                  <option value="all" className="bg-[#121520]">All Weaves</option>
                  {availableFabrics.map(fab => (
                    <option key={fab} value={fab} className="bg-[#121520]">{fab}</option>
                  ))}
                </select>
              </div>
            )}

            {/* Color Filter */}
            {availableColors.length > 1 && (
              <div className="flex items-center gap-1.5 bg-[#121520] border border-[#23283B] px-3 py-1.5 rounded-lg text-xs">
                <span className="text-[#7E8294]">Color:</span>
                <select
                  id="route-color-select"
                  value={selectedColor}
                  onChange={e => setSelectedColor(e.target.value)}
                  className="bg-transparent text-[#FAF7F0] focus:outline-none cursor-pointer"
                >
                  <option value="all" className="bg-[#121520]">All Tones</option>
                  {availableColors.map(c => (
                    <option key={c} value={c} className="bg-[#121520]">{c}</option>
                  ))}
                </select>
              </div>
            )}

            {/* Sort Picker */}
            <div className="flex items-center gap-1.5 bg-[#121520] border border-[#23283B] px-3 py-1.5 rounded-lg text-xs">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#D4AF37]" />
              <select
                id="route-sort-select"
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="bg-transparent text-[#FAF7F0] focus:outline-none cursor-pointer"
              >
                <option value="featured" className="bg-[#121520]">Curated Order</option>
                <option value="price-asc" className="bg-[#121520]">Price: Low to High</option>
                <option value="price-desc" className="bg-[#121520]">Price: High to Low</option>
                <option value="hours-desc" className="bg-[#121520]">Loom Dedication</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Product Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        <div className="flex items-center justify-between mb-6">
          <div className="text-xs text-[#A09A8E]">
            Showing <span className="font-mono text-[#FAF7F0] font-bold">{filteredProducts.length}</span> verified vault creations
          </div>
          {(selectedFabric !== 'all' || selectedColor !== 'all') && (
            <button
              onClick={() => {
                setSelectedFabric('all');
                setSelectedColor('all');
              }}
              className="text-xs text-[#D4AF37] hover:underline flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Sub-Filters</span>
            </button>
          )}
        </div>

        {loading ? (
          <div className="py-24 text-center text-[#A09A8E]">
            <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs uppercase tracking-widest">Loading available products...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="py-20 text-center bg-[#0E1119] rounded-2xl border border-[#202538] p-8 max-w-md mx-auto">
            <PackageCheck className="w-12 h-12 text-[#D4AF37] mx-auto mb-3" />
            <h3 className="font-cinzel text-xl font-bold text-[#FAF7F0] mb-2">No Products Found</h3>
            <p className="text-xs text-[#A09A8E] mb-6 font-sans">
              No products match the selected filters. Try clearing filters to view available items.
            </p>
            <button
              onClick={() => {
                setSelectedFabric('all');
                setSelectedColor('all');
              }}
              className="px-5 py-2.5 rounded-lg bg-[#D4AF37] text-black text-xs font-bold uppercase tracking-wider"
            >
              Clear Sub-Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6 sm:gap-8">
            {filteredProducts.map(product => {
              const isWishlisted = wishlist.includes(product.id);
              const isQuickAdded = quickAddedId === product.id;

              return (
                <div
                  key={product.id}
                  id={`curated-product-${product.id}`}
                  onClick={() => onSelectProduct(product)}
                  className="group bg-[#0E1119] rounded-2xl overflow-hidden border border-[#1E2333] hover:border-emerald-500/70 transition-all duration-500 flex flex-col cursor-pointer shadow-lg hover:shadow-[0_12px_36px_rgba(0,0,0,0.7)]"
                >
                  {/* Image Presentation */}
                  <div className="relative aspect-[3/4] overflow-hidden bg-[#151824]">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                    />
                    {product.images[1] && (
                      <img
                        src={product.images[1]}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                      />
                    )}

                    {/* Green Ready to Ship Vault Badge */}
                    <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 bg-[#090A0E]/90 backdrop-blur-md border border-emerald-500/60 px-3 py-1.5 rounded-full shadow-lg">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-[10px] uppercase tracking-wider text-emerald-300 font-bold">
                        Ready to Ship • 24h Dispatch
                      </span>
                    </div>

                    {/* Wishlist Button */}
                    <div className="absolute top-3 right-3 z-10">
                      <button
                        id={`wishlist-curated-${product.id}`}
                        onClick={e => {
                          e.stopPropagation();
                          onToggleWishlist(product.id);
                        }}
                        aria-label="Save to wishlist"
                        className="p-2 rounded-full bg-black/60 hover:bg-black/90 text-[#FAF7F0] border border-white/10 hover:border-[#D4AF37] transition-all backdrop-blur-sm"
                      >
                        <Heart
                          className={`w-3.5 h-3.5 ${
                            isWishlisted ? 'fill-red-500 text-red-500' : 'text-[#FAF7F0]'
                          }`}
                        />
                      </button>
                    </div>

                    {/* Quick Action Floating Controls */}
                    <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex gap-2 z-10">
                      <button
                        id={`curated-quickview-${product.id}`}
                        onClick={e => {
                          e.stopPropagation();
                          onQuickViewProduct(product);
                        }}
                        className="flex-1 py-2 rounded-xl bg-[#090A0E]/90 hover:bg-black text-[#FAF7F0] border border-white/20 text-[11px] font-medium tracking-wider uppercase backdrop-blur-md flex items-center justify-center gap-1.5 transition-all"
                      >
                        <Eye className="w-3.5 h-3.5 text-[#D4AF37]" />
                        <span>Quick View</span>
                      </button>

                      <button
                        id={`curated-quickadd-${product.id}`}
                        onClick={e => handleQuickAdd(product, e)}
                        className={`px-4 py-2 rounded-xl text-[11px] font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-1.5 shadow-md ${
                          isQuickAdded
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[#D4AF37] hover:bg-[#E5C158] text-black'
                        }`}
                        title="Add to Bag Immediately"
                      >
                        {isQuickAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Quick Add</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[10px] text-[#7E8294] uppercase tracking-wider mb-1">
                        <span>{product.fabric}</span>
                        <span className="font-mono text-emerald-400">Ready to Ship</span>
                      </div>

                      <h4 className="font-cinzel text-base font-bold text-[#FAF7F0] group-hover:text-[#D4AF37] transition-colors line-clamp-1">
                        {product.name}
                      </h4>

                      <p className="text-xs text-[#A09A8E] mt-1 line-clamp-2 font-sans">
                        {product.subtitle}
                      </p>

                      {/* Origin & Loom Hours */}
                      <div className="mt-3 flex items-center gap-2 text-[11px] text-[#8C90A4]">
                        <span>Origin: {product.weaveOrigin.split(',')[0]}</span>
                        <span>•</span>
                        <span>{product.artisan.loomHours}h loom</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#1C2030] flex items-center justify-between">
                      <div>
                        <span className="font-mono text-base font-bold text-[#FAF7F0]">
                          {formatPrice(product.price)}
                        </span>
                        {product.originalPrice && (
                          <span className="ml-2 font-mono text-xs text-[#62677C] line-through">
                            {formatPrice(product.originalPrice)}
                          </span>
                        )}
                      </div>

                      <span className="text-xs text-[#D4AF37] group-hover:translate-x-1 transition-transform flex items-center gap-1 font-medium">
                        <span>Acquire Drape</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Bottom Switcher Banner to Complete Catalogue */}
        <div className="mt-16 bg-[#0E1119] rounded-2xl p-8 border border-[#1E2333] text-center max-w-3xl mx-auto">
          <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-2">
            CANNOT FIND YOUR EXACT ELEMENT OR WEAVE?
          </p>
          <h3 className="font-cinzel text-2xl font-bold text-[#FAF7F0] mb-3">
            Browse Our Made-To-Order Haute Couture Collection
          </h3>
          <p className="text-xs sm:text-sm text-[#A09A8E] max-w-xl mx-auto mb-6">
            Patrons can commission bespoke creations woven from raw mulberry silk warp threads with personalized monogramming and custom loom lengths.
          </p>
          <button
            id="curated-explore-all-btn"
            onClick={() => onNavigateCatalogue && onNavigateCatalogue()}
            className="px-6 py-3 rounded-full bg-[#D4AF37] hover:bg-[#E5C158] text-black text-xs font-bold tracking-[0.16em] uppercase transition-all shadow-lg inline-flex items-center gap-2"
          >
            <span>Explore Full Atelier Catalogue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
