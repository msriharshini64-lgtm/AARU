export type ElementType = 'earth' | 'water' | 'fire' | 'air' | 'ether' | 'aaru';

export type ProductAvailability = 'in_stock' | 'made_to_order';

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  price: number;
  originalPrice?: number;
  element: ElementType;
  category: 'saree' | 'sherwani' | 'lehenga' | 'cape-gown' | 'kurta' | 'stole';
  description: string;
  editorialNote: string;
  fabric: string;
  weaveOrigin: string;
  color: string;
  colorHex?: string;
  occasion: string[];
  sizes: string[];
  inStock: boolean;
  availability: ProductAvailability;
  featured?: boolean;
  artisan: {
    name: string;
    region: string;
    experienceYears: number;
    loomHours: number;
  };
  images: string[];
  sustainableCertificate: string;
  details: string[];
  careInstructions: string[];
}

export interface CatalogueFilterState {
  category: string;
  collection: string;
  priceRange: [number, number];
  colors: string[];
  fabrics: string[];
  sizes: string[];
  occasions: string[];
  availability: 'all' | 'in_stock' | 'made_to_order';
  sort: 'featured' | 'price-asc' | 'price-desc' | 'hours-desc' | 'newest';
}

export interface SearchFacetOption {
  label: string;
  value: string;
  count: number;
  hex?: string;
}

export interface SearchFacets {
  categories: SearchFacetOption[];
  collections: SearchFacetOption[];
  priceRange: { min: number; max: number };
  colors: SearchFacetOption[];
  fabrics: SearchFacetOption[];
  sizes: SearchFacetOption[];
  occasions: SearchFacetOption[];
  availabilities: SearchFacetOption[];
}

export interface SearchResponse {
  products: Product[];
  collections: Array<{
    id: string;
    name: string;
    teluguName: string;
    concept: string;
    description: string;
    productCount: number;
  }>;
  total: number;
  facets: SearchFacets;
  suggestions: {
    popularCategories: string[];
    trendingSearches: string[];
    featuredCollections: Array<{ id: string; name: string }>;
  };
}

export interface EditorialStory {
  id: string;
  title: string;
  teluguTitle?: string;
  subtitle: string;
  readTime: string;
  chapter: string;
  quote: string;
  author: string;
  content: string[];
  image: string;
  featuredProducts?: string[];
  themeColor: string;
}

export interface CartItem {
  product: Product;
  size: string;
  quantity: number;
  customMeasurements?: {
    bustChest?: string;
    waist?: string;
    hips?: string;
    height?: string;
    shoulder?: string;
  };
  monogram?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  price: number;
  quantity: number;
  size: string;
  monogram?: string;
  customMeasurements?: Record<string, string>;
}

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  items: OrderItem[];
  total: number;
  status: 'Artisan Allocated' | 'Loom Weaving' | 'Bespoke Tailoring' | 'Quality Archival' | 'White Glove Dispatch' | 'Delivered';
  estimatedDelivery: string;
  shippingAddress: {
    fullName: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    postalCode: string;
    country: string;
  };
  giftPackaging: boolean;
  trackingMilestones: {
    title: string;
    description: string;
    date: string;
    completed: boolean;
  }[];
}

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  memberTier: 'Atelier Patron' | 'Elemental Circle' | 'First Loom Circle';
  elementAffinity: ElementType;
  measurements: {
    bustChest: string;
    waist: string;
    hips: string;
    shoulder: string;
    height: string;
    sleeveLength: string;
  };
  wishlist: string[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'recommendation' | 'atelier' | 'system';
  timestamp: string;
  read: boolean;
  actionUrl?: string;
  imageUrl?: string;
  metadata?: {
    orderId?: string;
    productId?: string;
  };
}

export interface ConsultationRequest {
  id: string;
  clientName: string;
  email: string;
  phone: string;
  preferredChannel: 'whatsapp' | 'video_call' | 'in_atelier';
  preferredDate: string;
  coutureInterest: string;
  measurementsNotes?: string;
  budgetRange?: string;
  status: 'pending' | 'confirmed' | 'completed';
}

export interface CollectionCraftHeritage {
  loomTechnique: string;
  zariStandard: string;
  originGuild: string;
  avgLoomHours: number;
  textileCertification: string;
  primaryFabric: string;
}

export interface EditorialCollection {
  id: string;
  title: string;
  teluguTitle: string;
  concept: string;
  subtitle: string;
  element: ElementType | 'capsule';
  heroImage: string;
  secondaryImage?: string;
  moodQuote: string;
  quoteAuthor: string;
  philosophyStory: string[];
  craftHeritage: CollectionCraftHeritage;
  accentColor: string;
  palette: string[];
  productCount?: number;
  featuredProductIds?: string[];
}

export interface ShopTheLookHotspot {
  x: number; // percentage from left (0 to 100)
  y: number; // percentage from top (0 to 100)
  label: string;
  role: string; // e.g. "Primary Saree", "Gilded Stole", "Bespoke Blouse"
}

export interface ShopTheLookPiece {
  productId: string;
  product: Product;
  hotspot: ShopTheLookHotspot;
  stylingTip: string;
}

export interface ShopTheLookEnsemble {
  id: string;
  title: string;
  teluguTitle?: string;
  subtitle: string;
  element: ElementType;
  occasion: string;
  heroLifestyleImage: string;
  secondaryEditorialImage?: string;
  story: string;
  curator: {
    name: string;
    role: string;
  };
  pieces: ShopTheLookPiece[];
  bundleSavingsNote?: string;
}

export interface AuthSession {
  token: string;
  user: UserProfile;
}

export interface SendOtpResult {
  success: boolean;
  message: string;
  mockMode?: boolean;
  testOtp?: string;
  status?: string;
}

export interface VerifyOtpResult {
  success: boolean;
  user: UserProfile;
  token: string;
  message: string;
}

export interface AuthStatusResult {
  success: boolean;
  hasTwilioConfigured: boolean;
  message: string;
}

