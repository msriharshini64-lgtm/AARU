// Web Audio API generator for subtle artisanal loom soundscape
let audioCtx: AudioContext | null = null;
let isPlaying = false;
let intervalId: any = null;

export const loomAudio = {
  toggle() {
    if (isPlaying) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  },

  start() {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      if (!audioCtx) {
        audioCtx = new AudioContextClass();
      }
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }

      isPlaying = true;
      // Gentle rhythmic wooden shuttle click every 1.8s
      intervalId = setInterval(() => {
        if (!isPlaying || !audioCtx) return;
        this.playShuttleClick();
      }, 1800);
      this.playShuttleClick();
    } catch {
      // Audio autoplay might be restricted
      isPlaying = false;
    }
  },

  stop() {
    isPlaying = false;
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
  },

  playShuttleClick() {
    if (!audioCtx) return;
    const now = audioCtx.currentTime;

    // Soft resonant wooden tap (shuttle glide)
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(70, now + 0.12);

    gain.gain.setValueAtTime(0.04, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start(now);
    osc.stop(now + 0.13);

    // Followed by subtle silk rustle whisper
    setTimeout(() => {
      if (!audioCtx || !isPlaying) return;
      const t = audioCtx.currentTime;
      const bufferSize = audioCtx.sampleRate * 0.1;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * 0.015;
      }
      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;
      const filter = audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 800;

      const noiseGain = audioCtx.createGain();
      noiseGain.gain.setValueAtTime(0.02, t);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);

      noise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(audioCtx.destination);
      noise.start(t);
      noise.stop(t + 0.1);
    }, 240);
  },

  getStatus() {
    return isPlaying;
  }
};
