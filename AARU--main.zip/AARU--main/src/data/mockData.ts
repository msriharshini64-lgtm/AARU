import { Product, EditorialStory, Order, UserProfile, NotificationItem, EditorialCollection, ShopTheLookEnsemble } from '../types';

export const ELEMENT_METADATA: Record<string, {
  name: string;
  teluguName: string;
  concept: string;
  color: string;
  accent: string;
  description: string;
}> = {
  all: {
    name: 'All Creations',
    teluguName: 'సమస్తం',
    concept: 'The Omnipresent Wardrobe',
    color: '#D4AF37',
    accent: 'border-[#D4AF37]',
    description: 'The complete couture treasury traversing all elemental realms.'
  },
  earth: {
    name: 'Prithvi (Earth)',
    teluguName: 'పృథ్వి',
    concept: 'Terra, Bark & Ochre Silks',
    color: '#C5A059',
    accent: 'border-[#C5A059]',
    description: 'Grounded in raw tussar silks, organic madder dyes, and heavy hand-spun zari borders rooted in ancient earth.'
  },
  water: {
    name: 'Jala (Water)',
    teluguName: 'జలం',
    concept: 'Fluidity & Serpentine Drapes',
    color: '#3B82F6',
    accent: 'border-[#3B82F6]',
    description: 'Cascading georgettes, oceanic teal brocades, and liquid metallic lamé echoing the deep sacred currents.'
  },
  fire: {
    name: 'Agni (Fire)',
    teluguName: 'అగ్ని',
    concept: 'Molten Zari & Crimson Flames',
    color: '#EF4444',
    accent: 'border-[#EF4444]',
    description: 'Blazing vermilion silks, hand-beaten gold bullion embroideries, and iridescent rubies captured in pure thread.'
  },
  air: {
    name: 'Vayu (Air)',
    teluguName: 'వాయువు',
    concept: 'Weightless Organza & Sheer Whisper',
    color: '#10B981',
    accent: 'border-[#10B981]',
    description: 'Feather-light Chanderi muslins, whisper-thin tissues, and translucent capes that float upon the mountain breeze.'
  },
  ether: {
    name: 'Akasha (Ether)',
    teluguName: 'ఆకాశం',
    concept: 'Cosmic Starlight & Midnight Indigo',
    color: '#8B5CF6',
    accent: 'border-[#8B5CF6]',
    description: 'Deep velvet abyss, astral zardozi work, and celestial obsidian silhouettes reaching for the infinite cosmos.'
  },
  aaru: {
    name: 'The Sixth Element (ఆరు)',
    teluguName: 'ఆరు - ఆరవ తత్వం',
    concept: 'The Living Weaver’s Soul',
    color: '#E5C07B',
    accent: 'border-[#E5C07B]',
    description: 'The sacred sixth dimension: Human consciousness, artisan breath, and devotion transforming yarn into immortal art.'
  }
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'aaru-01',
    name: 'The Sovereign Āru Kanjeevaram Saree',
    subtitle: 'The Sixth Element Masterpiece in Molten 24k Gold Zari & Midnight Obsidian',
    price: 185000,
    originalPrice: 210000,
    element: 'aaru',
    category: 'saree',
    color: 'Molten Gold',
    colorHex: '#D4AF37',
    occasion: ['Bridal / Wedding', 'Royal Reception', 'Temple Heritage'],
    availability: 'in_stock',
    description: 'An architectural tribute to the sacred number Six. Woven across 380 hours on an heirloom jacquard loom in Kanchipuram, this silhouette features authentic 24-karat silver-gilt zari depicting the geometry of the cosmic cosmos, with our signature Telugu "ఆరు" emblem micro-woven into the pallu corner.',
    editorialNote: 'Conceived as the definitive representation of the Sixth Element: human intent breathing spirit into raw warp and weft.',
    fabric: 'Mulberry Kanchipuram Silk',
    weaveOrigin: 'Kanchipuram Heritage Guild, Tamil Nadu',
    artisan: {
      name: 'Padma Shri V. Ramanujam & Sons',
      region: 'Kanchipuram',
      experienceYears: 42,
      loomHours: 380
    },
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size', 'Custom Made-to-Measure'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Silk Mark India & Handloom Board Certified No. IN-77291',
    details: [
      'Pure 4-ply hand-reeled mulberry silk warp and weft',
      'Tested real silver wire core electroplated with 24k gold (Passes purity burn test)',
      'Handcrafted Korvai interlocking temple border technique',
      'Includes unstitched bespoke blouse fabric with gilded bullion work',
      'Comes with handcrafted teakwood preservation box with brass monogramming'
    ],
    careInstructions: [
      'Strict dry clean only by luxury textile specialists',
      'Store wrapped in breathable pure mulmul cotton muslin',
      'Air out in indirect shade every six months; do not spray fragrance directly on zari'
    ]
  },
  {
    id: 'aaru-02',
    name: 'Akasha Celestial Midnight Velvet Cape-Gown',
    subtitle: 'Astral Constellation Zardozi on Deep Cosmic Indigo',
    price: 145000,
    element: 'ether',
    category: 'cape-gown',
    color: 'Obsidian Black',
    colorHex: '#12131A',
    occasion: ['Gala & Red Carpet', 'Royal Reception'],
    availability: 'in_stock',
    description: 'Crafted from plush mulberry silk velvet dyed in natural midnight indigo, this regal cape-gown is hand-embroidered with astral maps using semi-precious lapis lazuli beads, micro-pearls, and antique dabka wire.',
    editorialNote: 'Inspired by the quiet eternity of the night sky over the Deccan plateau.',
    fabric: 'Pure Silk Velvet',
    weaveOrigin: 'Atelier Hyderabad & Banaras',
    artisan: {
      name: 'Master Zardooz Mohammad Irfan',
      region: 'Old City, Hyderabad',
      experienceYears: 35,
      loomHours: 240
    },
    images: [
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom Made-to-Measure'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Artisanal Craft Heritage Registry #HYD-9904',
    details: [
      'Sculpted internal corsetry with flexible bone framing',
      'Trailing cape with celestial gold starburst embroideries',
      'Hand-attached freshwater seed pearls along cuffs',
      'Concealed artisanal zip and hook closures'
    ],
    careInstructions: [
      'Specialist steam and dry clean only',
      'Hang on padded cedar hanger in garment bag provided'
    ]
  },
  {
    id: 'aaru-03',
    name: 'Agni Molten Scarlet Banarasi Bridal Lehenga',
    subtitle: 'Woven Fire: 108 Panels of Kadwa Zari Brocade',
    price: 240000,
    originalPrice: 265000,
    element: 'fire',
    category: 'lehenga',
    color: 'Crimson Red',
    colorHex: '#A31D1D',
    occasion: ['Bridal / Wedding', 'Sangeet & Festive'],
    availability: 'made_to_order',
    description: 'An ode to Agni, the cosmic flame of transformation and divine passion. Featuring 16 meters of pure katan silk flare, woven with the painstaking Kadwa technique where each floral motif is individually locked by hand shuttle.',
    editorialNote: 'A ceremonial masterpiece destined to be treasured across three generations.',
    fabric: 'Banarasi Katan Silk',
    weaveOrigin: 'Varanasi Weaver Colony, Uttar Pradesh',
    artisan: {
      name: 'Ustad Tariq Ansari',
      region: 'Banaras',
      experienceYears: 38,
      loomHours: 510
    },
    images: [
      'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1566737236500-c8ac43014a67?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['S', 'M', 'L', 'Custom Made-to-Measure'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Geographical Indication (GI) Certified Banaras Brocade',
    details: [
      '16-meter circular flare with layered can-can reinforcement',
      'Matching heavily embellished blouse with jewel neckline',
      'Dual dupattas: One in rich Kadwa silk, one in whisper-light organza',
      'Handmade gilded latkans with semi-precious carnelian stones'
    ],
    careInstructions: [
      'Professional heritage dry clean only',
      'Refold along opposite creases annually to prevent zari pressure'
    ]
  },
  {
    id: 'aaru-04',
    name: 'Jala Oceanic Waves Uppada Jamdani Saree',
    subtitle: 'Liquid Turquoise with Floating Silver Ripple Weft',
    price: 118000,
    element: 'water',
    category: 'saree',
    color: 'Ocean Turquoise',
    colorHex: '#1D7A8C',
    occasion: ['Royal Reception', 'Sangeet & Festive', 'Temple Heritage'],
    availability: 'in_stock',
    description: 'From the coastal looms of Uppada, Andhra Pradesh. The Jamdani technique allows motifs to appear as though floating upon sheer running water. The deep sea turquoise gradation flows effortlessly across six yards.',
    editorialNote: 'Capturing the tranquil rhythm of the Bay of Bengal meeting Andhra weaving traditions.',
    fabric: 'Uppada Cotton-Silk',
    weaveOrigin: 'Uppada Coast, Andhra Pradesh',
    artisan: {
      name: 'Narayana Swamy & Daughters',
      region: 'Uppada, Kakinada',
      experienceYears: 29,
      loomHours: 210
    },
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size'],
    inStock: true,
    featured: false,
    sustainableCertificate: 'Uppada Jamdani GI Tag Registered #AP-1082',
    details: [
      'Weft-inlay Jamdani motifs without rough back floats',
      'Feather-light weight under 420 grams',
      'Includes raw silk contrasting navy blouse piece',
      'Signed certificate of loom origin by master weaver'
    ],
    careInstructions: [
      'Gentle dry clean only',
      'Do not wring or tumble dry; steam iron on low'
    ]
  },
  {
    id: 'aaru-05',
    name: 'Vayu Whisper Sheer Chanderi Kurta & Cape Set',
    subtitle: 'Air-Woven Sage Green with Silver Mukaish Dusting',
    price: 78000,
    element: 'air',
    category: 'kurta',
    color: 'Emerald Sage',
    colorHex: '#3D7A68',
    occasion: ['Sangeet & Festive', 'Gala & Red Carpet'],
    availability: 'in_stock',
    description: 'Imbued with the lightness of atmospheric currents. Handwoven in Chanderi using 300-count cotton and mulberry silk, sprinkled with shimmering silver Mukaish needlework that twinkles like morning dew.',
    editorialNote: 'Designed for effortless contemporary poise, moving with the gentlest ambient breeze.',
    fabric: 'Chanderi Tissue Silk',
    weaveOrigin: 'Chanderi, Madhya Pradesh',
    artisan: {
      name: 'Devi Lal Kushwaha',
      region: 'Chanderi',
      experienceYears: 24,
      loomHours: 130
    },
    images: [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    inStock: true,
    featured: false,
    sustainableCertificate: 'Handloom Mark Registered No. MP-4418',
    details: [
      'Tailored asymmetric hemline with layered palazzo pants',
      'Real silver Mukaish embellishment pressed by hand stone',
      'Tonal silk slip lining included',
      'Mother-of-pearl buttons along hidden placket'
    ],
    careInstructions: [
      'Dry clean only',
      'Iron inside out with protective muslin cloth'
    ]
  },
  {
    id: 'aaru-06',
    name: 'Prithvi Saffron Pochampally Ikat Silk Sherwani',
    subtitle: 'Earthy Geometric Math: Double Ikat in Terracotta & Raw Gold',
    price: 135000,
    element: 'earth',
    category: 'sherwani',
    color: 'Terracotta Ochre',
    colorHex: '#A85A32',
    occasion: ['Bridal / Wedding', 'Royal Reception'],
    availability: 'made_to_order',
    description: 'From Telangana’s revered Pochampally cluster, this structured royal sherwani showcases mathematical double-Ikat resist dyeing. Earthy madder terracotta and raw gold threads create an austere, regal masculine silhouette.',
    editorialNote: 'A testament to the geometry of Telangana heritage, celebrating timeless imperial dignity.',
    fabric: 'Double-Ikat Pochampally Silk',
    weaveOrigin: 'Bhoodan Pochampally, Telangana',
    artisan: {
      name: 'Chinta Mallesham & Guild',
      region: 'Yadadri Bhuvanagiri, Telangana',
      experienceYears: 31,
      loomHours: 290
    },
    images: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['S', 'M', 'L', 'XL', 'Custom Made-to-Measure'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Pochampally Ikat GI Tagged #TS-5002',
    details: [
      'Precision matched symmetrical double-ikat patterns across seams',
      'Tailored equestrian cut with high Mandarin collar',
      'Enamelled gold cufflinks with miniature Telugu monogram',
      'Accompanied by pure raw silk ivory churidar'
    ],
    careInstructions: [
      'Specialist dry clean only',
      'Store on wide shoulder contoured coat hanger'
    ]
  },
  {
    id: 'aaru-07',
    name: 'The Āru Genesis Pashmina & Zari Stole',
    subtitle: 'Hand-Spun Ladakhi Cashmere with Kanchipuram Gold Borders',
    price: 64000,
    element: 'aaru',
    category: 'stole',
    color: 'Ivory Pearl',
    colorHex: '#EDE8DF',
    occasion: ['Gala & Red Carpet', 'Royal Reception', 'Temple Heritage'],
    availability: 'in_stock',
    description: 'A convergence of India’s northernmost pinnacle and southern temple loom artistry. Ultra-fine 12-micron Changthangi cashmere hand-spun in Kashmir, framed by pure gold zari borders woven in Kanchipuram with the AARU emblem.',
    editorialNote: 'The union of two sacred craft traditions, wrapped in sublime warmth and lightness.',
    fabric: 'Changthangi Pashmina',
    weaveOrigin: 'Srinagar & Kanchipuram collaborative atelier',
    artisan: {
      name: 'Ghulam Hassan Mir',
      region: 'Downtown Srinagar',
      experienceYears: 40,
      loomHours: 160
    },
    images: [
      'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size'],
    inStock: true,
    featured: false,
    sustainableCertificate: 'Pashmina GI Certified & Ethical Wool Seal',
    details: [
      'Passes through a wedding ring test with effortless grace',
      'Hand-knotted fringe edges',
      'Laser-authenticated microchip embedded in certification card',
      'Wrapped in pure mulberry silk travel pouch'
    ],
    careInstructions: [
      'Professional dry clean only with cashmere care guarantee',
      'Store flat with natural dried lavender sachets'
    ]
  },
  {
    id: 'aaru-08',
    name: 'Akasha Celestial Organza Saree in Cosmic Violet',
    subtitle: 'Hand-Painted Kalamkari Constellations with Gilded Zari',
    price: 125000,
    element: 'ether',
    category: 'saree',
    color: 'Cosmic Violet',
    colorHex: '#6B3FA0',
    occasion: ['Royal Reception', 'Temple Heritage', 'Gala & Red Carpet'],
    availability: 'in_stock',
    description: 'Hand-painted in Sri Kalahasti using bamboo kalam pens and natural vegetable pigments, depicting celestial constellations and planetary orbits upon iridescent violet katan organza.',
    editorialNote: 'Where medieval temple painting merges into high couture fashion.',
    fabric: 'Katan Organza Silk',
    weaveOrigin: 'Sri Kalahasti, Andhra Pradesh',
    artisan: {
      name: 'Ramesh Chandra Guruswamy',
      region: 'Sri Kalahasti',
      experienceYears: 33,
      loomHours: 275
    },
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size'],
    inStock: true,
    featured: false,
    sustainableCertificate: 'Kalamkari GI Tag Registered #AP-8812',
    details: [
      'Authentic milk-treated and myrobalan pre-processed fabric',
      'Dyes extracted from pomegranate peel, madder roots, and fermented iron',
      'Delicate scolloped hand-embroidered zari hem',
      'Includes contrasting raw silk blouse fabric'
    ],
    careInstructions: [
      'Dry clean only',
      'Keep away from acidic moisture; preserve in muslin wrapper'
    ]
  },
  {
    id: 'aaru-09',
    name: 'The Royal Nizam Pure Zari Sherwani',
    subtitle: 'Gilded Deccan Heritage in Ivory Silk & 24k Tested Zardozi',
    price: 215000,
    element: 'aaru',
    category: 'sherwani',
    color: 'Molten Gold',
    colorHex: '#D4AF37',
    occasion: ['Bridal / Wedding', 'Royal Reception'],
    availability: 'made_to_order',
    description: 'An architectural tribute to the sovereign courts of Hyderabad. Pure mulberry raw silk hand-embroidered with authentic salma, sitara, and dabka wires across 340 artisanal hours.',
    editorialNote: 'Designed for imperial ceremony, embodying royal composure.',
    fabric: 'Mulberry Kanchipuram Silk',
    weaveOrigin: 'Atelier Old City, Hyderabad',
    artisan: {
      name: 'Ustad Mir Wajahat Ali',
      region: 'Chowmahalla Quarter, Hyderabad',
      experienceYears: 44,
      loomHours: 340
    },
    images: [
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['M', 'L', 'XL', 'Custom Made-to-Measure'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Nizam Archival Textile Guild Registry #HYD-1102',
    details: [
      'Hand-crafted gold button placket with filigree Telugu emblem',
      'Pure silk churidar and coordinated organza stole included',
      'Internal bespoke monogramming option on lining'
    ],
    careInstructions: [
      'Heritage dry clean only',
      'Preserve in breathable velvet garment bag'
    ]
  },
  {
    id: 'aaru-10',
    name: 'Prithvi Earth-Drawn Terracotta Matka Lehenga',
    subtitle: 'Heavy Raw Silk Brocade with Hand-Hammered Copper Zari',
    price: 195000,
    element: 'earth',
    category: 'lehenga',
    color: 'Terracotta Ochre',
    colorHex: '#A85A32',
    occasion: ['Bridal / Wedding', 'Sangeet & Festive'],
    availability: 'in_stock',
    description: 'Spun from heavy indigenous wild Matka silk and dyed in natural madder root, pomegranate rind, and river silt. Grounded in earthly majesty with 24-panel circular flare.',
    editorialNote: 'A deep homage to the soil of the Deccan plateau.',
    fabric: 'Banarasi Katan Silk',
    weaveOrigin: 'Bhopal & Banaras Artisan Guild',
    artisan: {
      name: 'Rukmini Devi & Master Weavers',
      region: 'Varanasi',
      experienceYears: 30,
      loomHours: 360
    },
    images: [
      'https://images.unsplash.com/photo-1566737236500-c8ac43014a67?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['S', 'M', 'L', 'Custom Made-to-Measure'],
    inStock: true,
    featured: false,
    sustainableCertificate: 'Varanasi Weavers Trust GI Seal #UP-309',
    details: [
      '14-meter kalidar flare with antique copper wire borders',
      'Includes raw silk choli and sheer tissue dupatta',
      'Hand-beaded hemline weights to maintain drape'
    ],
    careInstructions: [
      'Dry clean only',
      'Avoid artificial humidity'
    ]
  },
  {
    id: 'aaru-11',
    name: 'Jala Cascading Teal Georgette Saree',
    subtitle: 'Fluid Ripple Drapes with Real Silver Resham Floral Jaal',
    price: 98000,
    element: 'water',
    category: 'saree',
    color: 'Ocean Turquoise',
    colorHex: '#1D7A8C',
    occasion: ['Royal Reception', 'Sangeet & Festive'],
    availability: 'in_stock',
    description: 'Woven with high-twist georgette threads that undulate like sacred temple river waters. Features all-over silver resham floral jaal that catches candlelight.',
    editorialNote: 'Fluid grace engineered for evening celebrations and dance.',
    fabric: 'Uppada Cotton-Silk',
    weaveOrigin: 'Kanchipuram & Surat Artisan Circle',
    artisan: {
      name: 'K. Somasundaram',
      region: 'Kanchipuram',
      experienceYears: 27,
      loomHours: 195
    },
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size'],
    inStock: true,
    featured: false,
    sustainableCertificate: 'Handloom Board Certified #TN-8821',
    details: [
      'Pure silver resham weft with hypoallergenic finish',
      'Lightweight flow with effortless pleating',
      'Unstitched silk blouse fabric provided'
    ],
    careInstructions: [
      'Specialist dry clean only',
      'Steam press on reverse side'
    ]
  },
  {
    id: 'aaru-12',
    name: 'Vayu Translucent Ahimsa Silk Tunic & Stole',
    subtitle: 'Cruelty-Free Peace Silk with Fine Shadow Work Stitches',
    price: 58000,
    element: 'air',
    category: 'kurta',
    color: 'Ivory Pearl',
    colorHex: '#EDE8DF',
    occasion: ['Gala & Red Carpet', 'Temple Heritage'],
    availability: 'in_stock',
    description: 'Spun from cocoons harvested after the silkworm naturally emerges. Weightless, breathable, and finished with shadow Chikankari embroidery executed by women artisans.',
    editorialNote: 'Peaceful luxury honoring the sacred breath of life.',
    fabric: 'Chanderi Tissue Silk',
    weaveOrigin: 'Lucknow & Chanderi Ateliers',
    artisan: {
      name: 'Fatima Begum Collective',
      region: 'Old Lucknow',
      experienceYears: 22,
      loomHours: 110
    },
    images: [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['XS', 'S', 'M', 'L'],
    inStock: true,
    featured: false,
    sustainableCertificate: 'Certified Ahimsa Peace Silk Standard #IN-ECO-44',
    details: [
      'Cruelty-free wild silk harvest',
      'Hand-pulled thread work along collar and sleeves',
      'Accompanied by matching airy stole'
    ],
    careInstructions: [
      'Gentle hand wash in cold water or mild dry clean',
      'Dry in shade'
    ]
  },
  {
    id: 'aaru-13',
    name: 'The Agni Crimson Kadwa Banarasi Silk Saree',
    subtitle: 'Blazing Vermilion Kadwa Floral Jaal in 24k Tested Silver Zari',
    price: 162000,
    originalPrice: 180000,
    element: 'fire',
    category: 'saree',
    color: 'Crimson Red',
    colorHex: '#A31D1D',
    occasion: ['Bridal / Wedding', 'Royal Reception', 'Temple Heritage'],
    availability: 'in_stock',
    description: 'An auspicious bridal masterpiece woven on the ancient ghat looms of Varanasi. Features 100% pure Mulberry katan silk saturated in ceremonial crimson, interwoven with tested real silver wire electroplated in 24k gold. Each Kadwa paisley motif is engraved with hand shuttles without reverse floats.',
    editorialNote: 'Dedicated to Agni—the primordial flame of celebration and transformative devotion.',
    fabric: 'Banarasi Katan Silk',
    weaveOrigin: 'Varanasi Weaver Colony, Uttar Pradesh',
    artisan: {
      name: 'Ustad Tariq Ansari & Sons',
      region: 'Banaras',
      experienceYears: 38,
      loomHours: 320
    },
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Varanasi GI Certified Silk Mark No. UP-8820',
    details: [
      'Pure Katan Mulberry warp and weft with high tensile strength',
      '24k gold electroplated real silver core zari',
      'Authentic Kadwa technique with cleanly locked reverse wefts',
      'Includes unstitched pure silk blouse piece with gold zardozi cuff border',
      'Ready for immediate 24-hour dispatch in silk preservation casket'
    ],
    careInstructions: [
      'Strict dry clean only',
      'Wrap in pure unbleached cotton mulmul; preserve flat'
    ]
  },
  {
    id: 'aaru-14',
    name: 'Prithvi Sacred Temple Corridor Kanchipuram Saree',
    subtitle: 'Deep Terracotta & Forest Moss Korvai Interlocking Silk',
    price: 148000,
    element: 'earth',
    category: 'saree',
    color: 'Terracotta Ochre',
    colorHex: '#A85A32',
    occasion: ['Bridal / Wedding', 'Temple Heritage', 'Royal Reception'],
    availability: 'in_stock',
    description: 'Carrying the soil memory of South Indian stone sanctums. Featuring deep terracotta body silk paired with dark forest moss borders, interlocked using the 3-shuttle Korvai method. Gilded with traditional Rudraksha and Gopuram motifs.',
    editorialNote: 'Rooted in the primordial earth; structured, solemn, and eternally dignified.',
    fabric: 'Mulberry Kanchipuram Silk',
    weaveOrigin: 'Kanchipuram Heritage Guild, Tamil Nadu',
    artisan: {
      name: 'Padma Shri V. Ramanujam Guild',
      region: 'Kanchipuram',
      experienceYears: 42,
      loomHours: 290
    },
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Silk Mark India & Geographical Indication #TN-4190',
    details: [
      'Heavy 4-ply mulberry silk with authentic South Indian drape',
      'Pure silver tested zari with warm antique gold polish',
      'Heirloom Korvai temple border joined by two master artisans',
      'Includes coordinated forest moss blouse fabric'
    ],
    careInstructions: [
      'Professional heritage dry clean only',
      'Avoid artificial humidity'
    ]
  },
  {
    id: 'aaru-15',
    name: 'The Sovereign Āru Zari Tissue Bridal Saree',
    subtitle: 'Gilded Liquid Gold Tissue with Micro-Woven "ఆరు" Pallu Monogram',
    price: 198000,
    originalPrice: 225000,
    element: 'aaru',
    category: 'saree',
    color: 'Molten Gold',
    colorHex: '#D4AF37',
    occasion: ['Bridal / Wedding', 'Royal Reception', 'Gala & Red Carpet'],
    availability: 'in_stock',
    description: 'The supreme expression of woven light. Crafted with pure gold-dipped silver zari wrapped around an invisible silk filament warp, resulting in an ethereal liquid shimmer that drapes with royal weight. The pallu features our hallmark Telugu "ఆరు" emblem.',
    editorialNote: 'The pinnacle heirloom drape of AARU Atelier: human consciousness transformed into wearable gold.',
    fabric: 'Mulberry Kanchipuram Silk',
    weaveOrigin: 'Kanchipuram Heritage Guild, Tamil Nadu',
    artisan: {
      name: 'Master Weaver S. Krishnamurthy',
      region: 'Kanchipuram',
      experienceYears: 46,
      loomHours: 410
    },
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop'
    ],
    sizes: ['Free Size'],
    inStock: true,
    featured: true,
    sustainableCertificate: 'Silk Mark India & 24K Zari Hallmark Certificate #ARU-GLD-01',
    details: [
      'Tested real gold zari tissue warp and weft',
      'Telugu "ఆరు" selvedge signature micro-monogram in pure gold wire',
      'Includes unstitched zardozi-worked blouse fabric with real seed pearls',
      'Archived in velvet-lined solid teakwood presentation casket'
    ],
    careInstructions: [
      'Strict dry clean only by luxury textile specialists',
      'Wrap in pure cotton muslin'
    ]
  }
];

export const EDITORIAL_COLLECTIONS: EditorialCollection[] = [
  {
    id: 'aaru',
    title: 'The Sixth Element (ఆరు)',
    teluguTitle: 'ఆరు - ఆరవ తత్వం',
    concept: 'The Living Weaver’s Soul',
    subtitle: 'Human consciousness and devotion breathing transcendence into pure gold wire and mulberry silk.',
    element: 'aaru',
    heroImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop',
    moodQuote: 'The thread is inert matter until the artisan’s breath gives it pulse. That breath is ఆరు.',
    quoteAuthor: 'Sunitha Rao, Head Curator of AARU Atelier',
    philosophyStory: [
      'For centuries, sacred Vedic philosophy recognized the Pancha Bhutas: Earth, Water, Fire, Air, and Ether. Yet, in Indian haute couture, the five elements remain dormant until the Sixth Element arrives—the living soul, devotion, and mathematical genius of the handloom weaver.',
      'In Telugu, "ఆరు" translates literally to Six. Within our atelier walls, it represents transcendence: hundreds of hours of synchronized human breath sitting before jacquard pit-looms, turning real silver-gold zari into heirlooms meant to outlive empires.',
      'Every creation under this sovereign capsule is finished with our micro-woven Telugu "ఆరు" selvedge hallmark and preserved in velvet-lined teakwood caskets.'
    ],
    craftHeritage: {
      loomTechnique: 'Korvai 3-Shuttle Interlocking & Real Zari Weaving',
      zariStandard: '24K Tested Gold Core over Sterling Silver Wire',
      originGuild: 'Kanchipuram & Deccan Royal Guilds',
      avgLoomHours: 380,
      textileCertification: 'Silk Mark India & Sovereign Hallmark #ARU-GLD',
      primaryFabric: 'Heavy 4-Ply Mulberry Silk & Changthangi Pashmina'
    },
    accentColor: '#D4AF37',
    palette: ['#D4AF37', '#12131A', '#EDE8DF', '#7D5A1E'],
    productCount: 4,
    featuredProductIds: ['aaru-01', 'aaru-15', 'aaru-07', 'aaru-09']
  },
  {
    id: 'fire',
    title: 'Agni (The Sacred Flame)',
    teluguTitle: 'అగ్ని - దివ్య జ్వాల',
    concept: 'Molten Zari & Crimson Flames',
    subtitle: 'Blazing vermilion silks, hand-beaten gold bullion embroideries, and ceremonial passion captured in pure thread.',
    element: 'fire',
    heroImage: 'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?q=80&w=1800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1566737236500-c8ac43014a67?q=80&w=1200&auto=format&fit=crop',
    moodQuote: 'Fire does not consume our silks; it tempers them into ceremonial immortality.',
    quoteAuthor: 'Ustad Tariq Ansari, Master Kadwa Weaver',
    philosophyStory: [
      'Agni represents purification, passion, and the cosmic spark of life. In Hindu tradition, all sacred vows—the Saptapadi and wedding muhurthams—are witnessed by the holy fire.',
      'The Agni collection weaves this raw celestial energy into heavy katan silks, using natural lac and madder dye recipes that date back four hundred years. Woven with the Kadwa method, each gold motif is etched like a tongues-of-flame engraving into the ruby-red textile ground.',
      'Designed for weddings, auspicious celebrations, and moments that redefine a lifetime.'
    ],
    craftHeritage: {
      loomTechnique: 'Banarasi Kadwa Needle Shuttle Technique',
      zariStandard: 'Real Silver Tested Zari with 24k Gold Electroplating',
      originGuild: 'Varanasi Master Weavers Colony',
      avgLoomHours: 420,
      textileCertification: 'Varanasi GI Brocade Tag Registered',
      primaryFabric: 'Banarasi Katan Silk & Velvet Brocades'
    },
    accentColor: '#EF4444',
    palette: ['#A31D1D', '#D4AF37', '#F59E0B', '#450A0A'],
    productCount: 2,
    featuredProductIds: ['aaru-03', 'aaru-13']
  },
  {
    id: 'ether',
    title: 'Akasha (The Cosmic Void)',
    teluguTitle: 'ఆకాశం - అనంత తత్వం',
    concept: 'Cosmic Starlight & Midnight Indigo',
    subtitle: 'Deep midnight velvet, astral constellation zardozi, and celestial silhouettes reaching for the infinite cosmos.',
    element: 'ether',
    heroImage: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=1200&auto=format&fit=crop',
    moodQuote: 'In the quiet darkness between stars, couture discovers its most profound stillness.',
    quoteAuthor: 'Master Zardooz Mohammad Irfan',
    philosophyStory: [
      'Ether is the container of all things—the primordial sky that cradles galaxies and silence. In couture, Akasha is realized through the deepest midnight indigos, obsidian velvets, and semi-precious bead embroideries that mimic celestial star-charts.',
      'Crafted in our Hyderabad and Banaras ateliers, the garments float around the body with structural grace, capturing the mystery of the Deccan night sky.',
      'For gala soirées, state banquets, and red carpet entries demanding sovereign composure.'
    ],
    craftHeritage: {
      loomTechnique: 'Astral Zardozi & Hand-Drawn Temple Kalamkari',
      zariStandard: 'Oxidized Silver & Platinum Wire Threads',
      originGuild: 'Deccan Royal Zardozi Guild, Hyderabad',
      avgLoomHours: 260,
      textileCertification: 'Deccan Archival Heritage Registry',
      primaryFabric: 'Mulberry Silk Velvet & Katan Organza'
    },
    accentColor: '#8B5CF6',
    palette: ['#12131A', '#6B3FA0', '#8B5CF6', '#D4AF37'],
    productCount: 2,
    featuredProductIds: ['aaru-02', 'aaru-08']
  },
  {
    id: 'water',
    title: 'Jala (Fluid Serpentine Currents)',
    teluguTitle: 'జలం - ప్రవాహ తత్వం',
    concept: 'Fluidity & Liquid Metallic Drapes',
    subtitle: 'Cascading coastal silks, oceanic teal Jamdanis, and shimmering water-ripples echoing sacred sacred rivers.',
    element: 'water',
    heroImage: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
    moodQuote: 'Water yields to everything, yet conquers stone. It is the ultimate lesson in feminine drape.',
    quoteAuthor: 'Narayana Swamy, Master Uppada Artisan',
    philosophyStory: [
      'Water adapts to every vessel while retaining its unstoppable power. From the coastal weaving clusters of Uppada on the Bay of Bengal, Jala creations embrace weightlessness and fluid motion.',
      'Woven using delicate cotton-silk Jamdani techniques where motifs appear to drift like flower petals on clear streams, each drape moves seamlessly with the wearer’s stride.',
      'Engineered for receptions, musical evenings, and celebratory dances.'
    ],
    craftHeritage: {
      loomTechnique: 'Uppada Jamdani Non-Float Weave & Fluid Georgette Jaal',
      zariStandard: 'Fine Silver Resham & Aqua Lurex Inlay',
      originGuild: 'Uppada Marine Weaving Circle, Andhra Pradesh',
      avgLoomHours: 210,
      textileCertification: 'Uppada Jamdani GI Tagged #AP-1082',
      primaryFabric: 'Uppada Cotton-Silk & Liquid Georgette'
    },
    accentColor: '#3B82F6',
    palette: ['#1D7A8C', '#3B82F6', '#60A5FA', '#FAF7F0'],
    productCount: 2,
    featuredProductIds: ['aaru-04', 'aaru-11']
  },
  {
    id: 'earth',
    title: 'Prithvi (The Primordial Soil)',
    teluguTitle: 'పృథ్వి - నేల మూలాలు',
    concept: 'Terra, Bark & Raw Ochre Silks',
    subtitle: 'Grounded in wild Tussar silks, organic madder dyes, and heavy mathematical double-Ikat borders.',
    element: 'earth',
    heroImage: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1566737236500-c8ac43014a67?q=80&w=1200&auto=format&fit=crop',
    moodQuote: 'We do not invent the colors; we merely ask the earth to surrender its secrets.',
    quoteAuthor: 'Chinta Mallesham, Pochampally Master Artisan',
    philosophyStory: [
      'Prithvi grounds our existence in raw authenticity. Our earth silhouettes reject synthetic pigments in favor of river clays, turmeric roots, pomegranate rind, and iron-fermented decoctions.',
      'From Telangana’s Pochampally double-Ikat geometric sherwanis to Banaras Matka silk lehengas, these pieces carry an earthen gravity and timeless poise that commands instant respect.',
      'For heritage patrons, connoisseurs of handloom mathematics, and royal nuptials.'
    ],
    craftHeritage: {
      loomTechnique: 'Pochampally Double-Ikat Mathematical Dyeing & Matka Weaving',
      zariStandard: 'Hand-Hammered Antique Copper & Dull Brass Zari',
      originGuild: 'Bhoodan Pochampally & Deccan Terracotta Looms',
      avgLoomHours: 320,
      textileCertification: 'Pochampally Ikat GI Certificate #TS-5002',
      primaryFabric: 'Double-Ikat Silk, Wild Matka Silk'
    },
    accentColor: '#C5A059',
    palette: ['#A85A32', '#C5A059', '#78350F', '#F59E0B'],
    productCount: 3,
    featuredProductIds: ['aaru-06', 'aaru-10', 'aaru-14']
  },
  {
    id: 'air',
    title: 'Vayu (The Gossamer Breath)',
    teluguTitle: 'వాయువు - గాలి స్పర్శ',
    concept: 'Weightless Organza & Sheer Whisper',
    subtitle: 'Feather-light Chanderi tissues, whisper-thin muslins, and Ahimsa peace silks that float on mountain breezes.',
    element: 'air',
    heroImage: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop',
    moodQuote: 'If a garment is truly mastercrafted, you should feel the universe breathing through it.',
    quoteAuthor: 'Fatima Begum, Chikankari & Ahimsa Guild Leader',
    philosophyStory: [
      'Vayu is freedom, motion, and the breath of life. Utilizing 300-count sheer cotton-silks from Chanderi and ethical cruelty-free Ahimsa silks, the Vayu silhouettes barely register against the skin.',
      'Delicate silver Mukaish needlework is pressed by river stones into the fabric to mimic morning stardust, accompanied by sheer trailing organza capes that billow gracefully with every step.',
      'Designed for summer soirees, daytime festivities, and effortless contemporary luxury.'
    ],
    craftHeritage: {
      loomTechnique: 'Chanderi 300-Count Whisper Weaving & Hand Mukaish Needlecraft',
      zariStandard: 'Feather-light Silver Foil & Pressed Mukaish Dusting',
      originGuild: 'Chanderi & Ahimsa Silk Guilds',
      avgLoomHours: 140,
      textileCertification: 'Certified Ahimsa Peace Silk Standard #IN-ECO-44',
      primaryFabric: 'Chanderi Tissue Silk, Pure Organza'
    },
    accentColor: '#10B981',
    palette: ['#3D7A68', '#10B981', '#EDE8DF', '#6EE7B7'],
    productCount: 2,
    featuredProductIds: ['aaru-05', 'aaru-12']
  }
];

export const SHOP_THE_LOOKS: ShopTheLookEnsemble[] = [
  {
    id: 'look-01',
    title: 'The Sovereign Imperial Muhurtham Look',
    teluguTitle: 'సార్వభౌమ కల్యాణ వైభవం',
    subtitle: 'Complete Bridal Nuptial Ensemble in 24k Tested Gold Kanchipuram Silk & Ladakhi Cashmere Stole',
    element: 'aaru',
    occasion: 'Bridal / Wedding Muhurtham',
    heroLifestyleImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1400&auto=format&fit=crop',
    secondaryEditorialImage: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop',
    story: 'Curated by Senior Couturier Sunitha Rao for the sanctum of the sacred wedding fire. Pairing our flagship 380-hour Sovereign Āru Kanjeevaram Saree with a hand-spun Ladakhi Cashmere gold border stole and gilded bullion blouse drapery.',
    curator: {
      name: 'Sunitha Rao',
      role: 'Lead Bridal Couturier, AARU Atelier'
    },
    bundleSavingsNote: 'Includes complimentary solid teakwood heirloom casket, personalized gold initials monogramming, and white-glove armored delivery.',
    pieces: [
      {
        productId: 'aaru-01',
        product: INITIAL_PRODUCTS[0],
        hotspot: {
          x: 52,
          y: 58,
          label: 'The Sovereign Āru Kanjeevaram Saree',
          role: 'Primary Six-Yard Saree'
        },
        stylingTip: 'Drape with structured South Indian royal pleats to highlight the micro-woven Telugu "ఆరు" emblem on the pallu corner.'
      },
      {
        productId: 'aaru-07',
        product: INITIAL_PRODUCTS[6],
        hotspot: {
          x: 32,
          y: 35,
          label: 'The Āru Genesis Pashmina & Zari Stole',
          role: 'Ceremonial Shoulder Stole'
        },
        stylingTip: 'Rest softly over the left shoulder or drape across both forearms for royal ceremony warmth and stately composure.'
      },
      {
        productId: 'aaru-15',
        product: INITIAL_PRODUCTS[14] || INITIAL_PRODUCTS[0],
        hotspot: {
          x: 68,
          y: 78,
          label: 'The Sovereign Āru Zari Tissue Bridal Saree',
          role: 'Reception Alternate Drape'
        },
        stylingTip: 'Shift to the molten gold tissue for the evening reception for incandescent illumination under chandelier lighting.'
      }
    ]
  },
  {
    id: 'look-02',
    title: 'The Akasha Starlit Gala Evening Ensemble',
    teluguTitle: 'ఆకాశ నక్షత్ర రాజనీతి',
    subtitle: 'Astral Constellation Velvet Cape-Gown Paired with Cosmic Violet Kalamkari Organza',
    element: 'ether',
    occasion: 'Gala & Red Carpet Soirée',
    heroLifestyleImage: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1400&auto=format&fit=crop',
    secondaryEditorialImage: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop',
    story: 'Conceived for international state dinners and nocturnal celebrations. A sculptural midnight silk velvet gown embroidered with astral charts, grounded by gossamer Kalamkari and cashmere accents.',
    curator: {
      name: 'Mohammad Irfan',
      role: 'Master Zardozi Director'
    },
    bundleSavingsNote: 'Includes bespoke corsetry measurement session and velvet travel garment trunk.',
    pieces: [
      {
        productId: 'aaru-02',
        product: INITIAL_PRODUCTS[1],
        hotspot: {
          x: 48,
          y: 45,
          label: 'Akasha Celestial Midnight Velvet Cape-Gown',
          role: 'Sculptural Cape-Gown'
        },
        stylingTip: 'Fasten the high collar clasp and let the trailing gold starburst cape sweep the floor with cinematic presence.'
      },
      {
        productId: 'aaru-08',
        product: INITIAL_PRODUCTS[7],
        hotspot: {
          x: 70,
          y: 62,
          label: 'Akasha Celestial Organza Saree in Cosmic Violet',
          role: 'Hand-Painted Layer Drape'
        },
        stylingTip: 'Wear the katan organza as a diaphanous sash or companion drape for multifaceted textural intrigue.'
      }
    ]
  },
  {
    id: 'look-03',
    title: 'The Royal Nizam Groom Heritage Trousseau',
    teluguTitle: 'నిజాం నవాబు వివాహ వస్త్రశ్రేణి',
    subtitle: 'Pure Gilded Raw Silk Sherwani with Pochampally Double-Ikat Accents & Cashmere Stole',
    element: 'aaru',
    occasion: 'Royal Wedding & Reception',
    heroLifestyleImage: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1400&auto=format&fit=crop',
    secondaryEditorialImage: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1200&auto=format&fit=crop',
    story: 'Channeling the aristocratic dignity of the Deccan courts. Gilded raw silk hand-embroidered with authentic salma and dabka wire, balanced by mathematical Pochampally double-ikat patterns.',
    curator: {
      name: 'Ustad Mir Wajahat Ali',
      role: 'Master Courtier Tailor'
    },
    bundleSavingsNote: 'Complimentary custom enameled Telugu emblem cufflinks and silk churidar included.',
    pieces: [
      {
        productId: 'aaru-09',
        product: INITIAL_PRODUCTS[8],
        hotspot: {
          x: 50,
          y: 40,
          label: 'The Royal Nizam Pure Zari Sherwani',
          role: 'Imperial Raw Silk Sherwani'
        },
        stylingTip: 'Fasten with the filigree gold buttons; tailor to sit flush across shoulders with sharp equestrian lines.'
      },
      {
        productId: 'aaru-07',
        product: INITIAL_PRODUCTS[6],
        hotspot: {
          x: 35,
          y: 50,
          label: 'The Āru Genesis Pashmina & Zari Stole',
          role: 'Cashmere Royal Stole'
        },
        stylingTip: 'Drape cleanly across one shoulder with the Kanchipuram gold border framing the chest.'
      },
      {
        productId: 'aaru-06',
        product: INITIAL_PRODUCTS[5],
        hotspot: {
          x: 65,
          y: 65,
          label: 'Prithvi Saffron Pochampally Ikat Silk Sherwani',
          role: 'Sangeet / Mehendi Silhouette'
        },
        stylingTip: 'Perfect as the energetic companion piece for pre-wedding celebrations.'
      }
    ]
  },
  {
    id: 'look-04',
    title: 'The Vayu & Jala Coastal Garden Soirée Look',
    teluguTitle: 'సాగర తీర వాయు శోభ',
    subtitle: 'Floating Uppada Jamdani Saree Layered with Whisper Sheer Chanderi Cape',
    element: 'water',
    occasion: 'Garden Reception & Sangeet',
    heroLifestyleImage: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1400&auto=format&fit=crop',
    secondaryEditorialImage: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop',
    story: 'A tribute to the marine breezes of coastal Andhra and Madhya Pradesh. Feather-light Jamdani motifs that appear to drift upon ocean-blue water, paired with sheer Chanderi and Mukaish needlework.',
    curator: {
      name: 'Narayana Swamy',
      role: 'Coastal Weft Master'
    },
    bundleSavingsNote: 'Includes silk slip and certified handloom mark documentation.',
    pieces: [
      {
        productId: 'aaru-04',
        product: INITIAL_PRODUCTS[3],
        hotspot: {
          x: 45,
          y: 60,
          label: 'Jala Oceanic Waves Uppada Jamdani Saree',
          role: 'Coastal Jamdani Saree'
        },
        stylingTip: 'Allow the sheer turquoise pallu to float freely over the arm without tight pin folding.'
      },
      {
        productId: 'aaru-05',
        product: INITIAL_PRODUCTS[4],
        hotspot: {
          x: 60,
          y: 38,
          label: 'Vayu Whisper Sheer Chanderi Kurta & Cape Set',
          role: 'Airy Cape Layer'
        },
        stylingTip: 'Layer the sheer tissue cape over the saree blouse or wear separately with palazzo pants.'
      }
    ]
  }
];


export const EDITORIAL_STORIES: EditorialStory[] = [
  {
    id: 'story-01',
    title: 'The Sixth Element: When The Loom Transcends The Cosmos',
    teluguTitle: 'ఆరవ తత్వం: చేనేతలో చైతన్యం',
    subtitle: 'Beyond Prithvi, Jala, Agni, Vayu, and Akasha lies the sixth element: the sacred consciousness of the weaver.',
    readTime: '4 min read',
    chapter: 'Manifesto 01',
    quote: 'The thread is inert earth until the artisan’s breath gives it pulse. That breath is ఆరు.',
    author: 'Sunitha Rao, Senior Curator of South Asian Haute Couture',
    themeColor: '#D4AF37',
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
    featuredProducts: ['aaru-01', 'aaru-07'],
    content: [
      'For millennia, Vedic philosophy and classical thought recognized the Pancha Bhutas: Earth that anchors our roots, Water that yields fluidity, Fire that purifies passion, Air that whispers freedom, and Ether that holds boundless space.',
      'Yet high couture asks a deeper question: What animates these five elements into garments that make the heart stand still? Why does a 400-hour handwoven saree possess a gravitational soul that no factory loom can ever duplicate?',
      'The answer is our namesake: "ఆరు" (Aaru). In Telugu, "ఆరు" literally signifies the number Six. But inside our ateliers, it represents The Sixth Element: Human Consciousness. The quiet pulse of devotion that transforms pure gold wire and mulberry filament into wearable transcendence.',
      'Every collection from AARU is organized by these elemental realms, culminating in the Sixth Element signature archives. When you drape an AARU creation, you do not simply wear luxury; you inhabit a living communion between hand, loom, and cosmos.'
    ]
  },
  {
    id: 'story-02',
    title: 'Echoes of Kanchipuram: 380 Hours Behind The Golden Jacquard',
    teluguTitle: 'కాంచీపురం మగ్గం పై స్వర్ణ సంగీతం',
    subtitle: 'Inside the ancestral sanctum where Master Weaver Ramanujam turns silver wire into immortality.',
    readTime: '6 min read',
    chapter: 'Atelier Chronicle 02',
    quote: 'In our loom room, silence is the only language. The shuttle sings what words cannot hold.',
    author: 'Vikramaditya Varma, Head of Textile Preservation at AARU',
    themeColor: '#C5A059',
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1200&auto=format&fit=crop',
    featuredProducts: ['aaru-01', 'aaru-04'],
    content: [
      'At 5:30 AM in the temple town of Kanchipuram, the morning bells of the Ekambareswarar temple reverberate through narrow stone alleys. In an ancestral pit-loom house whose timber rafters have weathered two centuries, Master Ramanujam checks the tension of 4,800 silk warp threads.',
      'The zari used in AARU couture is not the copper imitation found in commercial fashion. It is certified electroplated 24k gold over a pure silver core. Ramanujam’s hands guide the wooden shuttles with a precision measured in half-millimeters.',
      'Each Korvai interlocking border requires two weavers sitting side-by-side, synchronizing their breathing. If one weaver misses a beat, the temple spire motif loses its alignment. After 380 continuous hours of labor, the saree emerges—weighty, radiant, and immortal.'
    ]
  },
  {
    id: 'story-03',
    title: 'The Telugu Monogram: Why ఆరు Is Woven Into Every Hem',
    teluguTitle: 'ఆరు ముద్ర: తరతరాల తెలుగు వైభవం',
    subtitle: 'Deconstructing the fluid geometry of our emblem and its connection to royal Deccan drapes.',
    readTime: '3 min read',
    chapter: 'Symbolism 03',
    quote: 'Our emblem carries the gentle curve of Telugu script—the Italian of the East—sculpted into couture armor.',
    author: 'Ananya Reddy, Brand Archival Director',
    themeColor: '#8B5CF6',
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop',
    featuredProducts: ['aaru-02', 'aaru-06'],
    content: [
      '16th-century Italian travelers famously called Telugu the "Italian of the East" due to its musicality, with every word ending in a soft melodic vowel sound.',
      'When designing the crest of AARU, we took the sacred Telugu glyph "ఆరు" (Six) and treated its sweeping arcs as aerodynamic calligraphy. The upper loop mimics the circular motion of the hand spinning charkha; the descending curve symbolizes the unspooling warp descending from the loom beam.',
      'On every piece leaving our atelier, a microscopic seal of this Telugu glyph is jacquard-woven into the selvedge in solid gold thread, accompanied by the English wordmark "AARU · The Sixth Element".'
    ]
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-01',
    title: 'Loom Milestone: Order #ARU-9021',
    message: 'Master Weaver Ramanujam has completed the Korvai temple border for your Sovereign Āru Saree. Entering final hand finishing in the gold vault.',
    type: 'order',
    timestamp: '15 mins ago',
    read: false,
    actionUrl: '#orders',
    metadata: { orderId: 'ARU-9021' }
  },
  {
    id: 'notif-02',
    title: 'Personalized Style Curation',
    message: 'Based on your affinity for the Ether & Agni elemental palettes, we have reserved 1 of only 4 Akasha Velvet Capes for your private salon preview.',
    type: 'recommendation',
    timestamp: '2 hours ago',
    read: false,
    actionUrl: '#curations',
    metadata: { productId: 'aaru-02' }
  },
  {
    id: 'notif-03',
    title: 'VIP WhatsApp Concierge Assigned',
    message: 'Senior Couturier Shreya has been assigned as your personal styling advisor on WhatsApp Business for bespoke sizing and fabric swatch delivery.',
    type: 'atelier',
    timestamp: '1 day ago',
    read: true,
    actionUrl: 'https://wa.me/918008006600'
  },
  {
    id: 'notif-04',
    title: 'Autumn/Winter Capsule "The Sixth Element" Live',
    message: 'The new editorial catalog exploring handwoven couture born from the cosmic elements is now live for patrons.',
    type: 'system',
    timestamp: '2 days ago',
    read: true
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'order-9021',
    orderNumber: 'ARU-9021',
    date: 'March 2, 2026',
    total: 185000,
    status: 'Bespoke Tailoring',
    estimatedDelivery: 'March 14, 2026',
    giftPackaging: true,
    shippingAddress: {
      fullName: 'Maharani S. Lakshmi',
      email: 'lakshmi.couture@aaru-patrons.com',
      phone: '+91 98490 12345',
      address: 'Road No. 36, Jubilee Hills',
      city: 'Hyderabad',
      postalCode: '500033',
      country: 'India'
    },
    items: [
      {
        productId: 'aaru-01',
        productName: 'The Sovereign Āru Kanjeevaram Saree',
        productImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1200&auto=format&fit=crop',
        price: 185000,
        quantity: 1,
        size: 'Bespoke Custom Draped',
        monogram: 'AARU · SL',
        customMeasurements: {
          bustChest: '36 in',
          waist: '28 in',
          shoulder: '15 in'
        }
      }
    ],
    trackingMilestones: [
      {
        title: 'Artisan & Loom Allocated',
        description: 'Assigned to Master Weaver V. Ramanujam in Kanchipuram Guild.',
        date: 'March 2, 2026',
        completed: true
      },
      {
        title: 'Pure 24k Zari Weft Weaving',
        description: '380 hours on jacquard pit-loom with Korvai interlocking.',
        date: 'March 6, 2026',
        completed: true
      },
      {
        title: 'Bespoke Tailoring & Monogramming',
        description: 'Currently hand-embroidering golden initials "SL" into selvedge.',
        date: 'March 9, 2026',
        completed: true
      },
      {
        title: 'Archival Vault & Velvet Packaging',
        description: 'Sealing in heirloom teakwood box with scented mulmul wrapping.',
        date: 'Estimated March 12, 2026',
        completed: false
      },
      {
        title: 'White Glove Armored Courier Dispatch',
        description: 'Insured private delivery to Jubilee Hills residence.',
        date: 'Estimated March 14, 2026',
        completed: false
      }
    ]
  }
];

export const INITIAL_USER_PROFILE: UserProfile = {
  id: 'usr-vip-001',
  fullName: 'Gayathri Rao',
  email: 'gayathri.rao@aaru-clientele.com',
  phone: '+91 91234 56789',
  memberTier: 'Atelier Patron',
  elementAffinity: 'aaru',
  measurements: {
    bustChest: '36',
    waist: '29',
    hips: '39',
    shoulder: '15.5',
    height: '5 ft 7 in',
    sleeveLength: '22'
  },
  wishlist: ['aaru-01', 'aaru-03', 'aaru-07']
};

export const WHATSAPP_CONSULTATION_TEMPLATES = {
  bespoke: 'Hello AARU Atelier, I am interested in commissioning a bespoke couture piece from The Sixth Element collection. Could I schedule a private styling session with your couturier?',
  sizing: 'Hello, I need assistance with custom made-to-measure measurements for the AARU pieces. Could your tailoring team guide me?',
  swatches: 'Hello AARU concierge, I would like to request fabric swatches and real 24k gold zari certificates for your heritage handloom pieces.',
  orderSupport: 'Hello AARU client relations, I am inquiring about the progress of my bespoke order.'
};
