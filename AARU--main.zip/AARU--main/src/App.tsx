import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { HeroEditorial } from './components/HeroEditorial';
import { ProductCard } from './components/ProductCard';
import { ProductListingPage } from './components/ProductListingPage';
import { EditorialCollectionLanding } from './components/EditorialCollectionLanding';
import { CuratedRoutePage } from './components/CuratedRoutePage';
import { ShopTheLook } from './components/ShopTheLook';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { WhatsAppConcierge } from './components/WhatsAppConcierge';
import { NotificationDrawer } from './components/NotificationDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { WishlistPage } from './components/WishlistPage';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { UserProfileModal } from './components/UserProfileModal';
import { ConsultationModal } from './components/ConsultationModal';
import { AuthPage } from './components/AuthPage';
import { Footer } from './components/Footer';
import { api } from './services/api';
import {
  Product,
  CartItem,
  Order,
  UserProfile,
  NotificationItem,
  EditorialStory,
  ConsultationRequest,
  CatalogueFilterState,
  SearchFacets
} from './types';
import {
  INITIAL_PRODUCTS,
  EDITORIAL_STORIES,
  INITIAL_ORDERS,
  INITIAL_USER_PROFILE,
  INITIAL_NOTIFICATIONS
} from './data/mockData';
import { Sparkles, MessageCircle, ArrowRight, ArrowLeft, SlidersHorizontal, Compass } from 'lucide-react';

export type AppView = 'home' | 'catalogue' | 'collection' | 'ready-to-ship' | 'sarees-ready-to-ship' | 'shop-the-look' | 'wishlist';

export default function App() {
  // Navigation / View State
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [activeCollectionId, setActiveCollectionId] = useState<string>('aaru');

  // Data State
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [allInventory, setAllInventory] = useState<Product[]>(INITIAL_PRODUCTS);
  const [stories, setStories] = useState<EditorialStory[]>(EDITORIAL_STORIES);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [userProfile, setUserProfile] = useState<UserProfile>(INITIAL_USER_PROFILE);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [unreadNotifications, setUnreadNotifications] = useState(2);

  // Authentication State (Requires login first to access website)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return Boolean(localStorage.getItem('aaru_auth_token'));
    } catch {
      return false;
    }
  });

  // Search & Catalogue Filter State
  const [globalSearchOpen, setGlobalSearchOpen] = useState(false);
  const [facets, setFacets] = useState<SearchFacets | null>(null);
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');

  const formatPrice = (priceINR: number) => {
    if (currency === 'USD') {
      return `$${Math.round(priceINR / 83).toLocaleString()}`;
    }
    return `₹${priceINR.toLocaleString('en-IN')}`;
  };

  const [catalogueFilters, setCatalogueFilters] = useState<CatalogueFilterState>({
    category: 'all',
    collection: 'all',
    availability: 'all',
    color: [],
    fabric: [],
    size: [],
    occasion: [],
    sort: 'featured'
  });

  // Shopping & Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('aaru_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [giftPackaging, setGiftPackaging] = useState<boolean>(true);

  // Modal Views State
  const [activeDetailProduct, setActiveDetailProduct] = useState<Product | null>(null);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [wishlistDrawerOpen, setWishlistDrawerOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [profileModalTab, setProfileModalTab] = useState<'orders' | 'measurements' | 'quiz' | 'wishlist'>('orders');
  const [consultationModalOpen, setConsultationModalOpen] = useState(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);

  // Synchronize cart with localStorage
  useEffect(() => {
    try {
      localStorage.setItem('aaru_cart', JSON.stringify(cartItems));
    } catch {
      // Ignore
    }
  }, [cartItems]);

  // Global Keyboard Shortcuts (Cmd+K / Ctrl+K and '/' for search)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isInput = ['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName);
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setGlobalSearchOpen(prev => !prev);
      } else if (e.key === '/' && !isInput) {
        e.preventDefault();
        setGlobalSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Check active authentication session on mount
  useEffect(() => {
    const checkAuthSession = async () => {
      try {
        const session = await api.getCurrentAuth();
        if (session && session.user) {
          setUserProfile(session.user);
          setIsAuthenticated(true);
        }
      } catch {
        // Fallback to local storage state
      }
    };
    checkAuthSession();
  }, []);

  const handleAuthenticated = (user: UserProfile) => {
    setUserProfile(user);
    setIsAuthenticated(true);
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch {
      // Ignore
    }
    setIsAuthenticated(false);
  };

  // Initial Load from API
  useEffect(() => {
    const initData = async () => {
      try {
        const [fetchedProducts, fetchedStories, fetchedOrders, fetchedProfile, fetchedNotifs, fetchedFacets] = await Promise.all([
          api.getProducts(),
          api.getStories(),
          api.getOrders(),
          api.getProfile(),
          api.getNotifications(),
          api.getCatalogueFilters()
        ]);
        if (fetchedProducts.length) {
          setProducts(fetchedProducts);
          setAllInventory(fetchedProducts);
        }
        if (fetchedStories.length) setStories(fetchedStories);
        if (fetchedOrders.length) setOrders(fetchedOrders);
        if (fetchedProfile) setUserProfile(fetchedProfile);
        if (fetchedNotifs) {
          setNotifications(fetchedNotifs.items);
          setUnreadNotifications(fetchedNotifs.unreadCount);
        }
        if (fetchedFacets) setFacets(fetchedFacets);
      } catch {
        // Mock data already serves as fallback
      }
    };
    initData();
  }, []);

  // Dynamic Querying when Catalogue Filters change
  useEffect(() => {
    const runSearchQuery = async () => {
      try {
        const res = await api.search({
          category: catalogueFilters.category,
          collection: catalogueFilters.collection,
          minPrice: catalogueFilters.minPrice,
          maxPrice: catalogueFilters.maxPrice,
          color: catalogueFilters.color,
          fabric: catalogueFilters.fabric,
          size: catalogueFilters.size,
          occasion: catalogueFilters.occasion,
          availability: catalogueFilters.availability,
          sort: catalogueFilters.sort
        });
        if (res?.products) {
          setProducts(res.products);
        }
        if (res?.facets) {
          setFacets(res.facets);
        }
      } catch (err) {
        console.error('Filter search failed:', err);
      }
    };
    runSearchQuery();
  }, [catalogueFilters]);

  // Filter handlers
  const handleFilterChange = useCallback((newFilters: Partial<CatalogueFilterState>) => {
    setCatalogueFilters(prev => ({ ...prev, ...newFilters }));
  }, []);

  const handleResetFilters = useCallback(() => {
    setCatalogueFilters({
      category: 'all',
      collection: 'all',
      availability: 'all',
      color: [],
      fabric: [],
      size: [],
      occasion: [],
      sort: 'featured'
    });
  }, []);

  // Cart Operations
  const handleAddToCart = (item: CartItem) => {
    setCartItems(prev => {
      const existingIdx = prev.findIndex(
        it => it.product.id === item.product.id && it.size === item.size && it.monogram === item.monogram
      );
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += item.quantity;
        return updated;
      }
      return [...prev, item];
    });
    setCartDrawerOpen(true);
  };

  const handleQuickAdd = (product: Product, size?: string) => {
    handleAddToCart({
      product,
      size: size || product.sizes[0] || 'Standard Size',
      quantity: 1
    });
  };

  const handleUpdateQuantity = (index: number, quantity: number) => {
    setCartItems(prev => {
      const updated = [...prev];
      updated[index].quantity = quantity;
      return updated;
    });
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdateCartSize = (index: number, newSize: string) => {
    setCartItems(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], size: newSize };
      return updated;
    });
  };

  // Wishlist Operations
  const handleToggleWishlist = async (productId: string) => {
    const exists = userProfile.wishlist.includes(productId);
    const updatedWishlist = exists
      ? userProfile.wishlist.filter(id => id !== productId)
      : [...userProfile.wishlist, productId];

    const updatedProfile = { ...userProfile, wishlist: updatedWishlist };
    setUserProfile(updatedProfile);
    await api.updateProfile({ wishlist: updatedWishlist });
  };

  const handleMoveWishlistToCart = (productId: string, size?: string) => {
    const product = allInventory.find(p => p.id === productId);
    if (!product) return;
    handleQuickAdd(product, size);
    handleToggleWishlist(productId);
  };

  const handleMoveAllWishlistToCart = () => {
    const wishlistedProducts = allInventory.filter(p => userProfile.wishlist.includes(p.id));
    wishlistedProducts.forEach(prod => {
      handleAddToCart({
        product: prod,
        size: prod.sizes[0] || 'Standard Size',
        quantity: 1
      });
    });
    const updatedProfile = { ...userProfile, wishlist: [] };
    setUserProfile(updatedProfile);
    api.updateProfile({ wishlist: [] });
    setWishlistDrawerOpen(false);
    setCartDrawerOpen(true);
  };

  // Notifications Operations
  const handleMarkAllNotificationsRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    setUnreadNotifications(0);
    await api.markNotificationsRead();
  };

  const handleMarkNotificationRead = async (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    setUnreadNotifications(prev => Math.max(0, prev - 1));
    await api.markNotificationsRead(id);
  };

  const handleTriggerTestPush = async (type: 'order' | 'recommendation' | 'atelier') => {
    const newNotif = await api.triggerTestNotification(type);
    if (newNotif) {
      setNotifications(prev => [newNotif, ...prev]);
      setUnreadNotifications(prev => prev + 1);

      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        new Notification(newNotif.title, {
          body: newNotif.message,
          icon: '/assets/aistudio/logo.png'
        });
      }
    }
  };

  // Consultations & WhatsApp
  const handleBookConsultation = async (data: Partial<ConsultationRequest>) => {
    const res = await api.bookConsultation(data);
    if (res) {
      const updatedNotifs = await api.getNotifications();
      setNotifications(updatedNotifs.items);
      setUnreadNotifications(updatedNotifs.unreadCount);
    }
  };

  const handleWhatsAppInquiry = (product: Product, customText?: string) => {
    const text = customText || `Hello AARU Atelier, I am inquiring about "${product.name}" (${product.fabric}, ${product.weaveOrigin}). Could your couture team guide me on custom measurements and bespoke delivery?`;
    const url = `https://wa.me/918008006600?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Checkout & Order Placement
  const handleOrderPlaced = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    setCartItems([]);
    api.getNotifications().then(res => {
      setNotifications(res.items);
      setUnreadNotifications(res.unreadCount);
    });
  };

  // Route and View Navigation Helpers
  const navigateToView = (view: AppView, extra?: string) => {
    setCurrentView(view);
    if (view === 'collection' && extra) {
      setActiveCollectionId(extra);
    }
    let newPath = '/';
    if (view === 'ready-to-ship') newPath = '/ready-to-ship';
    else if (view === 'sarees-ready-to-ship') newPath = '/sarees-ready-to-ship';
    else if (view === 'collection') newPath = `/collections/${extra || activeCollectionId || 'aaru'}`;
    else if (view === 'shop-the-look') newPath = '/shop-the-look';
    else if (view === 'catalogue') newPath = '/catalogue';
    else if (view === 'wishlist') newPath = '/wishlist';

    if (typeof window !== 'undefined' && window.location.pathname !== newPath) {
      try {
        window.history.pushState({}, '', newPath);
      } catch {
        // Safe fallback for sandbox restrictions
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Browser Popstate / Path Synchronizer
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path === '/ready-to-ship') {
        setCurrentView('ready-to-ship');
      } else if (path === '/sarees-ready-to-ship') {
        setCurrentView('sarees-ready-to-ship');
      } else if (path.startsWith('/collections')) {
        const parts = path.split('/');
        const colId = parts[2] || 'aaru';
        setActiveCollectionId(colId);
        setCurrentView('collection');
      } else if (path === '/shop-the-look') {
        setCurrentView('shop-the-look');
      } else if (path === '/catalogue') {
        setCurrentView('catalogue');
      } else if (path === '/wishlist') {
        setCurrentView('wishlist');
      }
    };

    handlePopState();
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Scroll Helpers
  const scrollToCreations = () => {
    if (currentView !== 'home') {
      setCurrentView('home');
      setTimeout(() => {
        const el = document.getElementById('creations-catalogue');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById('creations-catalogue');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToStory = () => {
    scrollToCreations();
  };

  const navigateToCatalogue = (options?: { element?: string; category?: string }) => {
    if (options) {
      setCatalogueFilters(prev => ({
        ...prev,
        collection: options.element || prev.collection,
        category: options.category || prev.category
      }));
    }
    navigateToView('catalogue');
  };

  // Route Protection: The user must login to access the website first
  if (!isAuthenticated) {
    return <AuthPage onAuthenticated={handleAuthenticated} />;
  }

  return (
    <div className="min-h-screen bg-[#07080B] text-[#FAF7F0] font-sans selection:bg-[#D4AF37]/30 selection:text-white">
      {/* Header with Telugu Logo, English Name, and Tagline */}
      <Header
        cartCount={cartItems.reduce((acc, it) => acc + it.quantity, 0)}
        wishlistCount={userProfile.wishlist.length}
        unreadNotifications={unreadNotifications}
        currentUser={userProfile}
        onLogout={handleLogout}
        onOpenCart={() => setCartDrawerOpen(true)}
        onOpenNotifications={() => setNotificationsOpen(true)}
        onOpenProfile={() => {
          setProfileModalTab('orders');
          setProfileModalOpen(true);
        }}
        onOpenWishlist={() => setWishlistDrawerOpen(true)}
        onOpenConsultation={() => setConsultationModalOpen(true)}
        onOpenQuiz={() => {
          setProfileModalTab('quiz');
          setProfileModalOpen(true);
        }}
        onOpenSearch={() => setGlobalSearchOpen(true)}
        onSelectStory={scrollToStory}
        onSelectCollection={elem => {
          if (elem && elem !== 'all') {
            navigateToView('collection', elem);
          } else {
            navigateToView('collection', 'aaru');
          }
        }}
        onSelectCategory={cat => {
          if (cat === 'Ready to Ship') {
            navigateToView('ready-to-ship');
          } else if (cat === 'Sarees') {
            navigateToView('sarees-ready-to-ship');
          } else {
            navigateToCatalogue({ category: cat });
          }
        }}
        onNavigateHome={() => navigateToView('home')}
        onNavigateReadyToShip={() => navigateToView('ready-to-ship')}
        onNavigateSareesReadyToShip={() => navigateToView('sarees-ready-to-ship')}
        onNavigateCollections={id => navigateToView('collection', id || 'aaru')}
        onNavigateShopTheLook={() => navigateToView('shop-the-look')}
        onNavigateCatalogue={() => navigateToView('catalogue')}
        onNavigateWishlist={() => navigateToView('wishlist')}
        onOpenWishlist={() => setWishlistDrawerOpen(true)}
        currentView={currentView}
        currency={currency}
        onToggleCurrency={() => setCurrency(prev => prev === 'INR' ? 'USD' : 'INR')}
        onSearchSelect={prod => setActiveDetailProduct(prod)}
        allProducts={allInventory}
      />

      {/* Main View Router: Home vs PLP vs Editorial Collections vs Curated Routes vs Shop The Look */}
      {currentView === 'catalogue' ? (
        <main>
          {/* Breadcrumb / Return to Atelier Home bar */}
          <div className="bg-[#090C14] border-b border-[#1A1E2D] py-3 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <button
                type="button"
                onClick={() => navigateToView('home')}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#B3B8CC] hover:text-[#D4AF37] transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Atelier Editorial</span>
              </button>

              <div className="flex items-center gap-2 text-[11px] text-[#7B8094]">
                <span>AARU Atelier</span>
                <span>/</span>
                <span className="text-[#FAF7F0] font-medium">Product Listing Page (PLP)</span>
              </div>
            </div>
          </div>

          {/* Full-Featured Responsive PLP */}
          <ProductListingPage
            products={products}
            facets={facets}
            currency={currency}
            filters={catalogueFilters}
            onFilterChange={handleFilterChange}
            onResetFilters={handleResetFilters}
            isWishlisted={id => userProfile.wishlist.includes(id)}
            onToggleWishlist={handleToggleWishlist}
            onQuickView={prod => setActiveDetailProduct(prod)}
            onAddToCart={handleQuickAdd}
            onWhatsAppInquiry={handleWhatsAppInquiry}
            onOpenGlobalSearch={() => setGlobalSearchOpen(true)}
          />
        </main>
      ) : currentView === 'collection' ? (
        <main>
          {/* Breadcrumb / Return to Atelier Home bar */}
          <div className="bg-[#090C14] border-b border-[#1A1E2D] py-3 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <button
                type="button"
                onClick={() => navigateToView('home')}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#B3B8CC] hover:text-[#D4AF37] transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Atelier Home</span>
              </button>

              <div className="flex items-center gap-2 text-[11px] text-[#7B8094]">
                <span>AARU Collections</span>
                <span>/</span>
                <span className="text-[#FAF7F0] font-medium">Editorial Collection Landing</span>
              </div>
            </div>
          </div>

          <EditorialCollectionLanding
            collectionId={activeCollectionId}
            onSelectCollection={id => {
              setActiveCollectionId(id);
              navigateToView('collection', id);
            }}
            onSelectProduct={prod => setActiveDetailProduct(prod)}
            onQuickViewProduct={prod => setActiveDetailProduct(prod)}
            onAddToCart={handleQuickAdd}
            onOpenQuiz={() => {
              setProfileModalTab('quiz');
              setProfileModalOpen(true);
            }}
            onOpenConsultation={() => setConsultationModalOpen(true)}
            currency={currency}
            formatPrice={formatPrice}
            wishlist={userProfile.wishlist}
            onToggleWishlist={handleToggleWishlist}
          />
        </main>
      ) : currentView === 'ready-to-ship' || currentView === 'sarees-ready-to-ship' ? (
        <main>
          <CuratedRoutePage
            mode={currentView === 'sarees-ready-to-ship' ? 'sarees-ready-to-ship' : 'ready-to-ship'}
            onSwitchMode={m => navigateToView(m)}
            onSelectProduct={prod => setActiveDetailProduct(prod)}
            onQuickViewProduct={prod => setActiveDetailProduct(prod)}
            onAddToCart={handleQuickAdd}
            currency={currency}
            formatPrice={formatPrice}
            wishlist={userProfile.wishlist}
            onToggleWishlist={handleToggleWishlist}
            onNavigateHome={() => navigateToView('home')}
            onNavigateCatalogue={() => navigateToView('catalogue')}
          />
        </main>
      ) : currentView === 'shop-the-look' ? (
        <main>
          {/* Breadcrumb / Return to Atelier Home bar */}
          <div className="bg-[#090C14] border-b border-[#1A1E2D] py-3 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <button
                type="button"
                onClick={() => navigateToView('home')}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#B3B8CC] hover:text-[#D4AF37] transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Atelier Home</span>
              </button>

              <div className="flex items-center gap-2 text-[11px] text-[#7B8094]">
                <span>AARU Atelier</span>
                <span>/</span>
                <span className="text-[#FAF7F0] font-medium">Shop The Look Ensembles</span>
              </div>
            </div>
          </div>

          <ShopTheLook
            currency={currency}
            formatPrice={formatPrice}
            onAddToCart={handleQuickAdd}
            onQuickViewProduct={prod => setActiveDetailProduct(prod)}
            onViewProductDetails={id => {
              const p = allInventory.find(item => item.id === id);
              if (p) setActiveDetailProduct(p);
            }}
            onNavigateCatalogue={() => navigateToView('catalogue')}
          />
        </main>
      ) : currentView === 'wishlist' ? (
        <main>
          {/* Breadcrumb / Return to Home bar */}
          <div className="bg-[#090C14] border-b border-[#1A1E2D] py-3 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <button
                type="button"
                onClick={() => navigateToView('home')}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#B3B8CC] hover:text-[#D4AF37] transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Home</span>
              </button>

              <div className="flex items-center gap-2 text-[11px] text-[#7B8094]">
                <span>AARU</span>
                <span>/</span>
                <span className="text-[#FAF7F0] font-medium">Wishlist</span>
              </div>
            </div>
          </div>

          <WishlistPage
            wishlistIds={userProfile.wishlist}
            allProducts={allInventory}
            onSelectProduct={prod => setActiveDetailProduct(prod)}
            onRemoveFromWishlist={handleToggleWishlist}
            onMoveToCart={handleMoveWishlistToCart}
            onMoveAllToCart={handleMoveAllWishlistToCart}
            onOpenCart={() => setCartDrawerOpen(true)}
            currency={currency}
            formatPrice={formatPrice}
            onNavigateHome={() => navigateToView('home')}
            onNavigateCatalogue={() => navigateToView('catalogue')}
          />
        </main>
      ) : (
        /* Home Editorial View */
        <main>
          {/* Hero Section */}
          <HeroEditorial
            onExploreClick={() => navigateToCatalogue()}
            onNavigateReadyToShip={() => navigateToView('ready-to-ship')}
            onOpenConsultation={() => setConsultationModalOpen(true)}
          />

          {/* Product Catalogue Section on Home */}
          <div id="creations-catalogue">
            {/* Direct Haute Couture Silhouettes Header */}
            <section className="pt-16 pb-8 bg-[#07080B] border-t border-[#1C1F2B]">
              <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-[#1E2230]">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-6 h-px bg-[#D4AF37]" />
                      <span className="text-[11px] uppercase tracking-[0.24em] text-[#D4AF37] font-medium">
                        ✦ HAUTE COUTURE TREASURY
                      </span>
                    </div>
                    <h2 className="font-cinzel text-3xl sm:text-4xl lg:text-5xl font-bold text-[#FAF7F0] tracking-wide">
                      Masterpiece Silhouettes
                    </h2>
                    <p className="mt-2 text-sm text-[#A09A8E] max-w-2xl font-sans">
                      Certified 24-karat tested electroplated zari, organic Telangana silks, and royal Deccan master tailoring.
                    </p>
                  </div>

                  {/* Right: Quick actions & Count */}
                  <div className="flex items-center gap-4">
                    <span className="text-xs uppercase tracking-widest text-[#7E8294]">
                      Showing <strong className="text-[#FAF7F0]">{products.length}</strong> Creations
                    </span>
                    <button
                      onClick={() => navigateToCatalogue()}
                      className="px-5 py-2.5 rounded-full bg-[#10121A] hover:bg-[#161924] border border-[#D4AF37]/60 text-[#D4AF37] hover:text-[#FAF7F0] text-xs uppercase tracking-wider font-medium transition-all flex items-center gap-2"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Advanced Filters</span>
                    </button>
                  </div>
                </div>

                {/* Category Quick Filter Pills */}
                <div className="flex items-center gap-2 overflow-x-auto py-5 scrollbar-none">
                  {['all', 'Sarees', 'Lehengas', 'Sherwanis', 'Gowns', 'Kurtas', 'Stoles', 'Ready to Ship'].map(cat => {
                    const isSelected = (catalogueFilters.category || 'all') === cat;
                    return (
                      <button
                        key={cat}
                        onClick={() => handleFilterChange({ category: cat })}
                        className={`px-4 py-2 rounded-full text-xs tracking-wider uppercase font-medium whitespace-nowrap transition-all ${
                          isSelected
                            ? 'bg-[#D4AF37] text-black font-semibold shadow-md'
                            : 'bg-[#10121A] hover:bg-[#181B26] text-[#C8C2B7] hover:text-white border border-[#232738]'
                        }`}
                      >
                        {cat === 'all' ? 'All Silhouettes' : cat}
                      </button>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* Product Grid with Quick Switch to Full PLP */}
            <section className="py-12 bg-[#07080B]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
                {/* Switcher Banner to Open Advanced Filters / Full PLP */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-lg bg-[#0E111B] border border-[#212638]">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded bg-[#181D2E] text-[#D4AF37]">
                      <SlidersHorizontal className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-cinzel text-sm font-bold text-[#FAF7F0]">
                        Advanced Curatorial Refinement Available
                      </h4>
                      <p className="text-xs text-[#8E93A8]">
                        Filter by Color palette, Fabric weave, Size specification, Occasion, and Availability.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => navigateToCatalogue()}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-sm bg-[#D4AF37] hover:bg-[#E5C07B] text-black text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md"
                  >
                    <span>Open Full PLP Experience ({products.length})</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {products.length === 0 ? (
                  <div className="text-center py-20 text-[#7A756C] space-y-3">
                    <Sparkles className="w-8 h-8 mx-auto text-[#D4AF37] opacity-40" />
                    <p className="text-sm">No creations found matching this elemental filter.</p>
                    <button
                      onClick={handleResetFilters}
                      className="text-xs uppercase tracking-widest text-[#D4AF37] underline"
                    >
                      View All Creations
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
                    {products.map(product => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        currency={currency}
                        isWishlisted={userProfile.wishlist.includes(product.id)}
                        onToggleWishlist={handleToggleWishlist}
                        onQuickView={prod => setActiveDetailProduct(prod)}
                        onAddToCart={handleQuickAdd}
                        onWhatsAppInquiry={handleWhatsAppInquiry}
                      />
                    ))}
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* Interactive Bespoke VIP Invitation Strip */}
          <section className="py-16 bg-[#0F1118] border-y border-[#252838] relative overflow-hidden">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center space-y-6 relative z-10">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/40 text-xs font-semibold text-[#D4AF37] uppercase tracking-widest">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Bespoke Clothing Consultations</span>
              </div>

              <h2 className="font-cinzel text-3xl sm:text-4xl font-bold tracking-[0.15em] text-[#FAF7F0] uppercase">
                Commission Your Sixth Element Heirloom
              </h2>

              <p className="text-sm sm:text-base text-[#B0AAA0] max-w-2xl mx-auto font-light leading-relaxed">
                Connect directly with our master couturiers via WhatsApp Business. Receive silk yarn swatches, discuss custom blouse embroidery, and schedule video appointments directly from your home.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
                <a
                  href="https://wa.me/918008006600?text=Hello%20AARU%20Atelier,%20I%20would%20like%20to%20request%20a%20Bespoke%20Couture%20Consultation."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-black font-semibold text-xs tracking-[0.25em] uppercase rounded-sm transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Open WhatsApp Business Chat</span>
                </a>

                <button
                  onClick={() => setConsultationModalOpen(true)}
                  className="px-8 py-3.5 bg-[#171924] hover:bg-[#222536] border border-[#3A4058] text-[#FAF7F0] font-semibold text-xs tracking-[0.25em] uppercase rounded-sm transition-all"
                >
                  Schedule Video Tailoring Session
                </button>
              </div>
            </div>
          </section>
        </main>
      )}

      {/* Luxury Footer */}
      <Footer
        onSelectStory={scrollToStory}
        onOpenConsultation={() => setConsultationModalOpen(true)}
        onSelectElement={elem => navigateToCatalogue({ element: elem })}
      />

      {/* Floating WhatsApp Business Concierge Widget */}
      <WhatsAppConcierge
        onOpenBookingModal={() => setConsultationModalOpen(true)}
      />

      {/* Modals & Drawers */}

      {/* 1. Global Search Modal (supports products, collections, hotkey Cmd+K, empty & zero-states) */}
      <GlobalSearchModal
        isOpen={globalSearchOpen}
        onClose={() => setGlobalSearchOpen(false)}
        currency={currency}
        onSelectProduct={prod => {
          setActiveDetailProduct(prod);
          setGlobalSearchOpen(false);
        }}
        onSelectCollection={col => {
          navigateToCatalogue({ element: col });
          setGlobalSearchOpen(false);
        }}
        onSelectCategory={cat => {
          navigateToCatalogue({ category: cat });
          setGlobalSearchOpen(false);
        }}
      />

      {/* 2. Product Detail Modal */}
      {activeDetailProduct && (
        <ProductDetailModal
          product={activeDetailProduct}
          onClose={() => setActiveDetailProduct(null)}
          currency={currency}
          isWishlisted={userProfile.wishlist.includes(activeDetailProduct.id)}
          onToggleWishlist={handleToggleWishlist}
          onAddToCart={handleAddToCart}
          onWhatsAppInquiry={handleWhatsAppInquiry}
        />
      )}

      {/* 3. Push Notification & Alert Center Drawer */}
      <NotificationDrawer
        isOpen={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllRead={handleMarkAllNotificationsRead}
        onMarkRead={handleMarkNotificationRead}
        onTriggerTestPush={handleTriggerTestPush}
      />

      {/* 4. Wishlist Drawer */}
      <WishlistDrawer
        isOpen={wishlistDrawerOpen}
        onClose={() => setWishlistDrawerOpen(false)}
        wishlistIds={userProfile.wishlist}
        wishlistProductIds={userProfile.wishlist}
        allProducts={allInventory}
        currency={currency}
        onRemoveWishlist={handleToggleWishlist}
        onRemoveFromWishlist={handleToggleWishlist}
        onMoveToCart={handleMoveWishlistToCart}
        onMoveAllToCart={handleMoveAllWishlistToCart}
        onOpenCart={() => {
          setWishlistDrawerOpen(false);
          setCartDrawerOpen(true);
        }}
        onViewWishlistPage={() => {
          setWishlistDrawerOpen(false);
          navigateToView('wishlist');
        }}
        onSelectProduct={prod => setActiveDetailProduct(prod)}
      />

      {/* 5. Cart Drawer */}
      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        onUpdateSize={handleUpdateCartSize}
        onProceedCheckout={() => {
          setCartDrawerOpen(false);
          setCheckoutModalOpen(true);
        }}
        currency={currency}
        giftPackaging={giftPackaging}
        onToggleGiftPackaging={setGiftPackaging}
      />

      {/* 6. Checkout Modal */}
      {checkoutModalOpen && (
        <CheckoutModal
          isOpen={checkoutModalOpen}
          onClose={() => setCheckoutModalOpen(false)}
          items={cartItems}
          currency={currency}
          giftPackaging={giftPackaging}
          onOrderPlaced={handleOrderPlaced}
        />
      )}

      {/* 7. Account & Saved Items Modal */}
      {profileModalOpen && (
        <UserProfileModal
          isOpen={profileModalOpen}
          onClose={() => setProfileModalOpen(false)}
          profile={userProfile}
          orders={orders}
          allProducts={allInventory}
          onUpdateProfile={async updated => {
            const res = await api.updateProfile(updated);
            setUserProfile(res);
          }}
          currency={currency}
          onSelectProduct={prod => setActiveDetailProduct(prod)}
          initialTab={profileModalTab}
          onLogout={handleLogout}
          onRemoveFromWishlist={handleToggleWishlist}
          onNavigateWishlistPage={() => {
            setProfileModalOpen(false);
            navigateToView('wishlist');
          }}
        />
      )}

      {/* 7. Bespoke Consultation Modal */}
      {consultationModalOpen && (
        <ConsultationModal
          isOpen={consultationModalOpen}
          onClose={() => setConsultationModalOpen(false)}
          onSubmit={handleBookConsultation}
        />
      )}
    </div>
  );
}

