import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  INITIAL_PRODUCTS,
  EDITORIAL_STORIES,
  INITIAL_ORDERS,
  INITIAL_USER_PROFILE,
  INITIAL_NOTIFICATIONS,
  EDITORIAL_COLLECTIONS,
  SHOP_THE_LOOKS
} from './src/data/mockData';
import { Order, UserProfile, NotificationItem, ConsultationRequest, Product } from './src/types/index';
import { DatabaseSearchEngine, SearchQueryFilters } from './server/searchService';
import {
  sendOtpVerification,
  verifyOtpCode,
  authenticateWithGoogle,
  activeSessions,
  hasTwilioCredentials,
  checkVerifySidFormat
} from './server/twilioAuthService';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory persistent state (simulating PostgreSQL / durable store with full schema operations)
  let products: Product[] = [...INITIAL_PRODUCTS];
  const searchEngine = new DatabaseSearchEngine(products);
  let orders: Order[] = [...INITIAL_ORDERS];
  let userProfile: UserProfile = { ...INITIAL_USER_PROFILE };
  let notifications: NotificationItem[] = [...INITIAL_NOTIFICATIONS];
  let stories = [...EDITORIAL_STORIES];
  let consultations: ConsultationRequest[] = [
    {
      id: 'cons-01',
      clientName: 'Gayathri Rao',
      email: 'gayathri.rao@aaru-clientele.com',
      phone: '+91 91234 56789',
      preferredChannel: 'whatsapp',
      preferredDate: '2026-03-15',
      coutureInterest: 'The Sovereign Āru Kanjeevaram Saree Bespoke Drapery',
      measurementsNotes: 'Custom saree blouse padding and 36in bust specification',
      budgetRange: '₹1,50,000 - ₹3,00,000',
      status: 'confirmed'
    }
  ];

  // API Endpoints:
  
  // 0. Authentication API (Twilio SMS Verify & Google Sign-In)
  app.get('/api/auth/status', (_req: Request, res: Response) => {
    const sidCheck = checkVerifySidFormat();
    res.json({
      success: true,
      hasTwilioConfigured: hasTwilioCredentials(),
      sidFormat: sidCheck,
      message: hasTwilioCredentials()
        ? 'Twilio Verify API credentials configured and active'
        : (sidCheck.message || 'Running in development mode (Twilio credentials pending in environment variables)')
    });
  });

  // POST /api/auth/send-otp
  app.post('/api/auth/send-otp', async (req: Request, res: Response) => {
    try {
      const { phoneNumber, fullName, email } = req.body;
      if (!phoneNumber) {
        return res.status(400).json({
          success: false,
          message: 'Phone number is required to send verification code'
        });
      }

      const result = await sendOtpVerification(phoneNumber, { fullName, email });
      res.json(result);
    } catch (err: any) {
      console.error('[API Send OTP Error]:', err?.message || err);
      res.status(400).json({
        success: false,
        message: err?.message || 'Failed to dispatch verification SMS'
      });
    }
  });

  // POST /api/auth/verify-otp
  app.post('/api/auth/verify-otp', async (req: Request, res: Response) => {
    try {
      const { phoneNumber, code, fullName, email } = req.body;
      if (!phoneNumber || !code) {
        return res.status(400).json({
          success: false,
          message: 'Both phone number and 6-digit verification code are required'
        });
      }

      const result = await verifyOtpCode(phoneNumber, code, { fullName, email });
      
      // Sync with global userProfile for the active session
      userProfile = { ...result.user };

      res.json(result);
    } catch (err: any) {
      console.error('[API Verify OTP Error]:', err?.message || err);
      res.status(400).json({
        success: false,
        message: err?.message || 'Verification failed. Please check the code and try again.'
      });
    }
  });

  // POST /api/auth/google
  app.post('/api/auth/google', async (req: Request, res: Response) => {
    try {
      const { email, name, picture, googleId } = req.body;
      if (!email) {
        return res.status(400).json({
          success: false,
          message: 'Valid Google email is required for sign-in'
        });
      }

      const result = await authenticateWithGoogle({ email, name, picture, googleId });
      userProfile = { ...result.user };

      res.json(result);
    } catch (err: any) {
      console.error('[API Google Auth Error]:', err?.message || err);
      res.status(400).json({
        success: false,
        message: err?.message || 'Google authentication failed'
      });
    }
  });

  // GET /api/auth/me
  app.get('/api/auth/me', (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Unauthorized. No token provided.' });
    }

    const token = authHeader.replace('Bearer ', '').trim();
    const session = activeSessions.get(token);

    if (!session) {
      return res.status(401).json({ success: false, message: 'Invalid or expired session' });
    }

    res.json({
      success: true,
      user: session.user,
      token
    });
  });

  // POST /api/auth/logout
  app.post('/api/auth/logout', (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.replace('Bearer ', '').trim();
      activeSessions.delete(token);
    }
    res.json({ success: true, message: 'Signed out successfully' });
  });

  // 1. Search & Discovery API (Abstracted search service)
  app.get('/api/search', async (req: Request, res: Response) => {
    try {
      const {
        q,
        category,
        collection,
        minPrice,
        maxPrice,
        color,
        fabric,
        size,
        occasion,
        availability,
        sort
      } = req.query;

      // Helper to parse query arrays (comma separated or multi-key)
      const parseArray = (val: any): string[] => {
        if (!val) return [];
        if (Array.isArray(val)) return val.map(String);
        return String(val).split(',').map(s => s.trim()).filter(Boolean);
      };

      const filters: SearchQueryFilters = {
        q: typeof q === 'string' ? q : undefined,
        category: typeof category === 'string' ? category : undefined,
        collection: typeof collection === 'string' ? collection : undefined,
        minPrice: minPrice ? Number(minPrice) : undefined,
        maxPrice: maxPrice ? Number(maxPrice) : undefined,
        color: parseArray(color),
        fabric: parseArray(fabric),
        size: parseArray(size),
        occasion: parseArray(occasion),
        availability: availability as any,
        sort: sort as any
      };

      const result = await searchEngine.search(filters);
      res.json({
        success: true,
        data: result
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        message: 'Search engine query failed',
        error: err?.message || 'Unknown error'
      });
    }
  });

  app.get('/api/search/suggestions', async (req: Request, res: Response) => {
    try {
      const q = typeof req.query.q === 'string' ? req.query.q : undefined;
      const suggestions = await searchEngine.getSuggestions(q);
      res.json({
        success: true,
        data: suggestions
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: 'Failed to fetch suggestions' });
    }
  });

  app.get('/api/catalogue/filters', async (_req: Request, res: Response) => {
    try {
      const facets = await searchEngine.getFacets();
      res.json({
        success: true,
        data: facets
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: 'Failed to fetch catalogue facets' });
    }
  });

  // 2. Products API (With full candidate filter support)
  app.get('/api/products', (req: Request, res: Response) => {
    const {
      element,
      category,
      search,
      sort,
      minPrice,
      maxPrice,
      color,
      fabric,
      size,
      occasion,
      availability
    } = req.query;

    const parseArray = (val: any): string[] => {
      if (!val) return [];
      if (Array.isArray(val)) return val.map(String);
      return String(val).split(',').map(s => s.trim()).filter(Boolean);
    };

    let filtered = [...products];

    if (element && element !== 'all') {
      filtered = filtered.filter(p => p.element === element);
    }
    if (category && category !== 'all') {
      filtered = filtered.filter(p => p.category === category);
    }
    if (minPrice) {
      filtered = filtered.filter(p => p.price >= Number(minPrice));
    }
    if (maxPrice) {
      filtered = filtered.filter(p => p.price <= Number(maxPrice));
    }
    const colors = parseArray(color);
    if (colors.length) {
      filtered = filtered.filter(p => colors.some(c => p.color.toLowerCase().includes(c.toLowerCase())));
    }
    const fabrics = parseArray(fabric);
    if (fabrics.length) {
      filtered = filtered.filter(p => fabrics.some(f => p.fabric.toLowerCase().includes(f.toLowerCase())));
    }
    const sizes = parseArray(size);
    if (sizes.length) {
      filtered = filtered.filter(p => sizes.some(s => p.sizes.includes(s)));
    }
    const occasions = parseArray(occasion);
    if (occasions.length) {
      filtered = filtered.filter(p => p.occasion.some(occ => occasions.includes(occ)));
    }
    if (availability && availability !== 'all') {
      if (availability === 'in_stock') {
        filtered = filtered.filter(p => p.inStock && p.availability === 'in_stock');
      } else if (availability === 'made_to_order') {
        filtered = filtered.filter(p => p.availability === 'made_to_order');
      }
    }

    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.subtitle.toLowerCase().includes(q) ||
        p.fabric.toLowerCase().includes(q) ||
        p.color.toLowerCase().includes(q) ||
        p.weaveOrigin.toLowerCase().includes(q) ||
        p.artisan.name.toLowerCase().includes(q)
      );
    }

    if (sort === 'price-asc') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sort === 'price-desc') {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sort === 'hours-desc') {
      filtered.sort((a, b) => b.artisan.loomHours - a.artisan.loomHours);
    }

    res.json({
      success: true,
      total: filtered.length,
      data: filtered
    });
  });

  app.get('/api/products/:id', (req: Request, res: Response) => {
    const product = products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    res.json({ success: true, data: product });
  });

  // Dedicated Curated Route: Ready to Ship inventory query
  app.get(['/api/collections/ready-to-ship', '/api/ready-to-ship'], (req: Request, res: Response) => {
    try {
      // Query items explicitly flagged with ready-to-ship inventory statuses
      let items = products.filter(p => p.inStock && p.availability === 'in_stock');

      const { category, color, fabric, minPrice, maxPrice, sort } = req.query;
      if (category && category !== 'all') {
        const catStr = String(category).toLowerCase();
        items = items.filter(p => p.category.toLowerCase() === catStr);
      }
      if (color) {
        const colors = String(color).split(',').map(c => c.trim().toLowerCase());
        items = items.filter(p => colors.some(c => p.color.toLowerCase().includes(c)));
      }
      if (fabric) {
        const fabrics = String(fabric).split(',').map(f => f.trim().toLowerCase());
        items = items.filter(p => fabrics.some(f => p.fabric.toLowerCase().includes(f)));
      }
      if (minPrice) {
        items = items.filter(p => p.price >= Number(minPrice));
      }
      if (maxPrice) {
        items = items.filter(p => p.price <= Number(maxPrice));
      }

      if (sort === 'price-asc') {
        items.sort((a, b) => a.price - b.price);
      } else if (sort === 'price-desc') {
        items.sort((a, b) => b.price - a.price);
      } else if (sort === 'hours-desc') {
        items.sort((a, b) => b.artisan.loomHours - a.artisan.loomHours);
      }

      res.json({
        success: true,
        meta: {
          id: 'ready-to-ship',
          title: 'Ready to Ship Creations',
          teluguTitle: 'తక్షణ లభ్యత',
          subtitle: 'Immaculate Handcrafted Silhouettes Available for 24-Hour Immediate Courier',
          description: 'Vault-stored creations that have achieved full master-weaver completion and 24K zari hallmark certification. Prepared in bespoke velvet-lined teakwood preservation caskets with armored white-glove transit.',
          route: '/ready-to-ship',
          badge: 'Immediate Dispatch',
          dispatchPromise: 'Guaranteed 24-hour white glove handover to logistics courier'
        },
        total: items.length,
        data: items
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: 'Failed to query ready-to-ship inventory' });
    }
  });

  // Dedicated Curated Route: Sarees – Ready to Ship query
  app.get(['/api/collections/sarees-ready-to-ship', '/api/sarees-ready-to-ship'], (req: Request, res: Response) => {
    try {
      // Query items explicitly flagged with ready-to-ship inventory status and category === saree
      let items = products.filter(p => p.inStock && p.availability === 'in_stock' && p.category === 'saree');

      const { color, fabric, minPrice, maxPrice, sort } = req.query;
      if (color) {
        const colors = String(color).split(',').map(c => c.trim().toLowerCase());
        items = items.filter(p => colors.some(c => p.color.toLowerCase().includes(c)));
      }
      if (fabric) {
        const fabrics = String(fabric).split(',').map(f => f.trim().toLowerCase());
        items = items.filter(p => fabrics.some(f => p.fabric.toLowerCase().includes(f)));
      }
      if (minPrice) {
        items = items.filter(p => p.price >= Number(minPrice));
      }
      if (maxPrice) {
        items = items.filter(p => p.price <= Number(maxPrice));
      }

      if (sort === 'price-asc') {
        items.sort((a, b) => a.price - b.price);
      } else if (sort === 'price-desc') {
        items.sort((a, b) => b.price - a.price);
      } else if (sort === 'hours-desc') {
        items.sort((a, b) => b.artisan.loomHours - a.artisan.loomHours);
      }

      res.json({
        success: true,
        meta: {
          id: 'sarees-ready-to-ship',
          title: 'Sarees – Ready to Ship',
          teluguTitle: 'తక్షణ పట్టు చీరలు',
          subtitle: 'Certified Masterpiece Drapes in Kanchipuram, Banarasi & Uppada Weaves',
          description: 'Six yards of woven poetry, tested real gold-silver zari, and certified Silk Mark authenticity. Dispatched immediately for bridal muhurthams and royal celebrations.',
          route: '/sarees-ready-to-ship',
          badge: 'Handloom Saree Vault',
          dispatchPromise: 'Ships within 24 hours in velvet-lined teakwood casket with unstitched matching blouse'
        },
        total: items.length,
        data: items
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: 'Failed to query sarees ready to ship' });
    }
  });

  // Editorial Collections API
  app.get('/api/editorial-collections', (_req: Request, res: Response) => {
    res.json({
      success: true,
      data: EDITORIAL_COLLECTIONS
    });
  });

  app.get('/api/editorial-collections/:id', (req: Request, res: Response) => {
    const col = EDITORIAL_COLLECTIONS.find(c => c.id === req.params.id);
    if (!col) {
      return res.status(404).json({ success: false, message: 'Collection not found' });
    }
    // Enrich with actual matched products
    const colProducts = products.filter(p => {
      if (col.element === 'aaru') return p.element === 'aaru';
      return p.element === col.element;
    });

    res.json({
      success: true,
      data: {
        ...col,
        products: colProducts
      }
    });
  });

  // Shop the Look API
  app.get('/api/shop-the-look', (_req: Request, res: Response) => {
    res.json({
      success: true,
      data: SHOP_THE_LOOKS
    });
  });

  app.get('/api/shop-the-look/:id', (req: Request, res: Response) => {
    const look = SHOP_THE_LOOKS.find(l => l.id === req.params.id);
    if (!look) {
      return res.status(404).json({ success: false, message: 'Look not found' });
    }
    res.json({
      success: true,
      data: look
    });
  });

  // 2. Editorial Stories API
  app.get('/api/stories', (_req: Request, res: Response) => {
    res.json({ success: true, data: stories });
  });

  app.get('/api/stories/:id', (req: Request, res: Response) => {
    const story = stories.find(s => s.id === req.params.id);
    if (!story) {
      return res.status(404).json({ success: false, message: 'Story not found' });
    }
    res.json({ success: true, data: story });
  });

  // 3. Orders API (PostgreSQL / Firebase Order History representation)
  app.get('/api/orders', (_req: Request, res: Response) => {
    res.json({ success: true, data: orders });
  });

  app.get('/api/orders/:id', (req: Request, res: Response) => {
    const order = orders.find(o => o.id === req.params.id || o.orderNumber === req.params.id);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }
    res.json({ success: true, data: order });
  });

  app.post('/api/orders', (req: Request, res: Response) => {
    const { items, total, shippingAddress, giftPackaging } = req.body;
    if (!items || !items.length) {
      return res.status(400).json({ success: false, message: 'Cart items required to place order' });
    }

    const orderSeq = Math.floor(1000 + Math.random() * 9000);
    const newOrderNumber = `ARU-${orderSeq}`;
    const newOrder: Order = {
      id: `order-${Date.now()}`,
      orderNumber: newOrderNumber,
      date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      total: total || items.reduce((sum: number, it: any) => sum + (it.price * it.quantity), 0),
      status: 'Artisan Allocated',
      estimatedDelivery: new Date(Date.now() + 14 * 86400000).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      giftPackaging: Boolean(giftPackaging),
      shippingAddress: shippingAddress || {
        fullName: userProfile.fullName,
        email: userProfile.email,
        phone: userProfile.phone,
        address: 'Road No. 36, Jubilee Hills',
        city: 'Hyderabad',
        postalCode: '500033',
        country: 'India'
      },
      items,
      trackingMilestones: [
        {
          title: 'Artisan Allocated',
          description: 'Senior Master Weaver and guild loom assigned for bespoke crafting.',
          date: 'Just now',
          completed: true
        },
        {
          title: 'Warp Setup & Zari Allocation',
          description: 'Inspecting certified 24k gold core zari and pure mulberry silk yarn.',
          date: 'In preparation',
          completed: false
        },
        {
          title: 'Handloom Weaving',
          description: 'Artisan pit-loom jacquard weaving cycle begins.',
          date: 'Pending',
          completed: false
        },
        {
          title: 'Quality Archival & Monogramming',
          description: 'Quality seal and velvet-lined preservation casket preparation.',
          date: 'Pending',
          completed: false
        },
        {
          title: 'White Glove Armored Dispatch',
          description: 'Direct insured delivery to your residence.',
          date: 'Pending',
          completed: false
        }
      ]
    };

    orders.unshift(newOrder);

    // Also trigger automatic push notification for the new order
    const orderNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: `Order Confirmed #${newOrder.orderNumber}`,
      message: `Your bespoke creation has been placed in the Kanchipuram loom queue. Master artisan will commence weaving shortly.`,
      type: 'order',
      timestamp: 'Just now',
      read: false,
      metadata: { orderId: newOrder.orderNumber }
    };
    notifications.unshift(orderNotif);

    res.status(201).json({
      success: true,
      message: 'Order created successfully and placed in artisan queue',
      data: newOrder
    });
  });

  // 4. User Profile API
  app.get('/api/profile', (_req: Request, res: Response) => {
    res.json({ success: true, data: userProfile });
  });

  app.put('/api/profile', (req: Request, res: Response) => {
    userProfile = {
      ...userProfile,
      ...req.body
    };
    res.json({ success: true, message: 'Profile updated successfully', data: userProfile });
  });

  // 5. Notifications & Push Alert API
  app.get('/api/notifications', (_req: Request, res: Response) => {
    res.json({
      success: true,
      total: notifications.length,
      unreadCount: notifications.filter(n => !n.read).length,
      data: notifications
    });
  });

  app.post('/api/notifications/read', (req: Request, res: Response) => {
    const { id } = req.body;
    if (id) {
      notifications = notifications.map(n => n.id === id ? { ...n, read: true } : n);
    } else {
      notifications = notifications.map(n => ({ ...n, read: true }));
    }
    res.json({ success: true, data: notifications });
  });

  // Trigger test push alert (for live demo of push notification capabilities)
  app.post('/api/notifications/trigger-test', (req: Request, res: Response) => {
    const { type } = req.body;
    let newNotif: NotificationItem;

    if (type === 'recommendation') {
      newNotif = {
        id: `notif-${Date.now()}`,
        title: 'New Haute Recommendation: The Sixth Element Capsule',
        message: `Curated exclusively for your affinity with ${userProfile.elementAffinity.toUpperCase()}: The Sovereign Āru Kanjeevaram Saree is ready for private inspection.`,
        type: 'recommendation',
        timestamp: 'Just now',
        read: false,
        metadata: { productId: 'aaru-01' }
      };
    } else if (type === 'order') {
      const activeOrder = orders[0];
      newNotif = {
        id: `notif-${Date.now()}`,
        title: `Loom Progress Update: #${activeOrder ? activeOrder.orderNumber : 'ARU-9021'}`,
        message: 'The gold zari weft has crossed 280 loom hours. Master weaver is now executing the Telugu "ఆరు" selvedge signature monogram.',
        type: 'order',
        timestamp: 'Just now',
        read: false,
        metadata: { orderId: activeOrder ? activeOrder.orderNumber : 'ARU-9021' }
      };
    } else {
      newNotif = {
        id: `notif-${Date.now()}`,
        title: 'VIP Atelier Invitation: Autumn Loom Showcase',
        message: 'An exclusive private appointment slot is open for Hyderabad & London patrons.',
        type: 'atelier',
        timestamp: 'Just now',
        read: false
      };
    }

    notifications.unshift(newNotif);
    res.json({ success: true, message: 'Push alert triggered successfully', data: newNotif });
  });

  // 6. Consultations API (WhatsApp and Bespoke Salon Booking)
  app.post('/api/consultations', (req: Request, res: Response) => {
    const { clientName, email, phone, preferredChannel, preferredDate, coutureInterest, measurementsNotes, budgetRange } = req.body;
    const newCons: ConsultationRequest = {
      id: `cons-${Date.now()}`,
      clientName: clientName || userProfile.fullName,
      email: email || userProfile.email,
      phone: phone || userProfile.phone,
      preferredChannel: preferredChannel || 'whatsapp',
      preferredDate: preferredDate || new Date().toISOString().split('T')[0],
      coutureInterest: coutureInterest || 'Bespoke Consultation',
      measurementsNotes,
      budgetRange,
      status: 'confirmed'
    };

    consultations.unshift(newCons);

    // Add notification for confirmation
    notifications.unshift({
      id: `notif-${Date.now()}`,
      title: 'Consultation Confirmed',
      message: `Your bespoke consultation on ${newCons.preferredChannel === 'whatsapp' ? 'WhatsApp Business' : 'Private Video'} is confirmed with our lead couturier.`,
      type: 'atelier',
      timestamp: 'Just now',
      read: false
    });

    res.status(201).json({
      success: true,
      message: 'Consultation booked successfully with AARU Couturier',
      data: newCons
    });
  });

  // 7. Recommendations API based on element and browsing
  app.get('/api/recommendations', (req: Request, res: Response) => {
    const affinity = req.query.element || userProfile.elementAffinity || 'aaru';
    const recommended = products.filter(p => p.element === affinity || p.element === 'aaru');
    res.json({
      success: true,
      element: affinity,
      data: recommended
    });
  });

  // Health check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'AARU Luxury E-commerce API',
      version: '1.0.0',
      database: 'PostgreSQL/Firebase Schema Emulation Active'
    });
  });

  // Vite middleware for development vs production static serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AARU Atelier Server] Running on http://localhost:${PORT}`);
  });
}

startServer();
