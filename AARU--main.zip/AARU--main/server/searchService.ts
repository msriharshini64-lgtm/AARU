import { Product, SearchFacets, SearchFacetOption, SearchResponse, ElementType } from '../src/types/index';
import { ELEMENT_METADATA } from '../src/data/mockData';

export interface SearchQueryFilters {
  q?: string;
  category?: string;
  collection?: string;
  minPrice?: number;
  maxPrice?: number;
  color?: string[];
  fabric?: string[];
  size?: string[];
  occasion?: string[];
  availability?: 'all' | 'in_stock' | 'made_to_order';
  sort?: 'featured' | 'price-asc' | 'price-desc' | 'hours-desc' | 'newest';
  page?: number;
  limit?: number;
}

export interface CollectionDiscoveryItem {
  id: string;
  name: string;
  teluguName: string;
  concept: string;
  description: string;
  productCount: number;
}

/**
 * SearchEngine - Abstracted search service interface.
 * The underlying search provider (Elasticsearch, Algolia, Typesense, PostgreSQL FTS)
 * is abstracted behind this contract.
 */
export interface SearchEngine {
  search(params: SearchQueryFilters): Promise<SearchResponse>;
  getFacets(): Promise<SearchFacets>;
  getSuggestions(query?: string): Promise<SearchResponse['suggestions']>;
}

/**
 * DatabaseSearchEngine
 * Mock database-backed search implementation supporting multi-attribute
 * querying, exact candidate facets, and collection discovery.
 */
export class DatabaseSearchEngine implements SearchEngine {
  private products: Product[];

  constructor(products: Product[]) {
    this.products = products;
  }

  public updateDataset(newProducts: Product[]) {
    this.products = newProducts;
  }

  public async search(params: SearchQueryFilters): Promise<SearchResponse> {
    const {
      q,
      category,
      collection,
      minPrice,
      maxPrice,
      color = [],
      fabric = [],
      size = [],
      occasion = [],
      availability = 'all',
      sort = 'featured'
    } = params;

    let results = [...this.products];

    // 1. Text Search Query matching product attributes
    if (q && q.trim()) {
      const queryWords = q.toLowerCase().trim().split(/\s+/);
      results = results.filter(product => {
        const searchableCorpus = [
          product.name,
          product.subtitle,
          product.description,
          product.editorialNote,
          product.category,
          product.element,
          product.fabric,
          product.color,
          product.weaveOrigin,
          product.artisan.name,
          product.artisan.region,
          ...product.occasion,
          ...product.details
        ].join(' ').toLowerCase();

        return queryWords.every(word => searchableCorpus.includes(word));
      });
    }

    // 2. Candidate Filter: Category
    if (category && category !== 'all') {
      results = results.filter(p => p.category.toLowerCase() === category.toLowerCase());
    }

    // 3. Candidate Filter: Collection / Element
    if (collection && collection !== 'all') {
      results = results.filter(p => p.element.toLowerCase() === collection.toLowerCase());
    }

    // 4. Candidate Filter: Price Range
    if (typeof minPrice === 'number' && !isNaN(minPrice)) {
      results = results.filter(p => p.price >= minPrice);
    }
    if (typeof maxPrice === 'number' && !isNaN(maxPrice)) {
      results = results.filter(p => p.price <= maxPrice);
    }

    // 5. Candidate Filter: Color
    if (color && color.length > 0) {
      const normalizedColors = color.map(c => c.toLowerCase());
      results = results.filter(p =>
        normalizedColors.some(c => p.color.toLowerCase().includes(c))
      );
    }

    // 6. Candidate Filter: Fabric
    if (fabric && fabric.length > 0) {
      const normalizedFabrics = fabric.map(f => f.toLowerCase());
      results = results.filter(p =>
        normalizedFabrics.some(f => p.fabric.toLowerCase().includes(f))
      );
    }

    // 7. Candidate Filter: Size
    if (size && size.length > 0) {
      results = results.filter(p =>
        size.some(s => p.sizes.includes(s) || (s === 'Free Size' && p.sizes.includes('Free Size')))
      );
    }

    // 8. Candidate Filter: Occasion
    if (occasion && occasion.length > 0) {
      results = results.filter(p =>
        p.occasion.some(occ => occasion.includes(occ))
      );
    }

    // 9. Candidate Filter: Availability
    if (availability && availability !== 'all') {
      if (availability === 'in_stock') {
        results = results.filter(p => p.inStock && p.availability === 'in_stock');
      } else if (availability === 'made_to_order') {
        results = results.filter(p => p.availability === 'made_to_order');
      }
    }

    // 10. Sorting
    if (sort === 'price-asc') {
      results.sort((a, b) => a.price - b.price);
    } else if (sort === 'price-desc') {
      results.sort((a, b) => b.price - a.price);
    } else if (sort === 'hours-desc') {
      results.sort((a, b) => b.artisan.loomHours - a.artisan.loomHours);
    } else if (sort === 'newest') {
      results.sort((a, b) => (b.originalPrice ? 1 : 0) - (a.originalPrice ? 1 : 0));
    } else {
      // Default: Featured first, then highest loom hours
      results.sort((a, b) => {
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        return b.artisan.loomHours - a.artisan.loomHours;
      });
    }

    // 11. Collection Discovery: Match against elemental capsules
    const matchedCollections = this.discoverCollections(q);

    // 12. Facets generation
    const facets = await this.getFacets();

    // 13. Suggestions for empty/zero states
    const suggestions = await this.getSuggestions(q);

    return {
      products: results,
      collections: matchedCollections,
      total: results.length,
      facets,
      suggestions
    };
  }

  public discoverCollections(query?: string): CollectionDiscoveryItem[] {
    const allCollections: CollectionDiscoveryItem[] = [
      {
        id: 'aaru',
        name: 'The Sixth Element (ఆరు)',
        teluguName: 'ఆరు - ఆరవ తత్వం',
        concept: 'The Living Weaver’s Soul',
        description: '24k Tested Gilt Zari & Sovereign Masterpieces',
        productCount: this.products.filter(p => p.element === 'aaru').length
      },
      {
        id: 'ether',
        name: 'Akasha (Ether / Space)',
        teluguName: 'ఆకాశం',
        concept: 'Cosmic Starlight & Midnight Velvet',
        description: 'Constellation Zardozi & Celestial Organza',
        productCount: this.products.filter(p => p.element === 'ether').length
      },
      {
        id: 'fire',
        name: 'Agni (Fire)',
        teluguName: 'అగ్ని',
        concept: 'Molten Zari & Crimson Flames',
        description: 'Blazing Kadwa Brocades & Imperial Lehengas',
        productCount: this.products.filter(p => p.element === 'fire').length
      },
      {
        id: 'water',
        name: 'Jala (Water)',
        teluguName: 'జలం',
        concept: 'Fluidity & Serpentine Drapes',
        description: 'Uppada Jamdani & Rippling Resham Silks',
        productCount: this.products.filter(p => p.element === 'water').length
      },
      {
        id: 'earth',
        name: 'Prithvi (Earth)',
        teluguName: 'పృథ్వి',
        concept: 'Terra, Bark & Ochre Silks',
        description: 'Double-Ikat Pochampally & Raw Matka Weaves',
        productCount: this.products.filter(p => p.element === 'earth').length
      },
      {
        id: 'air',
        name: 'Vayu (Air)',
        teluguName: 'వాయువు',
        concept: 'Weightless Organza & Sheer Whisper',
        description: 'Fine Chanderi Muslin & Ahimsa Peace Silk',
        productCount: this.products.filter(p => p.element === 'air').length
      }
    ];

    if (!query || !query.trim()) {
      return allCollections;
    }

    const qLower = query.toLowerCase().trim();
    return allCollections.filter(c =>
      c.name.toLowerCase().includes(qLower) ||
      c.teluguName.includes(query.trim()) ||
      c.concept.toLowerCase().includes(qLower) ||
      c.description.toLowerCase().includes(qLower)
    );
  }

  public async getFacets(): Promise<SearchFacets> {
    const categoryMap = new Map<string, number>();
    const colorMap = new Map<string, { count: number; hex?: string }>();
    const fabricMap = new Map<string, number>();
    const sizeMap = new Map<string, number>();
    const occasionMap = new Map<string, number>();
    const availabilityMap = new Map<string, number>();
    let minPrice = Number.MAX_SAFE_INTEGER;
    let maxPrice = 0;

    for (const p of this.products) {
      // Categories
      categoryMap.set(p.category, (categoryMap.get(p.category) || 0) + 1);

      // Colors
      const existingColor = colorMap.get(p.color);
      colorMap.set(p.color, {
        count: (existingColor?.count || 0) + 1,
        hex: p.colorHex || existingColor?.hex
      });

      // Fabrics
      fabricMap.set(p.fabric, (fabricMap.get(p.fabric) || 0) + 1);

      // Sizes
      for (const s of p.sizes) {
        sizeMap.set(s, (sizeMap.get(s) || 0) + 1);
      }

      // Occasions
      for (const occ of p.occasion) {
        occasionMap.set(occ, (occasionMap.get(occ) || 0) + 1);
      }

      // Availability
      availabilityMap.set(p.availability, (availabilityMap.get(p.availability) || 0) + 1);

      // Price
      if (p.price < minPrice) minPrice = p.price;
      if (p.price > maxPrice) maxPrice = p.price;
    }

    const categoryLabels: Record<string, string> = {
      saree: 'Heritage Sarees',
      sherwani: 'Regal Sherwanis',
      lehenga: 'Bridal Lehengas',
      'cape-gown': 'Celestial Cape-Gowns',
      kurta: 'Couture Kurta Sets',
      stole: 'Pashmina Stoles'
    };

    const categories: SearchFacetOption[] = Array.from(categoryMap.entries()).map(([val, count]) => ({
      label: categoryLabels[val] || val,
      value: val,
      count
    }));

    const colors: SearchFacetOption[] = Array.from(colorMap.entries()).map(([val, info]) => ({
      label: val,
      value: val,
      count: info.count,
      hex: info.hex
    }));

    const fabrics: SearchFacetOption[] = Array.from(fabricMap.entries()).map(([val, count]) => ({
      label: val,
      value: val,
      count
    }));

    const sizes: SearchFacetOption[] = Array.from(sizeMap.entries()).map(([val, count]) => ({
      label: val,
      value: val,
      count
    }));

    const occasions: SearchFacetOption[] = Array.from(occasionMap.entries()).map(([val, count]) => ({
      label: val,
      value: val,
      count
    }));

    const availabilities: SearchFacetOption[] = [
      {
        label: 'Ready to Ship (In Stock)',
        value: 'in_stock',
        count: availabilityMap.get('in_stock') || 0
      },
      {
        label: 'Made to Order (Bespoke)',
        value: 'made_to_order',
        count: availabilityMap.get('made_to_order') || 0
      }
    ];

    const collections: SearchFacetOption[] = [
      { label: 'All Collections', value: 'all', count: this.products.length },
      { label: 'The Sixth Element (ఆరు)', value: 'aaru', count: this.products.filter(p => p.element === 'aaru').length },
      { label: 'Akasha (Ether)', value: 'ether', count: this.products.filter(p => p.element === 'ether').length },
      { label: 'Agni (Fire)', value: 'fire', count: this.products.filter(p => p.element === 'fire').length },
      { label: 'Jala (Water)', value: 'water', count: this.products.filter(p => p.element === 'water').length },
      { label: 'Prithvi (Earth)', value: 'earth', count: this.products.filter(p => p.element === 'earth').length },
      { label: 'Vayu (Air)', value: 'air', count: this.products.filter(p => p.element === 'air').length }
    ];

    return {
      categories,
      collections,
      priceRange: {
        min: minPrice === Number.MAX_SAFE_INTEGER ? 50000 : minPrice,
        max: maxPrice === 0 ? 300000 : maxPrice
      },
      colors,
      fabrics,
      sizes,
      occasions,
      availabilities
    };
  }

  public async getSuggestions(_query?: string): Promise<SearchResponse['suggestions']> {
    return {
      popularCategories: ['saree', 'lehenga', 'cape-gown', 'sherwani', 'kurta', 'stole'],
      trendingSearches: [
        'Kanchipuram Silk',
        '24k Gold Zari',
        'Banarasi Kadwa',
        'Astral Velvet Cape',
        'Pochampally Ikat',
        'Changthangi Pashmina',
        'Bridal Wedding'
      ],
      featuredCollections: [
        { id: 'aaru', name: 'The Sixth Element (ఆరు)' },
        { id: 'ether', name: 'Akasha Celestial Abyss' },
        { id: 'fire', name: 'Agni Molten Zari' },
        { id: 'water', name: 'Jala Oceanic Jamdani' }
      ]
    };
  }
}
